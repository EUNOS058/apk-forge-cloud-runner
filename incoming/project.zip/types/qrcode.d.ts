declare module 'qrcode' {
  export type QRCodeModules = {
    size: number;
    data: Uint8Array | number[];
  };

  export type QRCodeSymbol = {
    modules: QRCodeModules;
    version: number;
    errorCorrectionLevel: unknown;
  };

  export function create(
    text: string,
    options?: { errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H'; version?: number }
  ): QRCodeSymbol;

  const QRCode: { create: typeof create };
  export default QRCode;
}
