import React from 'react';
import { View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

import { AppProvider, useApp } from './lib/store';
import HomeScreen from './screens/HomeScreen';
import RunScreen from './screens/RunScreen';
import ProjectScreen from './screens/ProjectScreen';
import FileViewerScreen from './screens/FileViewerScreen';
import DeliverScreen from './screens/DeliverScreen';
import HelpScreen from './screens/HelpScreen';

const Stack = createNativeStackNavigator();

function Root() {
  const { p, mode, ready } = useApp();

  const navTheme = {
    ...(mode === 'dark' ? DarkTheme : DefaultTheme),
    colors: {
      ...(mode === 'dark' ? DarkTheme : DefaultTheme).colors,
      background: p.bg,
      card: p.surface,
      text: p.text,
      border: p.border,
      primary: p.accent,
    },
  };

  if (!ready) return <View style={{ flex: 1, backgroundColor: p.bg }} />;

  return (
    <NavigationContainer theme={navTheme as any}>
      <StatusBar style={mode === 'dark' ? 'light' : 'dark'} />
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen
          name="Preview"
          component={RunScreen}
          options={{ presentation: 'modal', animation: 'slide_from_bottom' }}
        />
        <Stack.Screen name="Guide" component={DeliverScreen} options={{ animation: 'slide_from_right' }} />
        <Stack.Screen name="Files" component={ProjectScreen} options={{ animation: 'slide_from_right' }} />
        <Stack.Screen name="Help" component={HelpScreen} options={{ animation: 'slide_from_right' }} />
        <Stack.Screen
          name="FileViewer"
          component={FileViewerScreen}
          options={{ presentation: 'modal', animation: 'slide_from_bottom' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });
  if (!fontsLoaded) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AppProvider>
          <Root />
        </AppProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
