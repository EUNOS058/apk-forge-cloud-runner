/**
 * Builds a self-contained, runnable HTML document from a virtual file system.
 * Everything is inlined so it executes inside a WebView (native) or iframe (web)
 * with no network access required for the "html" tier.
 */
import type { VFS, VFile } from './vfs';
import { dataUrl, extname, lookup, resolvePath } from './vfs';

export type RunTier = 'html' | 'react' | 'static' | 'none';

export type RunPlan = {
  tier: RunTier;
  entry: string;
  reason: { en: string; bn: string };
  needsNetwork: boolean;
};

const HTML_ENTRIES = [
  'index.html', 'public/index.html', 'dist/index.html', 'build/index.html',
  'src/index.html', 'www/index.html', 'app/index.html', 'docs/index.html',
];

const JS_ENTRIES = [
  'App.tsx', 'App.jsx', 'App.js', 'app.tsx', 'src/App.tsx', 'src/App.jsx',
  'src/App.js', 'src/main.tsx', 'src/main.jsx', 'src/main.js', 'src/index.tsx',
  'src/index.jsx', 'src/index.js', 'index.tsx', 'index.jsx', 'index.js',
];

export function planRun(vfs: VFS): RunPlan {
  for (const c of HTML_ENTRIES) {
    if (vfs.files.has(c)) {
      return {
        tier: 'html',
        entry: c,
        reason: {
          en: 'Static web entry found — runs fully offline.',
          bn: 'স্ট্যাটিক ওয়েব এন্ট্রি পাওয়া গেছে — অফলাইনেই চলবে।',
        },
        needsNetwork: false,
      };
    }
  }
  // any html anywhere
  for (const [p] of vfs.files) {
    if (extname(p) === 'html') {
      return {
        tier: 'html',
        entry: p,
        reason: { en: 'HTML page found in archive.', bn: 'আর্কাইভে HTML পেজ পাওয়া গেছে।' },
        needsNetwork: false,
      };
    }
  }
  for (const c of JS_ENTRIES) {
    if (vfs.files.has(c)) {
      return {
        tier: 'react',
        entry: c,
        reason: {
          en: 'React / React Native entry compiled live with Babel.',
          bn: 'React / React Native এন্ট্রি Babel দিয়ে লাইভ কম্পাইল হবে।',
        },
        needsNetwork: true,
      };
    }
  }
  const readme = vfs.files.get('README.md') || vfs.files.get('readme.md');
  return {
    tier: readme ? 'static' : 'none',
    entry: readme ? readme.path : '',
    reason: {
      en: 'No runnable entry point — showing project summary.',
      bn: 'চালানোর মতো এন্ট্রি নেই — প্রজেক্ট সামারি দেখানো হচ্ছে।',
    },
    needsNetwork: false,
  };
}

/* ------------------------------------------------------------------ helpers */

function esc(s: string): string {
  return s.replace(/<\/script/gi, '<\\/script');
}

const MAX_BIN = 3 * 1024 * 1024;

function vfsPayload(vfs: VFS): string {
  const out: Record<string, { t?: string; b?: string; m: string }> = {};
  let bin = 0;
  vfs.files.forEach((f, p) => {
    if (f.binary) {
      if (!f.base64 || bin + f.base64.length > MAX_BIN) return;
      bin += f.base64.length;
      out[p] = { b: f.base64, m: f.mime };
    } else {
      out[p] = { t: f.text ?? '', m: f.mime };
    }
  });
  return esc(JSON.stringify(out));
}

/* --------------------------------------------------------- shared bootstrap */

const BOOTSTRAP = [
  '(function(){',
  '  var V = window.__VFS || {};',
  '  var urlCache = {}, pending = {};',
  '  function resolve(base, spec){',
  '    if (/^(https?:|data:|blob:|\\/\\/)/.test(spec)) return spec;',
  '    var clean = spec.split("?")[0].split("#")[0];',
  '    var dir = base.indexOf("/") >= 0 ? base.slice(0, base.lastIndexOf("/")) : "";',
  '    var full = (clean.charAt(0) === "/" ? clean.slice(1) : (dir ? dir + "/" + clean : clean));',
  '    var parts = full.split("/"), out = [];',
  '    for (var i=0;i<parts.length;i++){ var p=parts[i]; if(!p||p===".")continue; if(p==="..")out.pop(); else out.push(p); }',
  '    return out.join("/");',
  '  }',
  '  var EXT = ["", ".js", ".mjs", ".jsx", ".ts", ".tsx", ".json", ".css"];',
  '  function find(path){',
  '    for (var i=0;i<EXT.length;i++){ if (V[path+EXT[i]]) return path+EXT[i]; }',
  '    for (var j=1;j<EXT.length;j++){ if (V[path+"/index"+EXT[j]]) return path+"/index"+EXT[j]; }',
  '    return null;',
  '  }',
  '  function text(path){ var f=V[path]; if(!f) return ""; if(f.t!=null) return f.t; return atob(f.b||""); }',
  '  function asData(path){',
  '    var f = V[path]; if(!f) return "";',
  '    if (f.b != null) return "data:" + f.m + ";base64," + f.b;',
  '    return "data:" + f.m + ";charset=utf-8," + encodeURIComponent(f.t || "");',
  '  }',
  '  window.__vfsResolve = resolve;',
  '  window.__vfsFind = find;',
  '  window.__vfsText = text;',
  '  window.__vfsData = asData;',
  '  window.__vfsHas = function(p){ return !!V[p]; };',
  '  window.__vfsList = function(){ return Object.keys(V); };',
  '  var IMPORT_RE = /(\\bfrom\\s*|\\bimport\\s*\\(?\\s*)("([^"]+)"|\'([^\']+)\')/g;',
  '  function moduleUrl(path){',
  '    if (urlCache[path]) return urlCache[path];',
  '    if (pending[path]) return pending[path];',
  '    var src = text(path);',
  '    if (/\\.json$/.test(path)) src = "export default " + (src || "null") + ";";',
  '    pending[path] = "about:blank";',
  '    src = src.replace(IMPORT_RE, function(m, pre, q, d1, d2){',
  '      var spec = d1 || d2; if(!spec) return m;',
  '      if (/^(https?:|data:|blob:)/.test(spec)) return m;',
  '      var target = find(resolve(path, spec));',
  '      if (!target) return m;',
  '      if (/\\.css$/.test(target)) { injectCss(target); return pre + JSON.stringify("data:text/javascript,export default 0"); }',
  '      return pre + JSON.stringify(moduleUrl(target));',
  '    });',
  '    var u = URL.createObjectURL(new Blob([src], { type: "text/javascript" }));',
  '    urlCache[path] = u; delete pending[path];',
  '    return u;',
  '  }',
  '  window.__moduleUrl = moduleUrl;',
  '  var cssDone = {};',
  '  function injectCss(path){',
  '    if (cssDone[path]) return; cssDone[path] = 1;',
  '    var css = text(path).replace(/url\\(\\s*(["\']?)([^"\')]+)\\1\\s*\\)/g, function(m, q, ref){',
  '      if (/^(https?:|data:|#)/.test(ref)) return m;',
  '      var t = find(resolve(path, ref)) || resolve(path, ref);',
  '      return V[t] ? "url(" + asData(t) + ")" : m;',
  '    });',
  '    var s = document.createElement("style"); s.textContent = css; document.head.appendChild(s);',
  '  }',
  '  window.__injectCss = injectCss;',
  '  function send(type, payload){',
  '    var msg = JSON.stringify({ __apkstudio: true, type: type, payload: payload });',
  '    try { if (window.ReactNativeWebView) window.ReactNativeWebView.postMessage(msg); } catch(e){}',
  '    try { if (window.parent && window.parent !== window) window.parent.postMessage(msg, "*"); } catch(e){}',
  '  }',
  '  window.__send = send;',
  '  ["log","warn","error","info"].forEach(function(level){',
  '    var orig = console[level];',
  '    console[level] = function(){',
  '      var parts = [];',
  '      for (var i=0;i<arguments.length;i++){',
  '        var a = arguments[i];',
  '        try { parts.push(typeof a === "string" ? a : JSON.stringify(a)); } catch(e){ parts.push(String(a)); }',
  '      }',
  '      send("console", { level: level, text: parts.join(" ") });',
  '      try { orig.apply(console, arguments); } catch(e){}',
  '    };',
  '  });',
  '  window.addEventListener("error", function(e){',
  '    send("console", { level: "error", text: (e.message || "error") + " @" + (e.lineno||0) });',
  '  });',
  '  window.addEventListener("unhandledrejection", function(e){',
  '    send("console", { level: "error", text: "Unhandled: " + ((e.reason && e.reason.message) || e.reason) });',
  '  });',
  '  document.addEventListener("click", function(e){',
  '    var a = e.target && e.target.closest ? e.target.closest("a") : null;',
  '    if (!a) return;',
  '    var href = a.getAttribute("href") || "";',
  '    if (href.charAt(0) === "#" || /^(https?:|mailto:|tel:)/.test(href)) return;',
  '    e.preventDefault(); send("navigate", { href: href });',
  '  }, true);',
  '  setTimeout(function(){ send("ready", { title: document.title || "" }); }, 60);',
  '})();',
].join('\n');

const BASE_CSS = [
  '*,*::before,*::after{box-sizing:border-box}',
  'html,body{margin:0;padding:0;min-height:100%}',
  'body{-webkit-font-smoothing:antialiased;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}',
  '#__err{position:fixed;left:0;right:0;bottom:0;max-height:45%;overflow:auto;background:#2A0F13;color:#FF8A94;font:12px/1.5 ui-monospace,Menlo,monospace;padding:12px 14px;border-top:2px solid #FF5F6D;z-index:99999;white-space:pre-wrap}',
].join('');

/* -------------------------------------------------------------- html runner */

export function buildHtmlDocument(vfs: VFS, entryPath: string): string {
  const entry = vfs.files.get(entryPath);
  let src = entry?.text ?? '<h1>Missing entry</h1>';

  // Inline stylesheets
  src = src.replace(
    /<link\b[^>]*rel=["']?stylesheet["']?[^>]*>/gi,
    (tag) => {
      const m = tag.match(/href=["']([^"']+)["']/i);
      if (!m) return '';
      const target = lookup(vfs, resolvePath(entryPath, m[1]))?.path ?? resolvePath(entryPath, m[1]);
      const f = vfs.files.get(target);
      if (!f?.text) return '';
      return `<style data-apkstudio="${target}">${inlineCssUrls(vfs, target, f.text)}</style>`;
    }
  );

  // Rewrite media references to data urls
  src = src.replace(
    /(\s)(src|href|poster)=(["'])(?!https?:|data:|#|mailto:|tel:|\/\/)([^"']+)\3/gi,
    (whole, space, attr, _q, ref) => {
      const target = resolvePath(entryPath, ref);
      const f = vfs.files.get(target);
      if (!f) return whole;
      const e = extname(target);
      if (e === 'js' || e === 'mjs' || e === 'html' || e === 'htm') return whole;
      return `${space}${attr}="${dataUrl(f)}"`;
    }
  );

  // Collect and neutralise script tags
  const scripts: { module: boolean; path?: string; code?: string }[] = [];
  src = src.replace(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi, (whole, attrs, body) => {
    const isModule = /type=["']module["']/i.test(attrs);
    const m = attrs.match(/src=["']([^"']+)["']/i);
    if (m) {
      if (/^https?:|^\/\//.test(m[1])) return whole;
      const target = lookup(vfs, resolvePath(entryPath, m[1]))?.path;
      if (target) scripts.push({ module: isModule, path: target });
      return '';
    }
    if (body.trim()) scripts.push({ module: isModule, code: body });
    return '';
  });

  const boot: string[] = [];
  scripts.forEach((s, i) => {
    if (s.path) {
      if (s.module) {
        boot.push(`import(window.__moduleUrl(${JSON.stringify(s.path)})).catch(function(e){window.__fail(e);});`);
      } else {
        boot.push(`try{ (0,eval)(window.__vfsText(${JSON.stringify(s.path)})); }catch(e){ window.__fail(e); }`);
      }
    } else if (s.code) {
      const url = `__inline_${i}.js`;
      boot.push(
        s.module
          ? `import(URL.createObjectURL(new Blob([${JSON.stringify(s.code)}],{type:"text/javascript"}))).catch(function(e){window.__fail(e);});`
          : `try{ (0,eval)(${JSON.stringify(s.code)}); }catch(e){ window.__fail(e); }`
      );
      void url;
    }
  });

  const headMatch = src.match(/<head[^>]*>([\s\S]*?)<\/head>/i);
  const bodyMatch = src.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  const head = headMatch ? headMatch[1] : '';
  const body = bodyMatch ? bodyMatch[1] : src;

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<style>${BASE_CSS}</style>
${head}
<script>window.__VFS=${vfsPayload(vfs)};</script>
<script>${BOOTSTRAP}</script>
<script>
window.__fail=function(e){
  var d=document.getElementById("__err")||document.createElement("div");
  d.id="__err"; d.textContent="⚠ "+((e&&e.message)||e);
  document.body.appendChild(d);
  window.__send&&window.__send("console",{level:"error",text:String((e&&e.stack)||e)});
};
</script>
</head>
<body>
${body}
<script>
try{
${boot.join('\n')}
}catch(e){ window.__fail(e); }
</script>
</body>
</html>`;
}

function inlineCssUrls(vfs: VFS, cssPath: string, css: string): string {
  return css.replace(/url\(\s*(["']?)([^"')]+)\1\s*\)/g, (whole, _q, ref) => {
    if (/^(https?:|data:|#)/.test(ref)) return whole;
    const target = resolvePath(cssPath, ref);
    const f = vfs.files.get(target);
    return f ? `url(${dataUrl(f)})` : whole;
  });
}

/* ------------------------------------------------------- react / RN runner */

const RN_SHIM = [
  '(function(){',
  'var R = window.React;',
  'function num(v){ return typeof v === "number" ? v + "px" : v; }',
  'var NUMERIC = ["width","height","top","left","right","bottom","margin","marginTop","marginBottom","marginLeft","marginRight","marginHorizontal","marginVertical","padding","paddingTop","paddingBottom","paddingLeft","paddingRight","paddingHorizontal","paddingVertical","borderRadius","borderWidth","borderTopWidth","borderBottomWidth","fontSize","lineHeight","letterSpacing","gap","rowGap","columnGap","minWidth","minHeight","maxWidth","maxHeight","flexBasis","borderTopLeftRadius","borderTopRightRadius","borderBottomLeftRadius","borderBottomRightRadius"];',
  'function flat(s){',
  '  if (!s) return {};',
  '  if (Array.isArray(s)) { var o = {}; for (var i=0;i<s.length;i++) Object.assign(o, flat(s[i])); return o; }',
  '  return s;',
  '}',
  'function conv(style){',
  '  var s = flat(style), out = { display: "flex", flexDirection: "column" };',
  '  for (var k in s){',
  '    var v = s[k];',
  '    if (v == null) continue;',
  '    if (k === "marginHorizontal"){ out.marginLeft = num(v); out.marginRight = num(v); continue; }',
  '    if (k === "marginVertical"){ out.marginTop = num(v); out.marginBottom = num(v); continue; }',
  '    if (k === "paddingHorizontal"){ out.paddingLeft = num(v); out.paddingRight = num(v); continue; }',
  '    if (k === "paddingVertical"){ out.paddingTop = num(v); out.paddingBottom = num(v); continue; }',
  '    if (k === "shadowColor" || k === "shadowOffset" || k === "shadowOpacity" || k === "shadowRadius"){ continue; }',
  '    if (k === "elevation"){ out.boxShadow = "0 " + (v/2) + "px " + (v*2) + "px rgba(0,0,0,0.25)"; continue; }',
  '    if (k === "transform" && Array.isArray(v)){',
  '      out.transform = v.map(function(t){ var key = Object.keys(t)[0]; var val = t[key];',
  '        if (key.indexOf("translate")===0) return key+"("+num(val)+")";',
  '        if (key.indexOf("rotate")===0) return key+"("+val+")"; return key+"("+val+")"; }).join(" ");',
  '      continue;',
  '    }',
  '    out[k] = NUMERIC.indexOf(k) >= 0 ? num(v) : v;',
  '  }',
  '  return out;',
  '}',
  'function box(tag, extra){',
  '  return R.forwardRef(function(props, ref){',
  '    var p = Object.assign({}, props);',
  '    var style = conv(p.style); delete p.style;',
  '    if (extra) style = Object.assign({}, extra, style);',
  '    var on = p.onPress; delete p.onPress;',
  '    delete p.onPressIn; delete p.onPressOut; delete p.hitSlop;',
  '    delete p.activeOpacity; delete p.underlayColor; delete p.testID;',
  '    delete p.accessibilityRole; delete p.pointerEvents; delete p.removeClippedSubviews;',
  '    var children = p.children; delete p.children;',
  '    if (typeof children === "function") children = children({ pressed: false });',
  '    if (typeof style === "object" && typeof p.style === "undefined") {}',
  '    if (on){ p.onClick = function(e){ on(e); }; style.cursor = "pointer"; style.userSelect = "none"; }',
  '    p.style = style; p.ref = ref;',
  '    return R.createElement(tag, p, children);',
  '  });',
  '}',
  'var View = box("div");',
  'var Text = box("span", { display: "inline-block", flexDirection: "row", color: "#111", fontSize: "14px" });',
  'var ScrollView = box("div", { overflow: "auto", WebkitOverflowScrolling: "touch", flex: 1 });',
  'var SafeAreaView = box("div", { flex: 1 });',
  'var Pressable = box("div");',
  'var TouchableOpacity = box("div");',
  'var TouchableHighlight = box("div");',
  'var TouchableWithoutFeedback = box("div");',
  'var KeyboardAvoidingView = box("div", { flex: 1 });',
  'var Modal = function(props){ return props.visible ? R.createElement("div", { style: { position:"fixed", inset:0, zIndex:9999, display:"flex" } }, props.children) : null; };',
  'function Image(props){',
  '  var s = conv(props.style); var src = props.source;',
  '  if (src && typeof src === "object") src = src.uri || src.default || "";',
  '  return R.createElement("img", { src: src, style: Object.assign({ objectFit: props.resizeMode === "contain" ? "contain" : "cover" }, s) });',
  '}',
  'function TextInput(props){',
  '  var s = conv(props.style);',
  '  return R.createElement("input", {',
  '    value: props.value, placeholder: props.placeholder,',
  '    onChange: function(e){ props.onChangeText && props.onChangeText(e.target.value); },',
  '    style: Object.assign({ border: "none", outline: "none", background: "transparent" }, s)',
  '  });',
  '}',
  'function Switch(props){',
  '  return R.createElement("input", { type: "checkbox", checked: !!props.value,',
  '    onChange: function(e){ props.onValueChange && props.onValueChange(e.target.checked); } });',
  '}',
  'function ActivityIndicator(props){',
  '  return R.createElement("div", { style: { width: 20, height: 20, borderRadius: "50%",',
  '    border: "2px solid " + (props.color || "#888"), borderTopColor: "transparent",',
  '    animation: "__spin 0.8s linear infinite" } });',
  '}',
  'function FlatList(props){',
  '  var data = props.data || [];',
  '  var kids = data.map(function(item, index){',
  '    var key = props.keyExtractor ? props.keyExtractor(item, index) : String(index);',
  '    return R.createElement(R.Fragment, { key: key }, props.renderItem({ item: item, index: index }));',
  '  });',
  '  return R.createElement(ScrollView, { style: props.style },',
  '    props.ListHeaderComponent || null,',
  '    kids.length ? kids : (props.ListEmptyComponent || null),',
  '    props.ListFooterComponent || null);',
  '}',
  'var SectionList = FlatList;',
  'var StyleSheet = { create: function(o){ return o; }, flatten: flat, hairlineWidth: 1,',
  '  absoluteFill: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0 },',
  '  absoluteFillObject: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0 } };',
  'var Dimensions = { get: function(){ return { width: window.innerWidth, height: window.innerHeight, scale: 1, fontScale: 1 }; }, addEventListener: function(){ return { remove: function(){} }; } };',
  'var Platform = { OS: "android", Version: 34, select: function(o){ return o.android !== undefined ? o.android : (o.native !== undefined ? o.native : o.default); } };',
  'function AnimatedValue(v){ this._v = v; }',
  'AnimatedValue.prototype.setValue = function(v){ this._v = v; };',
  'AnimatedValue.prototype.interpolate = function(){ return this; };',
  'AnimatedValue.prototype.addListener = function(){ return "0"; };',
  'AnimatedValue.prototype.removeAllListeners = function(){};',
  'var noopAnim = { start: function(cb){ cb && cb({ finished: true }); }, stop: function(){}, reset: function(){} };',
  'var Animated = { View: View, Text: Text, ScrollView: ScrollView, Image: Image,',
  '  Value: AnimatedValue, createAnimatedComponent: function(C){ return C; },',
  '  timing: function(){ return noopAnim; }, spring: function(){ return noopAnim; },',
  '  sequence: function(){ return noopAnim; }, parallel: function(){ return noopAnim; },',
  '  loop: function(){ return noopAnim; }, delay: function(){ return noopAnim; } };',
  'var Easing = new Proxy({}, { get: function(){ return function(){ return function(t){ return t; }; }; } });',
  'window.__RN = {',
  '  View: View, Text: Text, ScrollView: ScrollView, SafeAreaView: SafeAreaView,',
  '  Pressable: Pressable, TouchableOpacity: TouchableOpacity, TouchableHighlight: TouchableHighlight,',
  '  TouchableWithoutFeedback: TouchableWithoutFeedback, KeyboardAvoidingView: KeyboardAvoidingView,',
  '  Modal: Modal, Image: Image, ImageBackground: Image, TextInput: TextInput, Switch: Switch,',
  '  ActivityIndicator: ActivityIndicator, FlatList: FlatList, SectionList: SectionList,',
  '  StyleSheet: StyleSheet, Dimensions: Dimensions, Platform: Platform, Animated: Animated,',
  '  Easing: Easing, StatusBar: function(){ return null; },',
  '  Alert: { alert: function(t, m){ console.log("Alert: " + t + (m ? " — " + m : "")); } },',
  '  Linking: { openURL: function(u){ console.log("openURL " + u); return Promise.resolve(); } },',
  '  useColorScheme: function(){ return "dark"; },',
  '  useWindowDimensions: function(){ return Dimensions.get(); },',
  '  AppState: { currentState: "active", addEventListener: function(){ return { remove: function(){} }; } },',
  '  Vibration: { vibrate: function(){} }, PixelRatio: { get: function(){ return 2; }, roundToNearestPixel: function(v){ return v; } },',
  '  I18nManager: { isRTL: false }, InteractionManager: { runAfterInteractions: function(cb){ cb && cb(); } },',
  '  __conv: conv',
  '};',
  '})();',
].join('\n');

const REACT_BOOT = [
  '(function(){',
  'if (!window.process) window.process = { env: { NODE_ENV: "production" }, platform: "android" };',
  'if (!window.global) window.global = window;',
  'var cache = {};',
  'function iconStub(){',
  '  var R = window.React;',
  '  var C = function(props){',
  '    return R.createElement("span", { style: { fontSize: (props.size || 16) + "px", color: props.color || "#888", lineHeight: 1 } }, "◆");',
  '  };',
  '  C.font = {}; C.loadFont = function(){ return Promise.resolve(); };',
  '  return C;',
  '}',
  'function shimFor(name){',
  '  var R = window.React;',
  '  if (name === "react") return window.React;',
  '  if (name === "react-dom") return window.ReactDOM;',
  '  if (name === "react-dom/client") return window.ReactDOM;',
  '  if (name === "react-native" || name === "react-native-web") return window.__RN;',
  '  if (name === "react/jsx-runtime") return { jsx: R.createElement, jsxs: R.createElement, Fragment: R.Fragment };',
  '  if (name === "expo-status-bar") return { StatusBar: function(){ return null; } };',
  '  if (name === "expo-font") return { useFonts: function(){ return [true, null]; }, loadAsync: function(){ return Promise.resolve(); } };',
  '  if (name === "expo-image") return { Image: window.__RN.Image };',
  '  if (name === "expo-linear-gradient") return { LinearGradient: window.__RN.View };',
  '  if (name === "react-native-safe-area-context") return {',
  '    SafeAreaView: window.__RN.SafeAreaView, SafeAreaProvider: window.__RN.View,',
  '    useSafeAreaInsets: function(){ return { top: 0, bottom: 0, left: 0, right: 0 }; } };',
  '  if (name === "react-native-gesture-handler") return Object.assign({}, window.__RN, {',
  '    GestureHandlerRootView: window.__RN.View, gestureHandlerRootHOC: function(C){ return C; } });',
  '  if (name.indexOf("@expo/vector-icons") === 0) {',
  '    var Icon = iconStub();',
  '    return new Proxy({ default: Icon }, { get: function(t, k){ if (k === "default" || k === "__esModule") return t[k]; return Icon; } });',
  '  }',
  '  if (name === "@react-navigation/native") return {',
  '    NavigationContainer: window.__RN.View, DefaultTheme: { colors: {} }, DarkTheme: { colors: {} },',
  '    useNavigation: function(){ return { navigate: function(s){ console.log("navigate → " + s); }, goBack: function(){} }; },',
  '    useRoute: function(){ return { params: {} }; } };',
  '  if (name.indexOf("@react-navigation") === 0) {',
  '    var mk = function(){ return { Navigator: window.__RN.View, Screen: function(p){ return p.component ? window.React.createElement(p.component, {}) : null; } }; };',
  '    return { createNativeStackNavigator: mk, createBottomTabNavigator: mk, createStackNavigator: mk, createDrawerNavigator: mk };',
  '  }',
  '  if (name.indexOf("@react-native-async-storage") === 0) {',
  '    var mem = {};',
  '    var api = { getItem: function(k){ return Promise.resolve(mem[k] || null); },',
  '      setItem: function(k,v){ mem[k]=v; return Promise.resolve(); },',
  '      removeItem: function(k){ delete mem[k]; return Promise.resolve(); } };',
  '    return { default: api, __esModule: true };',
  '  }',
  '  return new Proxy({}, { get: function(t, k){',
  '    if (k === "__esModule") return true;',
  '    if (k === "default") return function(){ return null; };',
  '    return function(){ return null; }; } });',
  '}',
  'function req(from, spec){',
  '  if (spec.charAt(0) !== "." && spec.charAt(0) !== "/") return shimFor(spec);',
  '  var path = window.__vfsFind(window.__vfsResolve(from, spec));',
  '  if (!path) { console.warn("Cannot resolve " + spec + " from " + from); return {}; }',
  '  if (cache[path]) return cache[path].exports;',
  '  if (/\\.css$/.test(path)) { window.__injectCss(path); return {}; }',
  '  if (/\\.(png|jpe?g|gif|svg|webp|ttf|otf|woff2?|mp3|mp4)$/i.test(path)) return { default: window.__vfsData(path), uri: window.__vfsData(path) };',
  '  if (/\\.json$/.test(path)) { var j = {}; try { j = JSON.parse(window.__vfsText(path)); } catch(e){} cache[path] = { exports: j }; return j; }',
  '  var code = window.__vfsText(path);',
  '  var isTs = /\\.tsx?$/.test(path);',
  '  var presets = [["react", { runtime: "classic" }]];',
  '  if (isTs) presets.push(["typescript", { isTSX: /\\.tsx$/.test(path), allExtensions: true }]);',
  '  var out;',
  '  try {',
  '    out = window.Babel.transform(code, {',
  '      filename: path,',
  '      presets: presets,',
  '      plugins: [["transform-modules-commonjs", { strictNamespace: false, loose: true }]],',
  '      sourceType: "module",',
  '      compact: false',
  '    }).code;',
  '  } catch(e){ throw new Error("Compile failed in " + path + ": " + e.message); }',
  '  var mod = { exports: {} };',
  '  cache[path] = mod;',
  '  var fn = new Function("require", "module", "exports", "React", "__filename", out);',
  '  fn(function(s){ return req(path, s); }, mod, mod.exports, window.React, path);',
  '  return mod.exports;',
  '}',
  'window.__req = req;',
  'window.__runEntry = function(entry){',
  '  try {',
  '    var m = req("", "./" + entry);',
  '    var App = m.default || m.App || m;',
  '    if (typeof App !== "function") throw new Error("Entry " + entry + " has no default React component export");',
  '    var root = document.getElementById("root");',
  '    var r = window.ReactDOM.createRoot(root);',
  '    r.render(window.React.createElement(App));',
  '    window.__send && window.__send("ready", { title: entry });',
  '  } catch(e){ window.__fail(e); }',
  '};',
  '})();',
].join('\n');

export function buildReactDocument(
  vfs: VFS,
  entryPath: string,
  bg: string,
  fg = '#8FA2B8'
): string {
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<style>${BASE_CSS}
@keyframes __spin{to{transform:rotate(360deg)}}
html,body,#root{height:100%;background:${bg}}
#__boot{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:14px;background:${bg};color:${fg};font:13px system-ui;z-index:9998}
#__boot .r{width:34px;height:34px;border-radius:50%;border:3px solid #3DDC84;border-top-color:transparent;animation:__spin .8s linear infinite}
</style>
<script>window.__VFS=${vfsPayload(vfs)};</script>
<script>${BOOTSTRAP}</script>
<script>
window.__fail=function(e){
  var b=document.getElementById("__boot"); if(b) b.remove();
  var d=document.getElementById("__err")||document.createElement("div");
  d.id="__err"; d.textContent="⚠ "+((e&&e.message)||e)+"\\n\\n"+((e&&e.stack)||"");
  document.body.appendChild(d);
  window.__send&&window.__send("console",{level:"error",text:String((e&&e.message)||e)});
};
</script>
</head>
<body>
<div id="__boot"><div class="r"></div><div>compiling ${entryPath}…</div></div>
<div id="root"></div>
<script src="https://unpkg.com/react@18.3.1/umd/react.production.min.js" crossorigin></script>
<script src="https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js" crossorigin></script>
<script src="https://unpkg.com/@babel/standalone@7.25.6/babel.min.js" crossorigin></script>
<script>
(function(){
  var tries = 0;
  function go(){
    if (!window.React || !window.ReactDOM || !window.Babel) {
      if (++tries > 120) { window.__fail(new Error("Could not load React/Babel runtime — check your internet connection.")); return; }
      return setTimeout(go, 100);
    }
    try {
      ${RN_SHIM.replace(/<\/script/gi, '<\\/script')}
      ${REACT_BOOT.replace(/<\/script/gi, '<\\/script')}
      var b = document.getElementById("__boot"); if (b) b.remove();
      window.__runEntry(${JSON.stringify(entryPath)});
    } catch(e){ window.__fail(e); }
  }
  go();
})();
</script>
</body>
</html>`;
}

/* ------------------------------------------------------------ static poster */

export function buildStaticDocument(
  vfs: VFS,
  meta: { name: string; framework: string; files: number; bg: string; fg: string; accent: string },
  readmePath: string
): string {
  const readme = readmePath ? vfs.files.get(readmePath)?.text ?? '' : '';
  const html = mdToHtml(readme || '# ' + meta.name + '\n\nNo README found in this archive.');
  const tree = [...vfs.files.keys()].slice(0, 60).map((p) => `<li>${p}</li>`).join('');
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>${BASE_CSS}
body{background:${meta.bg};color:${meta.fg};padding:22px;font-size:14px;line-height:1.65}
h1,h2,h3{line-height:1.25;margin:22px 0 10px;letter-spacing:-0.01em}
h1{font-size:24px}h2{font-size:19px}h3{font-size:16px}
code{background:rgba(127,127,127,0.18);padding:2px 6px;border-radius:5px;font:12px ui-monospace,Menlo,monospace}
pre{background:rgba(127,127,127,0.13);padding:14px;border-radius:12px;overflow:auto}
pre code{background:none;padding:0}
a{color:${meta.accent}}
.badge{display:inline-block;background:${meta.accent}22;color:${meta.accent};padding:5px 11px;border-radius:999px;font-size:12px;font-weight:700;margin-right:6px}
ul.tree{font:11.5px ui-monospace,Menlo,monospace;color:#8FA2B8;columns:1;padding-left:18px}
hr{border:none;border-top:1px solid rgba(127,127,127,0.25);margin:24px 0}
</style></head>
<body>
<div><span class="badge">${meta.framework}</span><span class="badge">${meta.files} files</span></div>
${html}
<hr/>
<h3>Archive contents</h3>
<ul class="tree">${tree}</ul>
</body></html>`;
}

function mdToHtml(md: string): string {
  const escapeHtml = (s: string) =>
    s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const blocks: string[] = [];
  let out = md.replace(/```[\w]*\n([\s\S]*?)```/g, (_m, code) => {
    blocks.push(`<pre><code>${escapeHtml(code)}</code></pre>`);
    return `\u0000BLOCK${blocks.length - 1}\u0000`;
  });
  out = escapeHtml(out);
  out = out
    .replace(/^###\s+(.*)$/gm, '<h3>$1</h3>')
    .replace(/^##\s+(.*)$/gm, '<h2>$1</h2>')
    .replace(/^#\s+(.*)$/gm, '<h1>$1</h1>')
    .replace(/^\s*[-*]\s+(.*)$/gm, '<li>$1</li>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>')
    .replace(/(<li>[\s\S]*?<\/li>)(?!\s*<li>)/g, '<ul>$1</ul>')
    .replace(/^\s*\|.*\|\s*$/gm, '')
    .replace(/\n{2,}/g, '</p><p>');
  out = `<p>${out}</p>`;
  return out.replace(/\u0000BLOCK(\d+)\u0000/g, (_m, i) => blocks[Number(i)]);
}
