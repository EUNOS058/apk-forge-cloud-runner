import type { Lang } from './types';

type Dict = Record<string, { en: string; bn: string }>;

export const S: Dict = {
  appName: { en: 'APK Studio', bn: 'APK স্টুডিও' },
  tagline: {
    en: 'ZIP in · installable Android app out',
    bn: 'ZIP দিন · ইনস্টলযোগ্য অ্যাপ নিন',
  },
  tabImport: { en: 'Import', bn: 'ইমপোর্ট' },
  tabRun: { en: 'Run', bn: 'রান' },
  tabDeliver: { en: 'Get APK', bn: 'APK নিন' },
  tabProject: { en: 'Project', bn: 'প্রজেক্ট' },
  tabBuild: { en: 'Build', bn: 'বিল্ড' },
  tabBuilds: { en: 'Builds', bn: 'হিস্ট্রি' },
  tabHelp: { en: 'Help', bn: 'হেল্প' },

  chooseZip: { en: 'Choose .ZIP File from Storage', bn: 'স্টোরেজ থেকে .ZIP ফাইল বাছুন' },
  dropHint: {
    en: '6 import sources · or drag a .zip here',
    bn: '৬টি ইমপোর্ট সোর্স · অথবা .zip এখানে টেনে আনুন',
  },
  reading: { en: 'Reading archive…', bn: 'আর্কাইভ পড়া হচ্ছে…' },
  loadSample: { en: 'Load sample project', bn: 'স্যাম্পল প্রজেক্ট লোড করুন' },
  importUrl: { en: 'Import from URL', bn: 'URL থেকে ইমপোর্ট' },
  pickerFailed: { en: 'Picker did not return a file', bn: 'পিকার কোনো ফাইল দেয়নি' },
  cancelled: { en: 'Selection cancelled', bn: 'সিলেকশন বাতিল হয়েছে' },
  notZip: {
    en: 'That file is not a valid ZIP archive',
    bn: 'এই ফাইলটি সঠিক ZIP আর্কাইভ নয়',
  },
  troubleLink: { en: "Picker not opening? Fix it →", bn: 'পিকার খুলছে না? ঠিক করুন →' },
  recent: { en: 'Recent imports', bn: 'সাম্প্রতিক ইমপোর্ট' },
  noRecent: { en: 'No projects imported yet', bn: 'এখনো কোনো প্রজেক্ট ইমপোর্ট হয়নি' },
  files: { en: 'files', bn: 'ফাইল' },
  openProject: { en: 'Open project', bn: 'প্রজেক্ট খুলুন' },
  delete: { en: 'Delete', bn: 'ডিলিট' },

  noProject: { en: 'No project loaded', bn: 'কোনো প্রজেক্ট লোড করা নেই' },
  noProjectHint: {
    en: 'Import a .zip archive to explore its files.',
    bn: 'ফাইল দেখতে একটি .zip আর্কাইভ ইমপোর্ট করুন।',
  },
  goImport: { en: 'Go to Import', bn: 'ইমপোর্টে যান' },
  searchFiles: { en: 'Search files…', bn: 'ফাইল খুঁজুন…' },
  buildApk: { en: 'Build APK', bn: 'APK বিল্ড করুন' },
  entriesEmpty: { en: 'This folder is empty', bn: 'এই ফোল্ডারটি খালি' },
  binaryFile: { en: 'Binary file — preview unavailable', bn: 'বাইনারি ফাইল — প্রিভিউ নেই' },
  notCached: {
    en: 'Content not cached. Re-import the ZIP to view it.',
    bn: 'কনটেন্ট সেভ নেই। দেখতে ZIP আবার ইমপোর্ট করুন।',
  },
  wrap: { en: 'Wrap', bn: 'র‍্যাপ' },

  config: { en: 'Build configuration', bn: 'বিল্ড কনফিগারেশন' },
  appLabel: { en: 'App name', bn: 'অ্যাপের নাম' },
  packageId: { en: 'Package ID', bn: 'প্যাকেজ আইডি' },
  version: { en: 'Version', bn: 'ভার্সন' },
  versionCode: { en: 'Version code', bn: 'ভার্সন কোড' },
  buildType: { en: 'Build type', bn: 'বিল্ড টাইপ' },
  outputFmt: { en: 'Output', bn: 'আউটপুট' },
  minSdk: { en: 'Minimum SDK', bn: 'মিনিমাম SDK' },
  orientation: { en: 'Orientation', bn: 'ওরিয়েন্টেশন' },
  permissions: { en: 'Permissions', bn: 'পারমিশন' },
  extras: { en: 'Extras', bn: 'অতিরিক্ত' },
  offline: { en: 'Offline asset cache', bn: 'অফলাইন অ্যাসেট ক্যাশ' },
  splash: { en: 'Generate splash screen', bn: 'স্প্ল্যাশ স্ক্রিন তৈরি' },
  startBuild: { en: 'Start build', bn: 'বিল্ড শুরু করুন' },
  cancelBuild: { en: 'Cancel build', bn: 'বিল্ড বাতিল' },
  building: { en: 'Building…', bn: 'বিল্ড হচ্ছে…' },
  buildLog: { en: 'Build log', bn: 'বিল্ড লগ' },
  artifact: { en: 'Artifact', bn: 'আর্টিফ্যাক্ট' },
  download: { en: 'Export project', bn: 'প্রজেক্ট এক্সপোর্ট' },
  installGuide: { en: 'Install guide', bn: 'ইনস্টল গাইড' },
  buildSuccess: { en: 'Build succeeded', bn: 'বিল্ড সফল হয়েছে' },
  buildFailed: { en: 'Build failed', bn: 'বিল্ড ব্যর্থ' },
  invalidPkg: {
    en: 'Package ID must look like com.company.app',
    bn: 'প্যাকেজ আইডি হতে হবে com.company.app এর মতো',
  },
  needProject: { en: 'Import a project first', bn: 'আগে একটি প্রজেক্ট ইমপোর্ট করুন' },

  noBuilds: { en: 'No builds yet', bn: 'এখনো কোনো বিল্ড হয়নি' },
  noBuildsHint: {
    en: 'Your finished builds will appear here.',
    bn: 'শেষ হওয়া বিল্ডগুলো এখানে দেখা যাবে।',
  },
  clearBuilds: { en: 'Clear history', bn: 'হিস্ট্রি মুছুন' },

  diagnostics: { en: 'Storage & picker diagnostics', bn: 'স্টোরেজ ও পিকার ডায়াগনস্টিকস' },
  runDiag: { en: 'Run diagnostics', bn: 'ডায়াগনস্টিক চালান' },
  troubleshoot: { en: 'Troubleshooting', bn: 'সমস্যা সমাধান' },
  appearance: { en: 'Appearance', bn: 'অ্যাপিয়ারেন্স' },
  language: { en: 'Language', bn: 'ভাষা' },
  theme: { en: 'Theme', bn: 'থিম' },
  darkT: { en: 'Dark', bn: 'ডার্ক' },
  lightT: { en: 'Light', bn: 'লাইট' },
  about: { en: 'About', bn: 'পরিচিতি' },
  retryPicker: { en: 'Open picker again', bn: 'আবার পিকার খুলুন' },
  close: { en: 'Close', bn: 'বন্ধ' },
  copyCmd: { en: 'Build command', bn: 'বিল্ড কমান্ড' },
};

export function makeT(lang: Lang) {
  return (key: keyof typeof S | string): string => {
    const entry = S[key as string];
    if (!entry) return String(key);
    return lang === 'bn' ? entry.bn : entry.en;
  };
}

export const HELP_TOPICS: {
  icon: string;
  title: { en: string; bn: string };
  body: { en: string[]; bn: string[] };
}[] = [
  {
    icon: 'download-outline',
    title: {
      en: 'I just want the .apk file — where is it?',
      bn: 'আমি শুধু .apk ফাইলটা চাই — সেটা কোথায়?',
    },
    body: {
      en: [
        'Open the "Get APK" tab. It gives four real delivery routes and every file each one needs is already generated for you.',
        'Fastest with zero tools: route 4. The export is a valid PWA — drop the folder on app.netlify.com/drop, open the link in Chrome on Android, tap "Install app". Android compiles a genuine signed WebAPK on the device with its own launcher icon.',
        'Fastest real .apk file: route 1. Upload the export to a GitHub repo — the included workflow builds and hands you a downloadable .apk in about 8 minutes, completely free.',
        'A phone cannot compile an APK by itself: Gradle, a JDK and the Android SDK are required and none of them exist inside an app. That is why the work is handed to a build machine.',
      ],
      bn: [
        '"APK নিন" ট্যাবটি খুলুন। সেখানে চারটি বাস্তব পথ আছে এবং প্রতিটির জন্য দরকারি সব ফাইল আগেই তৈরি করা আছে।',
        'কোনো টুল ছাড়া সবচেয়ে দ্রুত: ৪ নম্বর পথ। এক্সপোর্টটি একটি বৈধ PWA — ফোল্ডারটি app.netlify.com/drop-এ ফেলুন, Android Chrome-এ লিংক খুলে "Install app" চাপুন। Android ফোনেই আসল সাইন করা WebAPK বানায়, নিজস্ব আইকনসহ।',
        'সত্যিকারের .apk ফাইল দ্রুত পেতে: ১ নম্বর পথ। এক্সপোর্টটি GitHub রিপোতে আপলোড করুন — সঙ্গে থাকা ওয়ার্কফ্লো প্রায় ৮ মিনিটে ডাউনলোডযোগ্য .apk দেবে, একদম ফ্রি।',
        'ফোন নিজে APK কম্পাইল করতে পারে না: Gradle, JDK ও Android SDK লাগে, যেগুলো কোনো অ্যাপের ভেতরে থাকে না। তাই কাজটি একটি বিল্ড মেশিনে পাঠানো হয়।',
      ],
    },
  },
  {
    icon: 'play-circle-outline',
    title: {
      en: 'The export did not open my app / game',
      bn: 'এক্সপোর্ট করা ফাইল আমার অ্যাপ/খেলায় নিয়ে যাচ্ছে না',
    },
    body: {
      en: [
        'Use the Run tab first — your project runs live inside the app, no build needed. HTML/CSS/JS games start instantly; React and React Native entries are compiled on the fly.',
        'The export is a *source project*, not a finished binary. Android cannot install a .zip — you must run build-apk.sh (included) or eas build to get the .apk.',
        'Every original file is now preserved byte-for-byte. Earlier versions replaced App.tsx with a stub — that is fixed, your entry point is never overwritten.',
        'Pick “Original source only” in the export sheet if you just want your files back exactly as they were.',
      ],
      bn: [
        'আগে Run ট্যাব ব্যবহার করুন — বিল্ড ছাড়াই প্রজেক্ট অ্যাপের ভেতরেই চলবে। HTML/CSS/JS খেলা সঙ্গে সঙ্গে চালু হয়; React ও React Native এন্ট্রি সরাসরি কম্পাইল হয়।',
        'এক্সপোর্ট একটি *সোর্স প্রজেক্ট*, তৈরি বাইনারি নয়। Android .zip ইনস্টল করতে পারে না — .apk পেতে সঙ্গে দেওয়া build-apk.sh বা eas build চালাতে হবে।',
        'এখন আপনার প্রতিটি আসল ফাইল হুবহু সংরক্ষিত থাকে। আগের ভার্সন App.tsx মুছে স্টাব বসাত — সেটি ঠিক করা হয়েছে, এন্ট্রি পয়েন্ট আর কখনো বদলাবে না।',
        'শুধু নিজের ফাইলগুলো ফেরত চাইলে এক্সপোর্ট শিটে “শুধু আসল সোর্স” বেছে নিন।',
      ],
    },
  },
  {
    icon: 'folder-open-outline',
    title: {
      en: "'Choose .ZIP from Storage' does nothing",
      bn: "'Choose .ZIP File from Storage' কাজ করছে না",
    },
    body: {
      en: [
        'The button now opens a sheet with six separate routes. If one is blocked by the OS, the next one uses a different API — try them top to bottom.',
        '“Show every file type” uses the */* filter, which makes greyed-out ZIPs selectable on Xiaomi, Oppo and Samsung file pickers.',
        '“Pick a whole folder” grants access to an entire directory (Android SAF) and then lists every .zip inside it for you — the most reliable route.',
        'If nothing opens at all, storage permission is off: Settings → Apps → APK Studio → Permissions → Files and media → Allow.',
      ],
      bn: [
        'বাটনটি এখন ছয়টি আলাদা পথের শিট খোলে। একটি OS ব্লক করলে পরেরটি ভিন্ন API ব্যবহার করে — উপর থেকে নিচে চেষ্টা করুন।',
        '“সব ফাইল টাইপ দেখান” অপশনটি */* ফিল্টার দেয়, ফলে Xiaomi, Oppo ও Samsung পিকারে ধূসর দেখানো ZIP-ও বেছে নেওয়া যায়।',
        '“পুরো ফোল্ডার বাছুন” একটি ডিরেক্টরির অনুমতি নেয় (Android SAF) এবং ভেতরের সব .zip তালিকা করে দেখায় — এটিই সবচেয়ে নির্ভরযোগ্য।',
        'একদমই কিছু না খুললে স্টোরেজ পারমিশন বন্ধ: Settings → Apps → APK Studio → Permissions → Files and media → Allow করুন।',
      ],
    },
  },
  {
    icon: 'images-outline',
    title: {
      en: 'Gallery opens but no ZIP is visible',
      bn: 'গ্যালারি খুলছে কিন্তু ZIP দেখা যাচ্ছে না',
    },
    body: {
      en: [
        'Gallery apps index photos and videos only — an archive is never listed there, no matter what you do.',
        'The Gallery option is still provided so you can confirm this yourself; if you pick a photo the app tells you it is not a ZIP instead of failing silently.',
        'Use “Storage / File manager” or “Pick a whole folder” instead — those read real documents.',
        'Move the archive to Internal storage → Download and it will show up immediately.',
      ],
      bn: [
        'গ্যালারি অ্যাপ শুধু ছবি ও ভিডিও ইনডেক্স করে — যা-ই করুন, আর্কাইভ সেখানে দেখাবে না।',
        'তবু গ্যালারি অপশনটি রাখা হয়েছে যাতে নিজে যাচাই করতে পারেন; ছবি বাছলে অ্যাপ চুপ করে ফেল না করে পরিষ্কার বলে দেবে এটি ZIP নয়।',
        'এর বদলে “স্টোরেজ / ফাইল ম্যানেজার” বা “পুরো ফোল্ডার বাছুন” ব্যবহার করুন — এগুলো আসল ডকুমেন্ট পড়ে।',
        'আর্কাইভটি Internal storage → Download ফোল্ডারে সরালে সঙ্গে সঙ্গে দেখা যাবে।',
      ],
    },
  },
  {
    icon: 'cloud-download-outline',
    title: { en: 'Download / export is not working', bn: 'ডাউনলোড বা এক্সপোর্ট হচ্ছে না' },
    body: {
      en: [
        'On Android the export now asks you to choose a folder (Storage Access Framework) and writes the file straight into it — choose Download and it really lands there.',
        'If you cancel the folder dialog, the app falls back to the share sheet: pick “Save to Files”, “Drive” or any app.',
        'In the web preview the browser download bar may be suppressed — allow downloads for this site and retry.',
        'A build must finish successfully before the export button becomes active, and at least 200 MB of free space is needed.',
      ],
      bn: [
        'Android-এ এক্সপোর্ট এখন ফোল্ডার বাছতে বলে (Storage Access Framework) এবং সরাসরি সেখানেই ফাইল লেখে — Download বাছলে সত্যিই সেখানে যায়।',
        'ফোল্ডার ডায়ালগ বাতিল করলে অ্যাপ শেয়ার শিটে ফিরে যায়: “Save to Files”, “Drive” বা যেকোনো অ্যাপ বাছুন।',
        'ওয়েব প্রিভিউতে ব্রাউজার ডাউনলোড আটকাতে পারে — এই সাইটের জন্য ডাউনলোড Allow করে আবার চেষ্টা করুন।',
        'এক্সপোর্ট বাটন সক্রিয় হতে বিল্ড সফলভাবে শেষ হতে হবে, আর অন্তত ২০০ MB জায়গা খালি লাগবে।',
      ],
    },
  },
  {
    icon: 'shield-checkmark-outline',
    title: { en: 'APK will not install on the phone', bn: 'ফোনে APK ইনস্টল হচ্ছে না' },
    body: {
      en: [
        'Enable Settings → Security → Install unknown apps for your file manager or browser.',
        'Uninstall any older copy that was signed with a different key.',
        'Check that Minimum SDK is not higher than your Android version.',
        'Use the APK output (not AAB) for direct sideloading; AAB is only for Play Store uploads.',
      ],
      bn: [
        'Settings → Security → Install unknown apps থেকে আপনার ফাইল ম্যানেজার/ব্রাউজারকে অনুমতি দিন।',
        'ভিন্ন কী দিয়ে সাইন করা পুরনো কপি থাকলে সেটি আনইনস্টল করুন।',
        'Minimum SDK আপনার Android ভার্সনের চেয়ে বেশি কিনা দেখুন।',
        'সরাসরি ইনস্টলের জন্য APK আউটপুট নিন; AAB শুধু Play Store আপলোডের জন্য।',
      ],
    },
  },
  {
    icon: 'construct-outline',
    title: { en: 'Build failed midway', bn: 'বিল্ড মাঝপথে ফেল করেছে' },
    body: {
      en: [
        'Open the failed build from the Builds tab and read the last red log line.',
        'A missing package.json or index.html means the archive root is wrong — re-zip without the extra outer folder.',
        'Package ID must be lowercase and contain at least two dots-separated segments.',
        'Re-run the build; transient dependency downloads sometimes fail once.',
      ],
      bn: [
        'Builds ট্যাব থেকে ফেল হওয়া বিল্ড খুলে শেষ লাল লগ লাইনটি পড়ুন।',
        'package.json বা index.html না থাকলে আর্কাইভের রুট ভুল — বাড়তি বাইরের ফোল্ডার বাদ দিয়ে আবার zip করুন।',
        'প্যাকেজ আইডি ছোট হাতের হতে হবে এবং অন্তত দুটি ডট-সেপারেটেড অংশ থাকতে হবে।',
        'আবার বিল্ড দিন; মাঝে মাঝে ডিপেন্ডেন্সি ডাউনলোড একবার ফেল করে।',
      ],
    },
  },
];
