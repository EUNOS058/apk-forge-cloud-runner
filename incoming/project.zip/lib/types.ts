export type ZipEntry = {
  path: string;
  name: string;
  dir: boolean;
  size: number;
  ext: string;
};

export type PickedFile = {
  name: string;
  size: number;
  uri: string;
  bytes: Uint8Array | null;
};

export type FrameworkId =
  | 'react-native'
  | 'expo'
  | 'react'
  | 'nextjs'
  | 'vue'
  | 'angular'
  | 'flutter'
  | 'static'
  | 'node'
  | 'unknown';

export type Framework = {
  id: FrameworkId;
  label: string;
  mode: 'native' | 'webview' | 'hybrid';
  icon: string;
  color: string;
};

export type Project = {
  id: string;
  name: string;
  fileName: string;
  sizeBytes: number;
  importedAt: number;
  entries: ZipEntry[];
  contents: Record<string, string>;
  truncated: boolean;
  framework: Framework;
  source: 'storage' | 'sample' | 'url';
};

export type BuildConfig = {
  appName: string;
  packageId: string;
  version: string;
  versionCode: number;
  buildType: 'release' | 'debug';
  output: 'apk' | 'aab';
  minSdk: number;
  orientation: 'portrait' | 'landscape' | 'auto';
  permissions: string[];
  offlineCache: boolean;
  splashScreen: boolean;
};

export type LogLine = {
  t: number;
  text: string;
  level: 'info' | 'ok' | 'warn' | 'err' | 'cmd';
};

export type BuildStepState = 'pending' | 'running' | 'done' | 'failed';

export type BuildStep = {
  key: string;
  label: string;
  labelBn: string;
  state: BuildStepState;
  ms: number;
};

export type BuildRecord = {
  id: string;
  projectId: string;
  projectName: string;
  config: BuildConfig;
  status: 'success' | 'failed' | 'cancelled' | 'running';
  startedAt: number;
  durationMs: number;
  artifactName: string;
  artifactSize: number;
  checksum: string;
  logs: LogLine[];
  steps: BuildStep[];
};

export type Lang = 'bn' | 'en';
export type Mode = 'dark' | 'light';
