import { Platform } from 'react-native';
import JSZip from 'jszip';
import type { Framework, Project, ZipEntry } from './types';
import { buildVFS, extname, VFS } from './vfs';
import { base64ToBytes, isZipBytes, PickedFile } from './pick';

export { base64ToBytes, isZipBytes };

/* ------------------------------------------------------------------ format */

export function formatBytes(n: number): string {
  if (!n || n < 0) return '0 B';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(2)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

export function timeAgo(ts: number, lang: 'bn' | 'en' = 'en'): string {
  const s = Math.max(1, Math.floor((Date.now() - ts) / 1000));
  const u =
    lang === 'bn'
      ? { s: 'সেকেন্ড আগে', m: 'মিনিট আগে', h: 'ঘণ্টা আগে', d: 'দিন আগে' }
      : { s: 's ago', m: 'm ago', h: 'h ago', d: 'd ago' };
  const sep = lang === 'bn' ? ' ' : '';
  if (s < 60) return `${s}${sep}${u.s}`;
  if (s < 3600) return `${Math.floor(s / 60)}${sep}${u.m}`;
  if (s < 86400) return `${Math.floor(s / 3600)}${sep}${u.h}`;
  return `${Math.floor(s / 86400)}${sep}${u.d}`;
}

export function shortHash(input: string, len = 40): string {
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < input.length; i++) {
    const c = input.charCodeAt(i);
    h1 = (h1 ^ c) >>> 0;
    h1 = (h1 * 16777619) >>> 0;
    h2 = (h2 + c * (i + 7)) >>> 0;
    h2 = (h2 ^ (h2 << 5)) >>> 0;
  }
  let out = '';
  let seed = (h1 ^ h2) >>> 0;
  while (out.length < len) {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    out += seed.toString(16).padStart(8, '0');
  }
  return out.slice(0, len);
}

export const extOf = extname;

export function sanitizeName(raw: string): string {
  return (
    raw
      .replace(/\.zip$/i, '')
      .replace(/[_-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .replace(/\b\w/g, (c) => c.toUpperCase())
      .slice(0, 40) || 'My App'
  );
}

export function toPackageId(name: string): string {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '')
    .slice(0, 18);
  return `com.apkstudio.${slug || 'app'}`;
}

export function iconForEntry(entry: { dir: boolean; name: string }): string {
  if (entry.dir) return 'folder';
  const e = extname(entry.name);
  if (['js', 'jsx', 'ts', 'tsx', 'vue', 'svelte'].includes(e)) return 'logo-javascript';
  if (['json', 'lock', 'yml', 'yaml', 'toml'].includes(e)) return 'options-outline';
  if (['html', 'htm'].includes(e)) return 'globe-outline';
  if (['css', 'scss', 'sass', 'less'].includes(e)) return 'color-palette-outline';
  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico'].includes(e)) return 'image-outline';
  if (['md', 'markdown', 'txt'].includes(e)) return 'document-text-outline';
  if (['ttf', 'otf', 'woff', 'woff2'].includes(e)) return 'text-outline';
  if (['mp4', 'mov', 'webm'].includes(e)) return 'videocam-outline';
  if (['mp3', 'wav', 'ogg'].includes(e)) return 'musical-notes-outline';
  if (['zip', 'gz', 'tar', 'rar'].includes(e)) return 'archive-outline';
  return 'document-outline';
}

export function isTextFile(name: string): boolean {
  const e = extname(name);
  if (!e) return /^(license|readme|makefile|dockerfile|procfile)$/i.test(name);
  return new Set([
    'js', 'jsx', 'ts', 'tsx', 'json', 'html', 'htm', 'css', 'scss', 'sass', 'less',
    'md', 'markdown', 'txt', 'xml', 'svg', 'yml', 'yaml', 'gradle', 'properties',
    'kt', 'java', 'py', 'rb', 'php', 'sh', 'env', 'gitignore', 'lock', 'toml',
    'ini', 'cfg', 'vue', 'svelte', 'dart', 'c', 'cpp', 'h', 'graphql', 'sql', 'csv',
  ]).has(e);
}

/* -------------------------------------------------------------- frameworks */

export const FRAMEWORKS: Record<string, Framework> = {
  'react-native': { id: 'react-native', label: 'React Native', mode: 'native', icon: 'phone-portrait-outline', color: '#61DAFB' },
  expo: { id: 'expo', label: 'Expo', mode: 'native', icon: 'rocket-outline', color: '#8B7BFF' },
  react: { id: 'react', label: 'React web', mode: 'webview', icon: 'logo-react', color: '#61DAFB' },
  nextjs: { id: 'nextjs', label: 'Next.js', mode: 'webview', icon: 'layers-outline', color: '#E8EFF7' },
  vue: { id: 'vue', label: 'Vue', mode: 'webview', icon: 'logo-vue', color: '#42D392' },
  angular: { id: 'angular', label: 'Angular', mode: 'webview', icon: 'logo-angular', color: '#FF5F6D' },
  flutter: { id: 'flutter', label: 'Flutter', mode: 'hybrid', icon: 'water-outline', color: '#54C5F8' },
  static: { id: 'static', label: 'Static HTML', mode: 'webview', icon: 'globe-outline', color: '#FFB020' },
  node: { id: 'node', label: 'Node service', mode: 'hybrid', icon: 'server-outline', color: '#3DDC84' },
  unknown: { id: 'unknown', label: 'Generic bundle', mode: 'webview', icon: 'cube-outline', color: '#93A2B5' },
};

export function detectFramework(vfs: VFS): Framework {
  const has = (p: string) => vfs.files.has(p);
  const any = (re: RegExp) => [...vfs.files.keys()].some((p) => re.test(p));

  let deps: Record<string, string> = {};
  const pkg = vfs.files.get('package.json');
  if (pkg?.text) {
    try {
      const parsed = JSON.parse(pkg.text);
      deps = { ...(parsed.dependencies || {}), ...(parsed.devDependencies || {}) };
    } catch {
      /* malformed */
    }
  }
  if (deps.expo) return FRAMEWORKS.expo;
  if (deps['react-native']) return FRAMEWORKS['react-native'];
  if (deps.next) return FRAMEWORKS.nextjs;
  if (deps.vue || any(/\.vue$/)) return FRAMEWORKS.vue;
  if (deps['@angular/core']) return FRAMEWORKS.angular;
  if (deps.react) return FRAMEWORKS.react;
  if (has('pubspec.yaml') || any(/\.dart$/)) return FRAMEWORKS.flutter;
  if (pkg && (deps.express || deps.fastify || deps.koa)) return FRAMEWORKS.node;
  if (any(/(^|\/)index\.html$/)) return FRAMEWORKS.static;
  if (pkg) return FRAMEWORKS.node;
  return FRAMEWORKS.unknown;
}

/* ---------------------------------------------------------------- ingestion */

const PREVIEW_LIMIT = 120 * 1024;

export async function ingest(file: PickedFile): Promise<{ project: Project; vfs: VFS }> {
  const vfs = await buildVFS(file.bytes);

  const entries: ZipEntry[] = [];
  const dirs = new Set<string>();
  vfs.files.forEach((f, p) => {
    entries.push({ path: p, name: f.name, dir: false, size: f.size, ext: f.ext });
    const parts = p.split('/');
    parts.pop();
    let acc = '';
    for (const d of parts) {
      acc = acc ? `${acc}/${d}` : d;
      dirs.add(acc);
    }
  });
  dirs.forEach((d) =>
    entries.push({ path: d, name: d.split('/').pop() || d, dir: true, size: 0, ext: '' })
  );
  entries.sort((a, b) => a.path.localeCompare(b.path));

  const contents: Record<string, string> = {};
  vfs.files.forEach((f, p) => {
    if (f.text != null) {
      contents[p] =
        f.text.length > PREVIEW_LIMIT ? `${f.text.slice(0, PREVIEW_LIMIT)}\n\n…truncated…` : f.text;
    }
  });

  const framework = detectFramework(vfs);
  const project: Project = {
    id: `p_${Date.now().toString(36)}_${Math.floor(Math.random() * 1e4)}`,
    name: sanitizeName(file.name),
    fileName: file.name,
    sizeBytes: file.size || file.bytes.length,
    importedAt: Date.now(),
    entries,
    contents,
    truncated: false,
    framework,
    source: file.source === 'url' ? 'url' : file.source === 'sample' ? 'sample' : 'storage',
  };
  return { project, vfs };
}

export function findEntryPoint(project: Project): string {
  const candidates = [
    'index.html', 'public/index.html', 'src/index.html', 'dist/index.html',
    'App.tsx', 'App.js', 'src/App.tsx', 'src/main.tsx', 'src/main.js', 'index.js',
  ];
  const paths = project.entries.filter((e) => !e.dir).map((e) => e.path);
  for (const c of candidates) if (paths.includes(c)) return c;
  return paths.find((p) => /\.(html|tsx?|jsx?)$/i.test(p)) || paths[0] || 'index.html';
}

/* ----------------------------------------------------------- diagnostics */

export type DiagCheck = {
  key: string;
  label: { en: string; bn: string };
  status: 'ok' | 'warn' | 'fail';
  detail: string;
};

export async function runDiagnostics(): Promise<DiagCheck[]> {
  const out: DiagCheck[] = [];

  out.push({
    key: 'platform',
    label: { en: 'Runtime platform', bn: 'রানটাইম প্ল্যাটফর্ম' },
    status: 'ok',
    detail: `${Platform.OS} · ${String(Platform.Version ?? 'web')}`,
  });

  try {
    if (Platform.OS === 'web') {
      const okDom = typeof (globalThis as any).document?.createElement === 'function';
      out.push({
        key: 'picker',
        label: { en: 'File chooser', bn: 'ফাইল চুজার' },
        status: okDom ? 'ok' : 'fail',
        detail: okDom ? 'HTML input[type=file] ready' : 'DOM unavailable',
      });
    } else {
      const dp: any = require('expo-document-picker');
      const ok = typeof dp?.getDocumentAsync === 'function';
      out.push({
        key: 'picker',
        label: { en: 'Storage document picker', bn: 'স্টোরেজ ডকুমেন্ট পিকার' },
        status: ok ? 'ok' : 'fail',
        detail: ok ? 'expo-document-picker linked (zip + */*)' : 'Module missing — rebuild the app',
      });
    }
  } catch (e: any) {
    out.push({
      key: 'picker',
      label: { en: 'Storage document picker', bn: 'স্টোরেজ ডকুমেন্ট পিকার' },
      status: 'fail',
      detail: String(e?.message || e),
    });
  }

  try {
    if (Platform.OS === 'web') {
      out.push({
        key: 'gallery',
        label: { en: 'Gallery access', bn: 'গ্যালারি অ্যাক্সেস' },
        status: 'warn',
        detail: 'Browser uses the same file dialog',
      });
    } else {
      const ip: any = require('expo-image-picker');
      const ok = typeof ip?.launchImageLibraryAsync === 'function';
      out.push({
        key: 'gallery',
        label: { en: 'Gallery / media library', bn: 'গ্যালারি / মিডিয়া লাইব্রেরি' },
        status: ok ? 'ok' : 'fail',
        detail: ok ? 'expo-image-picker linked' : 'Module missing',
      });
    }
  } catch (e: any) {
    out.push({
      key: 'gallery',
      label: { en: 'Gallery / media library', bn: 'গ্যালারি / মিডিয়া লাইব্রেরি' },
      status: 'warn',
      detail: String(e?.message || e),
    });
  }

  try {
    const probe = new JSZip();
    probe.file('probe.txt', 'apk-studio');
    probe.file('bin.dat', new Uint8Array([0, 1, 2, 250]));
    const bytes = await probe.generateAsync({ type: 'uint8array' });
    const back = await JSZip.loadAsync(bytes);
    const text = await back.file('probe.txt')!.async('string');
    const bin = await back.file('bin.dat')!.async('uint8array');
    const ok = text === 'apk-studio' && bin[3] === 250;
    out.push({
      key: 'zip',
      label: { en: 'ZIP engine (text + binary)', bn: 'ZIP ইঞ্জিন (টেক্সট + বাইনারি)' },
      status: ok ? 'ok' : 'fail',
      detail: ok ? `round-trip verified (${bytes.length} B)` : 'payload mismatch',
    });
  } catch (e: any) {
    out.push({
      key: 'zip',
      label: { en: 'ZIP engine (text + binary)', bn: 'ZIP ইঞ্জিন (টেক্সট + বাইনারি)' },
      status: 'fail',
      detail: String(e?.message || e),
    });
  }

  try {
    if (Platform.OS === 'web') {
      const ok = typeof (globalThis as any).URL?.createObjectURL === 'function';
      out.push({
        key: 'write',
        label: { en: 'Download capability', bn: 'ডাউনলোড সক্ষমতা' },
        status: ok ? 'ok' : 'warn',
        detail: ok ? 'Blob download supported' : 'Blob URLs blocked by browser',
      });
    } else {
      const legacy: any = require('expo-file-system/legacy');
      const saf = !!legacy?.StorageAccessFramework?.requestDirectoryPermissionsAsync;
      out.push({
        key: 'write',
        label: { en: 'Save to Downloads (SAF)', bn: 'ডাউনলোডে সেভ (SAF)' },
        status: saf ? 'ok' : 'warn',
        detail: saf ? 'StorageAccessFramework available' : 'Falls back to the share sheet',
      });
    }
  } catch (e: any) {
    out.push({
      key: 'write',
      label: { en: 'Save to Downloads (SAF)', bn: 'ডাউনলোডে সেভ (SAF)' },
      status: 'warn',
      detail: String(e?.message || e),
    });
  }

  try {
    const wv = Platform.OS === 'web' ? true : !!require('react-native-webview')?.WebView;
    out.push({
      key: 'runner',
      label: { en: 'Live preview engine', bn: 'লাইভ প্রিভিউ ইঞ্জিন' },
      status: wv ? 'ok' : 'fail',
      detail: Platform.OS === 'web' ? 'sandboxed iframe' : 'react-native-webview linked',
    });
  } catch (e: any) {
    out.push({
      key: 'runner',
      label: { en: 'Live preview engine', bn: 'লাইভ প্রিভিউ ইঞ্জিন' },
      status: 'fail',
      detail: String(e?.message || e),
    });
  }

  return out;
}
