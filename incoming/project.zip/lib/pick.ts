import { Platform } from 'react-native';

export type PickedFile = {
  name: string;
  size: number;
  uri: string;
  bytes: Uint8Array;
  source: SourceId;
};

export type SourceId = 'storage' | 'anyfile' | 'gallery' | 'folder' | 'url' | 'sample';

export type PickResult =
  | { ok: true; file: PickedFile }
  | { ok: false; reason: 'cancelled' | 'error' | 'invalid' | 'unavailable'; message?: string };

export const SOURCES: {
  id: SourceId;
  icon: string;
  title: { en: string; bn: string };
  sub: { en: string; bn: string };
  tint: 'accent' | 'violet' | 'warn';
}[] = [
  {
    id: 'storage',
    icon: 'folder-open',
    title: { en: 'Storage / File manager', bn: 'স্টোরেজ / ফাইল ম্যানেজার' },
    sub: { en: 'Documents browser · ZIP filter', bn: 'ডকুমেন্ট ব্রাউজার · ZIP ফিল্টার' },
    tint: 'accent',
  },
  {
    id: 'anyfile',
    icon: 'documents',
    title: { en: 'Show every file type', bn: 'সব ফাইল টাইপ দেখান' },
    sub: {
      en: 'Use when the ZIP looks greyed out',
      bn: 'ZIP ধূসর দেখালে এটি ব্যবহার করুন',
    },
    tint: 'violet',
  },
  {
    id: 'gallery',
    icon: 'images',
    title: { en: 'Gallery / Media', bn: 'গ্যালারি / মিডিয়া' },
    sub: {
      en: 'Photos app — archives are usually hidden here',
      bn: 'ফটো অ্যাপ — এখানে সাধারণত আর্কাইভ থাকে না',
    },
    tint: 'warn',
  },
  {
    id: 'folder',
    icon: 'file-tray-full',
    title: { en: 'Pick a whole folder', bn: 'পুরো ফোল্ডার বাছুন' },
    sub: { en: 'Android SAF · lists every ZIP inside', bn: 'Android SAF · ভেতরের সব ZIP দেখাবে' },
    tint: 'accent',
  },
  {
    id: 'url',
    icon: 'link',
    title: { en: 'Download from a link', bn: 'লিংক থেকে ডাউনলোড' },
    sub: { en: 'Direct .zip or GitHub archive URL', bn: 'সরাসরি .zip বা GitHub লিংক' },
    tint: 'violet',
  },
  {
    id: 'sample',
    icon: 'sparkles',
    title: { en: 'Load the demo project', bn: 'ডেমো প্রজেক্ট লোড করুন' },
    sub: { en: 'Runnable example — try it instantly', bn: 'চালানো যায় এমন উদাহরণ' },
    tint: 'warn',
  },
];

/* ----------------------------------------------------------------- helpers */

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

export function base64ToBytes(b64: string): Uint8Array {
  const clean = b64.replace(/[^A-Za-z0-9+/=]/g, '');
  const len = clean.length;
  let bufLen = (len * 3) / 4;
  if (clean[len - 1] === '=') bufLen--;
  if (clean[len - 2] === '=') bufLen--;
  const bytes = new Uint8Array(bufLen);
  let p = 0;
  for (let i = 0; i < len; i += 4) {
    const e1 = B64.indexOf(clean[i]);
    const e2 = B64.indexOf(clean[i + 1]);
    const e3 = B64.indexOf(clean[i + 2]);
    const e4 = B64.indexOf(clean[i + 3]);
    if (p < bufLen) bytes[p++] = (e1 << 2) | (e2 >> 4);
    if (e3 !== -1 && p < bufLen) bytes[p++] = ((e2 & 15) << 4) | (e3 >> 2);
    if (e4 !== -1 && p < bufLen) bytes[p++] = ((e3 & 3) << 6) | e4;
  }
  return bytes;
}

export function isZipBytes(b: Uint8Array | null): boolean {
  if (!b || b.length < 4) return false;
  return b[0] === 0x50 && b[1] === 0x4b && (b[2] === 3 || b[2] === 5 || b[2] === 7);
}

async function readUriBytes(uri: string): Promise<Uint8Array> {
  try {
    const FS: any = require('expo-file-system');
    if (FS?.File) {
      const f = new FS.File(uri);
      if (typeof f.bytes === 'function') {
        const b = await f.bytes();
        if (b) return b as Uint8Array;
      }
      if (typeof f.base64 === 'function') {
        const b64 = await f.base64();
        if (b64) return base64ToBytes(b64);
      }
    }
  } catch {
    /* fall through */
  }
  const legacy: any = require('expo-file-system/legacy');
  const b64 = await legacy.readAsStringAsync(uri, { encoding: 'base64' });
  return base64ToBytes(b64);
}

/* ------------------------------------------------------------- web chooser */

function webPick(accept: string): Promise<PickResult> {
  return new Promise((resolve) => {
    try {
      const doc: any = (globalThis as any).document;
      if (!doc) return resolve({ ok: false, reason: 'unavailable', message: 'No DOM' });
      const input = doc.createElement('input');
      input.type = 'file';
      input.accept = accept;
      input.style.cssText = 'position:fixed;left:-10000px;top:0;opacity:0';
      doc.body.appendChild(input);

      let settled = false;
      const done = (r: PickResult) => {
        if (settled) return;
        settled = true;
        try {
          input.remove();
        } catch {
          /* noop */
        }
        resolve(r);
      };

      input.onchange = async () => {
        const f = input.files?.[0];
        if (!f) return done({ ok: false, reason: 'cancelled' });
        try {
          const bytes = new Uint8Array(await f.arrayBuffer());
          done({
            ok: true,
            file: { name: f.name, size: f.size, uri: '', bytes, source: 'storage' },
          });
        } catch (e: any) {
          done({ ok: false, reason: 'error', message: String(e?.message || e) });
        }
      };

      const onFocus = () =>
        setTimeout(() => {
          if (!settled && !input.files?.length) done({ ok: false, reason: 'cancelled' });
        }, 1200);
      (globalThis as any).addEventListener?.('focus', onFocus, { once: true });

      input.click();
    } catch (e: any) {
      resolve({ ok: false, reason: 'error', message: String(e?.message || e) });
    }
  });
}

/* --------------------------------------------------------- native choosers */

async function documentPick(types: string[]): Promise<PickResult> {
  try {
    const DocumentPicker: any = require('expo-document-picker');
    const res = await DocumentPicker.getDocumentAsync({
      type: types,
      copyToCacheDirectory: true,
      multiple: false,
    });
    if (res?.canceled || res?.type === 'cancel') return { ok: false, reason: 'cancelled' };
    const asset = res?.assets?.[0] ?? res;
    if (!asset?.uri) return { ok: false, reason: 'error', message: 'Picker returned no uri' };
    const bytes = await readUriBytes(asset.uri);
    return {
      ok: true,
      file: {
        name: asset.name || 'archive.zip',
        size: asset.size || bytes.length,
        uri: asset.uri,
        bytes,
        source: 'storage',
      },
    };
  } catch (e: any) {
    return { ok: false, reason: 'error', message: String(e?.message || e) };
  }
}

async function galleryPick(): Promise<PickResult> {
  if (Platform.OS === 'web') return webPick('*/*');
  try {
    const ImagePicker: any = require('expo-image-picker');
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm?.granted) {
      return {
        ok: false,
        reason: 'error',
        message: 'Media permission denied — enable Photos/Files access in Settings',
      };
    }
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images', 'videos', 'livePhotos'],
      allowsMultipleSelection: false,
      quality: 1,
    });
    if (res?.canceled) return { ok: false, reason: 'cancelled' };
    const a = res?.assets?.[0];
    if (!a?.uri) return { ok: false, reason: 'error', message: 'No media returned' };
    const bytes = await readUriBytes(a.uri);
    return {
      ok: true,
      file: {
        name: a.fileName || 'media',
        size: a.fileSize || bytes.length,
        uri: a.uri,
        bytes,
        source: 'gallery',
      },
    };
  } catch (e: any) {
    return { ok: false, reason: 'error', message: String(e?.message || e) };
  }
}

export type FolderZip = { name: string; uri: string; size: number };

/** Android SAF: let the user grant a folder, then list every .zip inside it. */
export async function listFolderZips(): Promise<
  { ok: true; dir: string; zips: FolderZip[] } | { ok: false; reason: string }
> {
  if (Platform.OS !== 'android') return { ok: false, reason: 'android-only' };
  try {
    const legacy: any = require('expo-file-system/legacy');
    const SAF = legacy.StorageAccessFramework;
    if (!SAF?.requestDirectoryPermissionsAsync) return { ok: false, reason: 'unavailable' };
    const perm = await SAF.requestDirectoryPermissionsAsync();
    if (!perm?.granted) return { ok: false, reason: 'cancelled' };
    const uris: string[] = await SAF.readDirectoryAsync(perm.directoryUri);
    const zips: FolderZip[] = [];
    for (const uri of uris) {
      const decoded = decodeURIComponent(uri);
      const name = decoded.split(/[/%]/).pop() || decoded;
      if (!/\.zip$/i.test(decoded)) continue;
      let size = 0;
      try {
        const info = await legacy.getInfoAsync(uri);
        size = info?.size ?? 0;
      } catch {
        /* size optional */
      }
      zips.push({ name, uri, size });
    }
    return { ok: true, dir: perm.directoryUri, zips };
  } catch (e: any) {
    return { ok: false, reason: String(e?.message || e) };
  }
}

export async function readFolderZip(z: FolderZip): Promise<PickResult> {
  try {
    const bytes = await readUriBytes(z.uri);
    if (!isZipBytes(bytes)) return { ok: false, reason: 'invalid' };
    return {
      ok: true,
      file: { name: z.name, size: z.size || bytes.length, uri: z.uri, bytes, source: 'folder' },
    };
  } catch (e: any) {
    return { ok: false, reason: 'error', message: String(e?.message || e) };
  }
}

export async function fetchZip(url: string): Promise<PickResult> {
  try {
    const target = normaliseUrl(url.trim());
    const res = await fetch(target);
    if (!res.ok) return { ok: false, reason: 'error', message: `HTTP ${res.status}` };
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (!isZipBytes(bytes)) return { ok: false, reason: 'invalid' };
    const name = (target.split('/').pop() || 'remote.zip').split('?')[0];
    return {
      ok: true,
      file: {
        name: /\.zip$/i.test(name) ? name : `${name}.zip`,
        size: bytes.length,
        uri: target,
        bytes,
        source: 'url',
      },
    };
  } catch (e: any) {
    return { ok: false, reason: 'error', message: String(e?.message || e) };
  }
}

function normaliseUrl(url: string): string {
  const gh = url.match(/^https?:\/\/github\.com\/([^/]+)\/([^/]+?)(?:\.git)?\/?$/i);
  if (gh) return `https://codeload.github.com/${gh[1]}/${gh[2]}/zip/refs/heads/main`;
  const tree = url.match(/^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/tree\/([^/]+)\/?$/i);
  if (tree) return `https://codeload.github.com/${tree[1]}/${tree[2]}/zip/refs/heads/${tree[3]}`;
  return url;
}

/* --------------------------------------------------------------- dispatcher */

export async function pickFrom(source: SourceId): Promise<PickResult> {
  let res: PickResult;
  switch (source) {
    case 'storage':
      res =
        Platform.OS === 'web'
          ? await webPick('.zip,application/zip,application/x-zip-compressed,application/octet-stream')
          : await documentPick([
              'application/zip',
              'application/x-zip-compressed',
              'multipart/x-zip',
              'application/octet-stream',
            ]);
      break;
    case 'anyfile':
      res = Platform.OS === 'web' ? await webPick('*/*') : await documentPick(['*/*']);
      break;
    case 'gallery':
      res = await galleryPick();
      break;
    default:
      res = { ok: false, reason: 'unavailable' };
  }
  if (res.ok && !isZipBytes(res.file.bytes)) return { ok: false, reason: 'invalid' };
  return res;
}
