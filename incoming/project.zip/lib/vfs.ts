import JSZip from 'jszip';

export type VFile = {
  path: string;
  name: string;
  ext: string;
  size: number;
  text?: string;
  base64?: string;
  mime: string;
  binary: boolean;
};

export type VFS = {
  files: Map<string, VFile>;
  root: string;
  totalBytes: number;
};

const MIME: Record<string, string> = {
  html: 'text/html',
  htm: 'text/html',
  js: 'text/javascript',
  mjs: 'text/javascript',
  cjs: 'text/javascript',
  jsx: 'text/javascript',
  ts: 'text/javascript',
  tsx: 'text/javascript',
  json: 'application/json',
  css: 'text/css',
  scss: 'text/css',
  svg: 'image/svg+xml',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  gif: 'image/gif',
  webp: 'image/webp',
  ico: 'image/x-icon',
  bmp: 'image/bmp',
  woff: 'font/woff',
  woff2: 'font/woff2',
  ttf: 'font/ttf',
  otf: 'font/otf',
  eot: 'application/vnd.ms-fontobject',
  mp3: 'audio/mpeg',
  wav: 'audio/wav',
  ogg: 'audio/ogg',
  mp4: 'video/mp4',
  webm: 'video/webm',
  md: 'text/markdown',
  txt: 'text/plain',
  xml: 'application/xml',
  yml: 'text/yaml',
  yaml: 'text/yaml',
};

export const TEXT_EXTS = new Set([
  'html', 'htm', 'js', 'mjs', 'cjs', 'jsx', 'ts', 'tsx', 'json', 'css', 'scss',
  'sass', 'less', 'svg', 'md', 'markdown', 'txt', 'xml', 'yml', 'yaml',
  'gradle', 'properties', 'kt', 'java', 'py', 'rb', 'php', 'sh', 'env',
  'gitignore', 'lock', 'toml', 'ini', 'cfg', 'vue', 'svelte', 'dart', 'c',
  'cpp', 'h', 'graphql', 'sql', 'csv', 'babelrc', 'eslintrc', 'prettierrc',
]);

export function extname(p: string): string {
  const base = p.split('/').pop() || p;
  const i = base.lastIndexOf('.');
  if (i < 1) return '';
  return base.slice(i + 1).toLowerCase();
}

export function mimeFor(p: string): string {
  return MIME[extname(p)] || 'application/octet-stream';
}

export function isTextPath(p: string): boolean {
  const e = extname(p);
  if (!e) return /^(license|readme|makefile|dockerfile|procfile|\.?[a-z]+rc)$/i.test(p.split('/').pop() || '');
  return TEXT_EXTS.has(e);
}

/** Read every entry of a zip into a virtual file system (text + base64 binaries). */
export async function buildVFS(bytes: Uint8Array): Promise<VFS> {
  const zip = await JSZip.loadAsync(bytes);
  const raw: { path: string; file: any }[] = [];
  zip.forEach((path, f: any) => {
    if (f.dir) return;
    const clean = path.replace(/^\/+/, '');
    if (!clean) return;
    if (/(^|\/)(__MACOSX|\.DS_Store|Thumbs\.db)(\/|$)/.test(clean)) return;
    raw.push({ path: clean, file: f });
  });

  // Detect and strip a single wrapping root folder.
  let root = '';
  const tops = new Set(raw.map((r) => r.path.split('/')[0]));
  if (tops.size === 1 && raw.every((r) => r.path.includes('/'))) {
    root = `${[...tops][0]}/`;
  }

  const files = new Map<string, VFile>();
  let totalBytes = 0;

  for (const r of raw) {
    const rel = root && r.path.startsWith(root) ? r.path.slice(root.length) : r.path;
    if (!rel) continue;
    const binary = !isTextPath(rel);
    const name = rel.split('/').pop() || rel;
    try {
      if (binary) {
        const b64 = await r.file.async('base64');
        const size = Math.floor((b64.length * 3) / 4);
        files.set(rel, {
          path: rel, name, ext: extname(rel), size, base64: b64,
          mime: mimeFor(rel), binary: true,
        });
        totalBytes += size;
      } else {
        const text = await r.file.async('string');
        files.set(rel, {
          path: rel, name, ext: extname(rel), size: text.length, text,
          mime: mimeFor(rel), binary: false,
        });
        totalBytes += text.length;
      }
    } catch {
      /* skip corrupt entry */
    }
  }

  return { files, root, totalBytes };
}

export function dataUrl(f: VFile): string {
  if (f.base64 != null) return `data:${f.mime};base64,${f.base64}`;
  return `data:${f.mime};charset=utf-8,${encodeURIComponent(f.text ?? '')}`;
}

/** Resolve "./a/../b.js" style specifiers against a base file path. */
export function resolvePath(base: string, spec: string): string {
  if (/^(https?:|data:|blob:|\/\/)/.test(spec)) return spec;
  const clean = spec.split('?')[0].split('#')[0];
  const baseDir = base.includes('/') ? base.slice(0, base.lastIndexOf('/')) : '';
  const start = clean.startsWith('/') ? '' : baseDir;
  const parts = (start ? `${start}/${clean}` : clean).split('/');
  const out: string[] = [];
  for (const part of parts) {
    if (!part || part === '.') continue;
    if (part === '..') out.pop();
    else out.push(part);
  }
  return out.join('/');
}

const JS_EXTS = ['', '.js', '.jsx', '.ts', '.tsx', '.mjs', '.cjs', '.json'];

/** Find a file with node-ish resolution (extension + /index). */
export function lookup(vfs: VFS, path: string): VFile | undefined {
  for (const e of JS_EXTS) {
    const f = vfs.files.get(`${path}${e}`);
    if (f) return f;
  }
  for (const e of JS_EXTS.slice(1)) {
    const f = vfs.files.get(`${path}/index${e}`);
    if (f) return f;
  }
  return undefined;
}

export function findFirst(vfs: VFS, candidates: string[]): VFile | undefined {
  for (const c of candidates) {
    const f = vfs.files.get(c);
    if (f) return f;
  }
  return undefined;
}

export function listDirs(vfs: VFS): string[] {
  const dirs = new Set<string>();
  vfs.files.forEach((_, p) => {
    const parts = p.split('/');
    parts.pop();
    let acc = '';
    for (const d of parts) {
      acc = acc ? `${acc}/${d}` : d;
      dirs.add(acc);
    }
  });
  return [...dirs].sort();
}
