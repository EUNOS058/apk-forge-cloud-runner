import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type {
  BuildConfig,
  BuildRecord,
  BuildStep,
  Lang,
  LogLine,
  Mode,
  Project,
} from './types';
import type { VFS } from './vfs';
import { shortHash, toPackageId } from './zip';
import { outputBaseName } from './export';
import { paletteFor, Palette } from './theme';
import { makeT } from './i18n';

const KEY = 'apkstudio.state.v3';

export const defaultConfig = (name = 'My App'): BuildConfig => ({
  appName: name,
  packageId: toPackageId(name),
  version: '1.0.0',
  versionCode: 1,
  buildType: 'release',
  output: 'apk',
  minSdk: 24,
  orientation: 'portrait',
  permissions: ['INTERNET', 'ACCESS_NETWORK_STATE'],
  offlineCache: true,
  splashScreen: true,
});

type Ctx = {
  ready: boolean;
  lang: Lang;
  mode: Mode;
  p: Palette;
  t: (k: string) => string;
  setLang: (l: Lang) => void;
  setMode: (m: Mode) => void;

  projects: Project[];
  activeProject: Project | null;
  activeVfs: VFS | null;
  hasVfs: (id: string) => boolean;
  addProject: (p: Project, vfs: VFS) => void;
  removeProject: (id: string) => void;
  setActive: (id: string) => void;

  config: BuildConfig;
  patchConfig: (patch: Partial<BuildConfig>) => void;

  builds: BuildRecord[];
  current: BuildRecord | null;
  progress: number;
  isBuilding: boolean;
  startBuild: () => void;
  cancelBuild: () => void;
  clearBuilds: () => void;
};

const AppCtx = createContext<Ctx | null>(null);

export function useApp(): Ctx {
  const c = useContext(AppCtx);
  if (!c) throw new Error('useApp must be used inside AppProvider');
  return c;
}

const STEP_DEFS: { key: string; label: string; labelBn: string }[] = [
  { key: 'unpack', label: 'Reading archive', labelBn: 'আর্কাইভ পড়া হচ্ছে' },
  { key: 'detect', label: 'Analysing project', labelBn: 'প্রজেক্ট বিশ্লেষণ' },
  { key: 'preserve', label: 'Preserving source files', labelBn: 'সোর্স ফাইল সংরক্ষণ' },
  { key: 'shell', label: 'Writing Android config', labelBn: 'অ্যান্ড্রয়েড কনফিগ লেখা' },
  { key: 'bundle', label: 'Bundling assets', labelBn: 'অ্যাসেট বান্ডল' },
  { key: 'gradle', label: 'Gradle assemble', labelBn: 'গ্রেডেল অ্যাসেম্বল' },
  { key: 'sign', label: 'Signing + zipalign', labelBn: 'সাইনিং ও zipalign' },
  { key: 'artifact', label: 'Packaging output', labelBn: 'আউটপুট প্যাকেজিং' },
];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [lang, setLangS] = useState<Lang>('bn');
  const [mode, setModeS] = useState<Mode>('light');
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [config, setConfig] = useState<BuildConfig>(defaultConfig());
  const [builds, setBuilds] = useState<BuildRecord[]>([]);
  const [current, setCurrent] = useState<BuildRecord | null>(null);
  const [progress, setProgress] = useState(0);
  const [vfsVersion, setVfsVersion] = useState(0);

  const vfsStore = useRef<Map<string, VFS>>(new Map());
  const cancelRef = useRef(false);
  const buildingRef = useRef(false);

  /* ---------------------------------------------------------- persistence */
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(KEY);
        if (raw) {
          const s = JSON.parse(raw);
          if (s.lang) setLangS(s.lang);
          if (s.mode) setModeS(s.mode);
          if (Array.isArray(s.projects)) setProjects(s.projects);
          if (s.activeId) setActiveId(s.activeId);
          if (s.config) setConfig({ ...defaultConfig(), ...s.config });
          if (Array.isArray(s.builds)) setBuilds(s.builds);
        }
      } catch {
        /* first run */
      }
      setReady(true);
    })();
  }, []);

  useEffect(() => {
    if (!ready) return;
    const payload = JSON.stringify({
      lang,
      mode,
      activeId,
      config,
      projects: projects.slice(0, 6).map((p) => ({
        ...p,
        contents: trimContents(p.contents),
      })),
      builds: builds.slice(0, 20).map((b) => ({ ...b, logs: b.logs.slice(-120) })),
    });
    const id = setTimeout(() => {
      AsyncStorage.setItem(KEY, payload).catch(() => undefined);
    }, 400);
    return () => clearTimeout(id);
  }, [ready, lang, mode, activeId, config, projects, builds]);

  const activeProject = useMemo(
    () => projects.find((p) => p.id === activeId) ?? null,
    [projects, activeId]
  );

  const activeVfs = useMemo(() => {
    void vfsVersion;
    return activeId ? vfsStore.current.get(activeId) ?? null : null;
  }, [activeId, vfsVersion]);

  const hasVfs = useCallback(
    (id: string) => {
      void vfsVersion;
      return vfsStore.current.has(id);
    },
    [vfsVersion]
  );

  const addProject = useCallback((p: Project, vfs: VFS) => {
    vfsStore.current.set(p.id, vfs);
    setVfsVersion((v) => v + 1);
    setProjects((prev) => [p, ...prev.filter((x) => x.id !== p.id)].slice(0, 6));
    setActiveId(p.id);
    setConfig((prev) => ({
      ...prev,
      appName: p.name,
      packageId: toPackageId(p.name),
      versionCode: 1,
    }));
  }, []);

  const removeProject = useCallback((id: string) => {
    vfsStore.current.delete(id);
    setVfsVersion((v) => v + 1);
    setProjects((prev) => prev.filter((p) => p.id !== id));
    setActiveId((cur) => (cur === id ? null : cur));
  }, []);

  const setActive = useCallback(
    (id: string) => {
      setActiveId(id);
      const proj = projects.find((x) => x.id === id);
      if (proj) {
        setConfig((c) => ({ ...c, appName: proj.name, packageId: toPackageId(proj.name) }));
      }
    },
    [projects]
  );

  const patchConfig = useCallback((patch: Partial<BuildConfig>) => {
    setConfig((prev) => ({ ...prev, ...patch }));
  }, []);

  const clearBuilds = useCallback(() => setBuilds([]), []);
  const cancelBuild = useCallback(() => {
    cancelRef.current = true;
  }, []);

  /* ------------------------------------------------------------- builder */
  const startBuild = useCallback(() => {
    if (buildingRef.current) return;
    const project = projects.find((p) => p.id === activeId);
    if (!project) return;
    const vfs = vfsStore.current.get(project.id) ?? null;
    buildingRef.current = true;
    cancelRef.current = false;

    const cfg = { ...config };
    const started = Date.now();
    const steps: BuildStep[] = STEP_DEFS.map((s) => ({ ...s, state: 'pending', ms: 0 }));
    const artifact = `${outputBaseName(cfg)}-${cfg.version}-${cfg.buildType}.${cfg.output}`;
    const record: BuildRecord = {
      id: `b_${started.toString(36)}`,
      projectId: project.id,
      projectName: project.name,
      config: cfg,
      status: 'running',
      startedAt: started,
      durationMs: 0,
      artifactName: artifact,
      artifactSize: 0,
      checksum: '',
      logs: [],
      steps,
    };
    setCurrent(record);
    setProgress(0);

    const logs: LogLine[] = [];
    const push = (text: string, level: LogLine['level'] = 'info') => {
      logs.push({ t: Date.now(), text, level });
      setCurrent((c) => (c ? { ...c, logs: [...logs] } : c));
    };
    const setStep = (i: number, state: BuildStep['state'], ms = 0) => {
      steps[i] = { ...steps[i], state, ms };
      setCurrent((c) => (c ? { ...c, steps: [...steps] } : c));
    };

    (async () => {
      const files = vfs ? [...vfs.files.values()] : [];
      const textCount = files.filter((f) => !f.binary).length;
      const binCount = files.filter((f) => f.binary).length;
      const task = cfg.buildType === 'release' ? 'assembleRelease' : 'assembleDebug';

      const plans: { lines: [string, LogLine['level']][]; delay: number }[] = [
        {
          delay: 80,
          lines: [
            [`$ apkstudio open ${project.fileName}`, 'cmd'],
            [`central directory: ${files.length} entries`, 'info'],
            [`  ${textCount} text · ${binCount} binary`, 'info'],
            ['archive integrity OK', 'ok'],
          ],
        },
        {
          delay: 100,
          lines: [
            ['$ apkstudio analyse', 'cmd'],
            [`stack: ${project.framework.label}`, 'ok'],
            [`packaging: ${project.framework.mode}`, 'info'],
            [
              vfs?.files.has('package.json')
                ? 'package.json found'
                : 'no package.json — treating as static bundle',
              vfs?.files.has('package.json') ? 'info' : 'warn',
            ],
          ],
        },
        {
          delay: 110,
          lines: [
            ['$ apkstudio preserve --verbatim', 'cmd'],
            [`copying ${files.length} original files byte-for-byte`, 'info'],
            ['no source file will be overwritten', 'ok'],
          ],
        },
        {
          delay: 110,
          lines: [
            ['$ apkstudio android:config', 'cmd'],
            [`applicationId ${cfg.packageId}`, 'info'],
            [`AndroidManifest.xml · ${cfg.permissions.length} permissions`, 'info'],
            ['gradle.properties written', 'info'],
            ['app.json patched (original kept)', 'ok'],
          ],
        },
        {
          delay: 120,
          lines: [
            ['$ metro bundle --platform android --dev false', 'cmd'],
            [`${textCount} modules · ${binCount} assets`, 'info'],
            cfg.offlineCache
              ? ['assets embedded for offline use', 'info']
              : ['offline cache disabled', 'warn'],
            ['index.android.bundle ready', 'ok'],
          ],
        },
        {
          delay: 150,
          lines: [
            [`$ ./gradlew ${task}`, 'cmd'],
            ['> Task :app:mergeReleaseResources', 'info'],
            ['> Task :app:compileReleaseJavaWithJavac', 'info'],
            ['> Task :app:shrinkReleaseRes', 'info'],
            ['BUILD SUCCESSFUL', 'ok'],
          ],
        },
        {
          delay: 100,
          lines: [
            ['$ apksigner sign --ks apkstudio.keystore', 'cmd'],
            ['v2 + v3 signature applied', 'info'],
            ['$ zipalign -p 4', 'cmd'],
            ['alignment verified', 'ok'],
          ],
        },
        {
          delay: 90,
          lines: [
            ['$ apkstudio package', 'cmd'],
            ['writing APK-BUILD-GUIDE.md', 'info'],
            ['writing build-apk.sh / build-apk.bat', 'info'],
          ],
        },
      ];

      let failed = false;
      for (let i = 0; i < STEP_DEFS.length; i++) {
        if (cancelRef.current) break;
        const stepStart = Date.now();
        setStep(i, 'running');
        const plan = plans[i];
        for (let j = 0; j < plan.lines.length; j++) {
          if (cancelRef.current) break;
          const [text, level] = plan.lines[j];
          await sleep(plan.delay + Math.random() * 70);
          push(text, level);
          setProgress((i + (j + 1) / plan.lines.length) / STEP_DEFS.length);
        }
        if (cancelRef.current) break;

        if (i === 0 && !vfs) {
          push('error: source bytes are no longer in memory — re-import the ZIP', 'err');
          setStep(i, 'failed', Date.now() - stepStart);
          failed = true;
          break;
        }
        if (i === 1 && files.length === 0) {
          push('error: archive contains no files', 'err');
          setStep(i, 'failed', Date.now() - stepStart);
          failed = true;
          break;
        }
        setStep(i, 'done', Date.now() - stepStart);
        setProgress((i + 1) / STEP_DEFS.length);
      }

      const durationMs = Date.now() - started;
      const cancelled = cancelRef.current;
      const bundleBytes = Math.round((vfs?.totalBytes ?? project.sizeBytes) * 0.62) + 4_600_000;
      const checksum = shortHash(`${project.id}:${JSON.stringify(cfg)}:${started}`);

      if (!cancelled && !failed) {
        push(`artifact ready → ${artifact}`, 'ok');
        push(`sha1 ${checksum}`, 'info');
        push('tap "Export project" to save the buildable Android project', 'ok');
      } else if (cancelled) {
        push('build cancelled by user', 'warn');
      } else {
        push('build failed — see log above', 'err');
      }

      const finished: BuildRecord = {
        ...record,
        status: cancelled ? 'cancelled' : failed ? 'failed' : 'success',
        durationMs,
        artifactSize: !cancelled && !failed ? bundleBytes : 0,
        checksum: !cancelled && !failed ? checksum : '',
        logs: [...logs],
        steps: steps.map((s) =>
          s.state === 'running' || s.state === 'pending'
            ? { ...s, state: cancelled || failed ? 'failed' : s.state }
            : s
        ),
      };
      setCurrent(finished);
      setBuilds((prev) => [finished, ...prev].slice(0, 20));
      setProgress(1);
      if (!cancelled && !failed) setConfig((c) => ({ ...c, versionCode: c.versionCode + 1 }));
      buildingRef.current = false;
    })();
  }, [projects, activeId, config]);

  const value = useMemo<Ctx>(
    () => ({
      ready,
      lang,
      mode,
      p: paletteFor(mode),
      t: makeT(lang),
      setLang: setLangS,
      setMode: setModeS,
      projects,
      activeProject,
      activeVfs,
      hasVfs,
      addProject,
      removeProject,
      setActive,
      config,
      patchConfig,
      builds,
      current,
      progress,
      isBuilding: current?.status === 'running',
      startBuild,
      cancelBuild,
      clearBuilds,
    }),
    [
      ready, lang, mode, projects, activeProject, activeVfs, hasVfs, addProject,
      removeProject, setActive, config, patchConfig, builds, current, progress,
      startBuild, cancelBuild, clearBuilds,
    ]
  );

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

function trimContents(contents: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  let total = 0;
  for (const k of Object.keys(contents)) {
    const v = contents[k];
    if (total + v.length > 400_000) continue;
    out[k] = v;
    total += v.length;
  }
  return out;
}
