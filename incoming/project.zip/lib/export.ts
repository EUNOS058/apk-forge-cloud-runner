import { Platform } from 'react-native';
import JSZip from 'jszip';
import type { BuildConfig, Project } from './types';
import type { VFS } from './vfs';
import { base64ToBytes } from './zip';
import { buildApkAddons, makeKeystore } from './apk';

/* ------------------------------------------------------------ project build */

export type ExportKind = 'project' | 'source' | 'web';

export function outputBaseName(config: BuildConfig): string {
  return (
    config.appName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'app'
  );
}

/**
 * Produces a *complete, buildable* Android project ZIP.
 * Every original file is preserved byte-for-byte. Nothing the user wrote is
 * overwritten — generated files live beside them or patch known config keys.
 */
export async function buildAndroidProject(
  vfs: VFS,
  project: Project,
  config: BuildConfig,
  checksum: string,
  kind: ExportKind = 'project'
): Promise<JSZip> {
  const zip = new JSZip();

  // 1. every original file, untouched
  let restored = 0;
  vfs.files.forEach((f, path) => {
    if (f.binary && f.base64 != null) {
      zip.file(path, f.base64, { base64: true });
      restored++;
    } else if (f.text != null) {
      zip.file(path, f.text);
      restored++;
    }
  });

  if (kind === 'source') return zip;

  // 1b · APK delivery add-ons (keystore, CI workflows, PWA shell)
  const keystore = makeKeystore(config);
  const addons = buildApkAddons(vfs, project, config, keystore);
  Object.keys(addons.files).forEach((path) => zip.file(path, addons.files[path]));
  Object.keys(addons.base64Files).forEach((path) =>
    zip.file(path, addons.base64Files[path], { base64: true })
  );

  if (kind === 'web') return zip;

  const isNative = project.framework.mode === 'native';
  const entry = detectEntry(vfs, isNative);

  // 2. patch (never replace) app.json
  const appJsonFile = vfs.files.get('app.json');
  let appJson: any = {};
  if (appJsonFile?.text) {
    try {
      appJson = JSON.parse(appJsonFile.text);
      zip.file('app.json.original', appJsonFile.text);
    } catch {
      appJson = {};
    }
  }
  const expo = appJson.expo ?? appJson;
  expo.name = config.appName;
  expo.slug = expo.slug || outputBaseName(config);
  expo.version = config.version;
  expo.orientation = config.orientation === 'auto' ? 'default' : config.orientation;
  expo.android = {
    ...(expo.android || {}),
    package: config.packageId,
    versionCode: config.versionCode,
    permissions: config.permissions,
    minSdkVersion: config.minSdk,
  };
  zip.file('app.json', JSON.stringify(appJson.expo ? { ...appJson, expo } : { expo }, null, 2));

  // 3. patch package.json scripts without destroying dependencies
  const pkgFile = vfs.files.get('package.json');
  let pkg: any = null;
  if (pkgFile?.text) {
    try {
      pkg = JSON.parse(pkgFile.text);
    } catch {
      pkg = null;
    }
  }
  if (pkg) {
    pkg.scripts = {
      ...(pkg.scripts || {}),
      'apk:prebuild': 'npx expo prebuild --platform android --clean',
      'apk:debug': 'cd android && ./gradlew assembleDebug',
      'apk:release': 'cd android && ./gradlew assembleRelease',
      'apk:cloud': 'eas build -p android --profile preview',
    };
    zip.file('package.json', JSON.stringify(pkg, null, 2));
  }

  // 4. Android config
  zip.file('android/app/src/main/AndroidManifest.xml', manifest(config));
  zip.file('android/gradle.properties', gradleProps(config));
  zip.file('eas.json', easJson(config));

  // 5. WebView shell only when the project has no native entry (never overwrites)
  if (!isNative && entry.kind === 'html') {
    zip.file('apkstudio/WebShell.tsx', webShell(config, entry.path));
    zip.file('apkstudio/README.txt', WEBSHELL_NOTE);
  }

  // 6. one-shot build scripts
  zip.file('build-apk.sh', shScript(config));
  zip.file('build-apk.bat', batScript(config));
  zip.file(
    'APK-BUILD-GUIDE.md',
    guide(project, config, checksum, entry.path, restored, vfs.files.size)
  );
  zip.file(
    'apkstudio/build-manifest.json',
    JSON.stringify(
      {
        generator: 'APK Studio 2.0',
        generatedAt: new Date().toISOString(),
        artifact: `${outputBaseName(config)}-${config.version}-${config.buildType}.${config.output}`,
        checksum,
        entryPoint: entry.path,
        packagingMode: project.framework.mode,
        framework: project.framework.id,
        filesPreserved: restored,
        config,
      },
      null,
      2
    )
  );
  return zip;
}

function detectEntry(vfs: VFS, isNative: boolean): { kind: 'native' | 'html'; path: string } {
  const nativeCandidates = ['App.tsx', 'App.jsx', 'App.js', 'src/App.tsx', 'index.js', 'index.ts'];
  const htmlCandidates = ['index.html', 'public/index.html', 'dist/index.html', 'www/index.html'];
  if (isNative) {
    for (const c of nativeCandidates) if (vfs.files.has(c)) return { kind: 'native', path: c };
  }
  for (const c of htmlCandidates) if (vfs.files.has(c)) return { kind: 'html', path: c };
  for (const c of nativeCandidates) if (vfs.files.has(c)) return { kind: 'native', path: c };
  const first = [...vfs.files.keys()].find((p) => /\.(html|tsx|jsx|js)$/i.test(p));
  return { kind: 'html', path: first || 'index.html' };
}

const WEBSHELL_NOTE = `apkstudio/WebShell.tsx is an OPTIONAL WebView wrapper.

Your original files were NOT modified. If you want the wrapper to be the app
entry, import it from your own App file:

  export { default } from './apkstudio/WebShell';
`;

function manifest(c: BuildConfig) {
  const perms = c.permissions
    .map((p) => `    <uses-permission android:name="android.permission.${p}" />`)
    .join('\n');
  return `<?xml version="1.0" encoding="utf-8"?>
<!-- Generated by APK Studio · merge into your android/app/src/main/AndroidManifest.xml -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="${c.packageId}">
${perms}

    <application
        android:label="${c.appName}"
        android:icon="@mipmap/ic_launcher"
        android:allowBackup="true"
        android:usesCleartextTraffic="true"
        android:theme="@style/AppTheme">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTask"
            android:screenOrientation="${c.orientation === 'auto' ? 'unspecified' : c.orientation}"
            android:configChanges="keyboard|keyboardHidden|orientation|screenSize|uiMode"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;
}

function gradleProps(c: BuildConfig) {
  return `# Generated by APK Studio
org.gradle.jvmargs=-Xmx4096m -XX:MaxMetaspaceSize=1024m
org.gradle.parallel=true
android.useAndroidX=true
android.enableJetifier=false
newArchEnabled=true
hermesEnabled=true

APPLICATION_ID=${c.packageId}
VERSION_NAME=${c.version}
VERSION_CODE=${c.versionCode}
MIN_SDK_VERSION=${c.minSdk}
TARGET_SDK_VERSION=35
COMPILE_SDK_VERSION=35
`;
}

function easJson(c: BuildConfig) {
  return JSON.stringify(
    {
      cli: { version: '>= 12.0.0', appVersionSource: 'local' },
      build: {
        preview: {
          distribution: 'internal',
          android: { buildType: 'apk' },
        },
        production: {
          android: { buildType: c.output === 'apk' ? 'apk' : 'app-bundle' },
        },
      },
      submit: { production: {} },
    },
    null,
    2
  );
}

function webShell(c: BuildConfig, entry: string) {
  return `import React from 'react';
import { SafeAreaView, StyleSheet, StatusBar } from 'react-native';
import { WebView } from 'react-native-webview';

/**
 * Optional WebView wrapper generated by APK Studio.
 * Install once:  npx expo install react-native-webview
 */
export default function WebShell() {
  return (
    <SafeAreaView style={styles.root}>
      <StatusBar barStyle="light-content" />
      <WebView
        source={require('../${entry}')}
        originWhitelist={['*']}
        allowFileAccess
        allowFileAccessFromFileURLs
        allowUniversalAccessFromFileURLs
        domStorageEnabled
        javaScriptEnabled
        cacheEnabled={${c.offlineCache}}
        style={styles.web}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  web: { flex: 1, backgroundColor: '#fff' },
});
`;
}

function shScript(c: BuildConfig) {
  const task = c.buildType === 'release' ? 'assembleRelease' : 'assembleDebug';
  return `#!/usr/bin/env bash
set -e
echo "▸ APK Studio — building ${c.appName} (${c.packageId})"

if [ ! -d node_modules ]; then
  echo "▸ installing dependencies"
  npm install
fi

echo "▸ generating native android project"
npx expo prebuild --platform android --clean

echo "▸ gradle ${task}"
cd android
chmod +x ./gradlew
./gradlew ${task}

echo ""
echo "✔ APK ready:"
find app/build/outputs/apk -name "*.apk" -print
`;
}

function batScript(c: BuildConfig) {
  const task = c.buildType === 'release' ? 'assembleRelease' : 'assembleDebug';
  return `@echo off
echo APK Studio - building ${c.appName}
if not exist node_modules ( call npm install )
call npx expo prebuild --platform android --clean
cd android
call gradlew.bat ${task}
echo.
echo APK ready in android\\app\\build\\outputs\\apk\\
pause
`;
}

function guide(
  project: Project,
  c: BuildConfig,
  checksum: string,
  entry: string,
  restored: number,
  total: number
) {
  return `# ${c.appName} — Android build guide

Generated by **APK Studio** from \`${project.fileName}\`.
**All ${restored} of ${total} original files are preserved unchanged** in this archive.

| Field | Value |
| --- | --- |
| Package | \`${c.packageId}\` |
| Version | ${c.version} (code ${c.versionCode}) |
| Output | ${c.output.toUpperCase()} · ${c.buildType} |
| Min SDK | ${c.minSdk} |
| Detected stack | ${project.framework.label} |
| Entry point | \`${entry}\` |
| Build id | \`${checksum.slice(0, 16)}\` |

---

## Fastest path — one command

\`\`\`bash
bash build-apk.sh          # macOS / Linux
build-apk.bat              # Windows (double click)
\`\`\`

The finished file appears in
\`android/app/build/outputs/apk/${c.buildType}/\`.

## Cloud build (no Android Studio needed)

\`\`\`bash
npm install -g eas-cli
eas login
eas build -p android --profile preview
\`\`\`

EAS returns a download link for an installable **.apk**.

## Manual steps

\`\`\`bash
npm install
npx expo prebuild --platform android --clean
cd android && ./gradlew ${c.buildType === 'release' ? 'assembleRelease' : 'assembleDebug'}
\`\`\`

## Install the APK on your phone

1. Copy the \`.apk\` to the device.
2. **Settings → Security → Install unknown apps** → allow your file manager.
3. Tap the file and confirm.

> If an older copy exists that was signed with a different key, uninstall it first.

---

## What APK Studio added

| Path | Purpose |
| --- | --- |
| \`android/app/src/main/AndroidManifest.xml\` | permissions, launcher activity, orientation |
| \`android/gradle.properties\` | application id, version, SDK levels |
| \`app.json\` | patched Expo config (original kept as \`app.json.original\`) |
| \`eas.json\` | cloud build profiles |
| \`build-apk.sh\` / \`build-apk.bat\` | one-shot build scripts |
${project.framework.mode !== 'native' ? '| `apkstudio/WebShell.tsx` | optional WebView wrapper (opt-in) |\n' : ''}
Nothing else was touched.
`;
}

/* ------------------------------------------------------------------- saving */

export type SaveOutcome = {
  ok: boolean;
  where: 'downloads' | 'share' | 'browser' | 'none';
  message: string;
  uri?: string;
};

export async function saveZip(
  zip: JSZip,
  fileName: string,
  prefer: 'downloads' | 'share' = 'downloads'
): Promise<SaveOutcome> {
  if (Platform.OS === 'web') {
    try {
      const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
      const g: any = globalThis as any;
      const url = g.URL.createObjectURL(blob);
      const a = g.document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.rel = 'noopener';
      g.document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        try {
          g.URL.revokeObjectURL(url);
          a.remove();
        } catch {
          /* noop */
        }
      }, 2000);
      return { ok: true, where: 'browser', message: fileName };
    } catch (e: any) {
      return { ok: false, where: 'none', message: String(e?.message || e) };
    }
  }

  const b64 = await zip.generateAsync({ type: 'base64', compression: 'DEFLATE' });

  // 1 · Android Storage Access Framework → writes straight into a real folder.
  if (Platform.OS === 'android' && prefer === 'downloads') {
    try {
      const legacy: any = require('expo-file-system/legacy');
      const SAF = legacy.StorageAccessFramework;
      if (SAF?.requestDirectoryPermissionsAsync) {
        const perm = await SAF.requestDirectoryPermissionsAsync();
        if (perm?.granted) {
          const uri = await SAF.createFileAsync(perm.directoryUri, fileName, 'application/zip');
          await legacy.writeAsStringAsync(uri, b64, { encoding: 'base64' });
          return { ok: true, where: 'downloads', message: fileName, uri };
        }
      }
    } catch {
      /* fall through to share sheet */
    }
  }

  // 2 · write to app storage, then hand to the share sheet
  try {
    let uri = '';
    try {
      const FS: any = require('expo-file-system');
      const file = new FS.File(FS.Paths.cache, fileName);
      if (file.exists) file.delete();
      file.create();
      file.write(base64ToBytes(b64));
      uri = file.uri;
    } catch {
      const legacy: any = require('expo-file-system/legacy');
      uri = `${legacy.cacheDirectory}${fileName}`;
      await legacy.writeAsStringAsync(uri, b64, { encoding: 'base64' });
    }
    try {
      const Sharing: any = require('expo-sharing');
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, {
          mimeType: 'application/zip',
          dialogTitle: fileName,
          UTI: 'public.zip-archive',
        });
        return { ok: true, where: 'share', message: fileName, uri };
      }
    } catch {
      /* sharing unavailable */
    }
    return { ok: true, where: 'share', message: uri, uri };
  } catch (e: any) {
    return { ok: false, where: 'none', message: String(e?.message || e) };
  }
}
