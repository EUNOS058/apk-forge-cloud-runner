import { useColorScheme } from 'react-native';
import type { Mode } from './types';

/**
 * Two calm palettes. Light is the default: pure white surfaces, soft grey
 * dividers, a single green accent. Every log/code colour is theme-aware so
 * nothing becomes unreadable when the background flips.
 */

export const light = {
  mode: 'light' as Mode,
  bg: '#F7F9FB',
  surface: '#FFFFFF',
  surfaceAlt: '#F1F4F8',
  elevated: '#FFFFFF',
  border: '#E3E8EF',
  borderSoft: '#EEF1F5',
  text: '#0F1720',
  textDim: '#4B5766',
  muted: '#8996A5',
  accent: '#0A7F47',
  accentText: '#FFFFFF',
  accentSoft: 'rgba(10,127,71,0.10)',
  violet: '#5A47D6',
  violetSoft: 'rgba(90,71,214,0.09)',
  warn: '#A2700B',
  warnSoft: 'rgba(162,112,11,0.10)',
  danger: '#CE2B39',
  dangerSoft: 'rgba(206,43,57,0.09)',

  /** Code / log surface — stays light so the UI reads as white. */
  terminal: '#F4F6FA',
  code: {
    ok: '#0F7A45',
    err: '#C0202E',
    warn: '#8A5D06',
    cmd: '#4A38C4',
    info: '#57636F',
    dim: '#84909E',
    text: '#1B2430',
  },
};

export const dark = {
  mode: 'dark' as Mode,
  bg: '#0B0D10',
  surface: '#14181D',
  surfaceAlt: '#1C2128',
  elevated: '#212831',
  border: '#262D36',
  borderSoft: '#1E242B',
  text: '#EDF1F5',
  textDim: '#9AA7B4',
  muted: '#68757F',
  accent: '#3DDC84',
  accentText: '#04150B',
  accentSoft: 'rgba(61,220,132,0.13)',
  violet: '#8B7BFF',
  violetSoft: 'rgba(139,123,255,0.15)',
  warn: '#FFB020',
  warnSoft: 'rgba(255,176,32,0.13)',
  danger: '#FF5F6D',
  dangerSoft: 'rgba(255,95,109,0.13)',

  terminal: '#07090C',
  code: {
    ok: '#3DDC84',
    err: '#FF6B77',
    warn: '#FFB020',
    cmd: '#8B7BFF',
    info: '#8B99A8',
    dim: '#5C6B80',
    text: '#DCE6F2',
  },
};

export type Palette = typeof light;

export function paletteFor(mode: Mode): Palette {
  return mode === 'dark' ? dark : light;
}

export function useSystemMode(): Mode {
  const scheme = useColorScheme();
  return scheme === 'dark' ? 'dark' : 'light';
}

/** Maps a log level to the right colour for the active palette. */
export function logColor(p: Palette, level: string): string {
  if (level === 'ok') return p.code.ok;
  if (level === 'err' || level === 'error') return p.code.err;
  if (level === 'warn') return p.code.warn;
  if (level === 'cmd') return p.code.cmd;
  return p.code.info;
}

export const radius = { sm: 10, md: 14, lg: 20, xl: 26 };
export const space = { xs: 6, sm: 10, md: 16, lg: 22, xl: 30 };
