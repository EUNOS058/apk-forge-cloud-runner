import JSZip from 'jszip';
import type { PickedFile } from './pick';

const INDEX_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
  <title>Neon Tap</title>
  <link rel="stylesheet" href="styles/game.css" />
</head>
<body>
  <div id="app">
    <header class="hud">
      <div class="stat"><span class="k">SCORE</span><b id="score">0</b></div>
      <div class="stat"><span class="k">BEST</span><b id="best">0</b></div>
      <div class="stat"><span class="k">TIME</span><b id="time">30</b></div>
    </header>

    <main id="board" class="board"></main>

    <footer class="bar">
      <button id="start" class="btn primary">▶ START</button>
      <button id="reset" class="btn ghost">RESET</button>
    </footer>

    <div id="overlay" class="overlay">
      <div class="card">
        <h1>NEON TAP</h1>
        <p>Tap the glowing tile before it fades. Miss one and you lose a life.</p>
        <button id="play" class="btn primary big">PLAY</button>
      </div>
    </div>
  </div>

  <script type="module" src="scripts/main.js"></script>
</body>
</html>
`;

const GAME_CSS = `:root{
  --bg:#080B12; --tile:#141A26; --edge:#1F2735;
  --neon:#3DDC84; --hot:#FF4D6D; --violet:#8B7BFF; --fg:#E8EFF7; --dim:#7C8AA0;
}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:var(--bg);color:var(--fg);font-family:system-ui,-apple-system,sans-serif;user-select:none;overflow:hidden}
#app{display:flex;flex-direction:column;height:100vh;padding:16px;gap:14px}

.hud{display:flex;gap:10px}
.stat{flex:1;background:var(--tile);border:1px solid var(--edge);border-radius:14px;padding:11px 13px;display:flex;flex-direction:column;gap:3px}
.stat .k{font-size:10px;letter-spacing:1.4px;color:var(--dim);font-weight:800}
.stat b{font-size:21px;font-variant-numeric:tabular-nums}

.board{flex:1;display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:repeat(4,1fr);gap:10px}
.cell{background:var(--tile);border:1px solid var(--edge);border-radius:16px;transition:transform .09s ease,background .18s ease,box-shadow .18s ease}
.cell.on{background:var(--neon);box-shadow:0 0 26px rgba(61,220,132,.55);transform:scale(1.03)}
.cell.bomb{background:var(--hot);box-shadow:0 0 26px rgba(255,77,109,.55)}
.cell.hit{animation:pop .22s ease}
@keyframes pop{0%{transform:scale(1.12)}100%{transform:scale(1)}}

.bar{display:flex;gap:10px}
.btn{flex:1;border:0;border-radius:14px;padding:15px;font-weight:800;font-size:14px;letter-spacing:.6px;cursor:pointer}
.btn.primary{background:var(--neon);color:#05130B}
.btn.ghost{background:transparent;border:1px solid var(--edge);color:var(--fg)}
.btn.big{font-size:16px;padding:17px 34px;flex:none}

.overlay{position:fixed;inset:0;background:rgba(6,9,14,.9);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:26px;transition:opacity .25s}
.overlay.hide{opacity:0;pointer-events:none}
.card{background:var(--tile);border:1px solid var(--edge);border-radius:24px;padding:30px 26px;text-align:center;max-width:340px}
.card h1{font-size:30px;letter-spacing:-1px;background:linear-gradient(90deg,var(--neon),var(--violet));-webkit-background-clip:text;background-clip:text;color:transparent;margin-bottom:10px}
.card p{color:var(--dim);font-size:14px;line-height:1.6;margin-bottom:22px}
`;

const MAIN_JS = `import { createBoard, flash, clearAll } from './board.js';
import { Store } from './store.js';

const els = {
  score: document.getElementById('score'),
  best: document.getElementById('best'),
  time: document.getElementById('time'),
  board: document.getElementById('board'),
  start: document.getElementById('start'),
  reset: document.getElementById('reset'),
  overlay: document.getElementById('overlay'),
  play: document.getElementById('play'),
};

const store = new Store('neon-tap');
const CELLS = 12;
let cells = [];
let score = 0;
let time = 30;
let live = null;
let tickId = null;
let spawnId = null;
let running = false;

els.best.textContent = store.get('best', 0);

function render() {
  els.score.textContent = score;
  els.time.textContent = time;
}

function spawn() {
  clearAll(cells);
  const i = Math.floor(Math.random() * CELLS);
  const bomb = Math.random() < 0.18;
  live = { i, bomb };
  flash(cells[i], bomb);
}

function hit(index) {
  if (!running || !live) return;
  const cell = cells[index];
  cell.classList.add('hit');
  setTimeout(() => cell.classList.remove('hit'), 220);

  if (index !== live.i) { score = Math.max(0, score - 1); render(); return; }
  score += live.bomb ? -3 : 2;
  score = Math.max(0, score);
  live = null;
  clearAll(cells);
  render();
  setTimeout(spawn, 120);
}

function stop() {
  running = false;
  clearInterval(tickId);
  clearInterval(spawnId);
  clearAll(cells);
  const best = Math.max(score, store.get('best', 0));
  store.set('best', best);
  els.best.textContent = best;
  els.start.textContent = '▶ START';
  console.log('Game over — score ' + score + ', best ' + best);
}

function start() {
  if (running) { stop(); return; }
  score = 0; time = 30; running = true;
  els.start.textContent = '⏸ STOP';
  els.overlay.classList.add('hide');
  render();
  spawn();
  spawnId = setInterval(spawn, 900);
  tickId = setInterval(() => {
    time -= 1;
    render();
    if (time <= 0) stop();
  }, 1000);
}

cells = createBoard(els.board, CELLS, hit);
els.start.addEventListener('click', start);
els.play.addEventListener('click', start);
els.reset.addEventListener('click', () => {
  stop(); score = 0; time = 30; render();
  els.overlay.classList.remove('hide');
});

render();
console.log('Neon Tap ready · ' + CELLS + ' tiles');
`;

const BOARD_JS = `export function createBoard(root, count, onHit) {
  root.innerHTML = '';
  const cells = [];
  for (let i = 0; i < count; i++) {
    const el = document.createElement('button');
    el.className = 'cell';
    el.setAttribute('aria-label', 'tile ' + (i + 1));
    el.addEventListener('click', () => onHit(i));
    root.appendChild(el);
    cells.push(el);
  }
  return cells;
}

export function flash(cell, bomb) {
  cell.classList.add(bomb ? 'bomb' : 'on');
}

export function clearAll(cells) {
  cells.forEach((c) => c.classList.remove('on', 'bomb'));
}
`;

const STORE_JS = `export class Store {
  constructor(ns) { this.ns = ns; }
  key(k) { return this.ns + ':' + k; }
  get(k, fallback) {
    try {
      const raw = localStorage.getItem(this.key(k));
      return raw == null ? fallback : JSON.parse(raw);
    } catch (e) { return fallback; }
  }
  set(k, v) {
    try { localStorage.setItem(this.key(k), JSON.stringify(v)); } catch (e) {}
  }
}
`;

const PACKAGE_JSON = `{
  "name": "neon-tap",
  "version": "1.2.0",
  "private": true,
  "description": "A tiny reflex game — tap the glowing tile, avoid the red ones.",
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  },
  "devDependencies": {
    "vite": "^5.4.0"
  }
}
`;

const README = `# Neon Tap

A tiny offline reflex game used as the APK Studio demo project.

## How to play

- Tap the **green** tile as fast as you can — each hit is **+2**.
- **Red** tiles are bombs — hitting one costs **-3**.
- Missing (tapping a dark tile) costs **-1**.
- You have **30 seconds**. Your best score is stored locally.

## Structure

- \`index.html\` — game shell and HUD
- \`styles/game.css\` — neon theme + grid layout
- \`scripts/main.js\` — game loop and scoring
- \`scripts/board.js\` — tile factory
- \`scripts/store.js\` — localStorage wrapper

## Packaging

The whole game is static and offline-capable, so it wraps cleanly into a
WebView based Android APK.
`;

const MANIFEST = `{
  "name": "Neon Tap",
  "short_name": "NeonTap",
  "start_url": "./index.html",
  "display": "standalone",
  "background_color": "#080B12",
  "theme_color": "#3DDC84"
}
`;

const ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">
  <rect width="64" height="64" rx="14" fill="#080B12"/>
  <rect x="10" y="10" width="18" height="18" rx="5" fill="#3DDC84"/>
  <rect x="36" y="10" width="18" height="18" rx="5" fill="#1F2735"/>
  <rect x="10" y="36" width="18" height="18" rx="5" fill="#1F2735"/>
  <rect x="36" y="36" width="18" height="18" rx="5" fill="#FF4D6D"/>
</svg>
`;

/** Builds a real .zip in memory so the demo goes through the exact same pipeline. */
export async function makeSampleFile(): Promise<PickedFile> {
  const zip = new JSZip();
  zip.file('index.html', INDEX_HTML);
  zip.file('styles/game.css', GAME_CSS);
  zip.file('scripts/main.js', MAIN_JS);
  zip.file('scripts/board.js', BOARD_JS);
  zip.file('scripts/store.js', STORE_JS);
  zip.file('package.json', PACKAGE_JSON);
  zip.file('README.md', README);
  zip.file('manifest.webmanifest', MANIFEST);
  zip.file('assets/icon.svg', ICON_SVG);
  zip.file('.gitignore', 'node_modules\ndist\n.DS_Store\n');

  const bytes = await zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE' });
  return {
    name: 'neon-tap-game.zip',
    size: bytes.length,
    uri: '',
    bytes,
    source: 'sample',
  };
}
