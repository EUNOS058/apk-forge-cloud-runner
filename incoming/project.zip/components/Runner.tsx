import React, { useCallback } from 'react';
import { View } from 'react-native';
import { WebView } from 'react-native-webview';

export type RunnerMessage =
  | { type: 'console'; payload: { level: string; text: string } }
  | { type: 'ready'; payload: { title: string } }
  | { type: 'navigate'; payload: { href: string } };

export type RunnerProps = {
  html: string;
  bg: string;
  reloadKey: number;
  onMessage: (m: RunnerMessage) => void;
};

export default function Runner({ html, bg, reloadKey, onMessage }: RunnerProps) {
  const handle = useCallback(
    (e: any) => {
      try {
        const data = JSON.parse(e.nativeEvent.data);
        if (data && data.__apkstudio) onMessage(data as RunnerMessage);
      } catch {
        /* ignore non-json */
      }
    },
    [onMessage]
  );

  return (
    <View style={{ flex: 1, backgroundColor: bg, overflow: 'hidden' }}>
      <WebView
        key={reloadKey}
        source={{ html }}
        originWhitelist={['*']}
        onMessage={handle}
        javaScriptEnabled
        domStorageEnabled
        allowFileAccess
        allowFileAccessFromFileURLs
        allowUniversalAccessFromFileURLs
        mixedContentMode="always"
        setSupportMultipleWindows={false}
        style={{ flex: 1, backgroundColor: bg }}
      />
    </View>
  );
}
