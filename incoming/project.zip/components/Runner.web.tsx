import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';
import type { RunnerProps, RunnerMessage } from './Runner';

export type { RunnerProps, RunnerMessage };

export default function Runner({ html, bg, reloadKey, onMessage }: RunnerProps) {
  const ref = useRef<any>(null);

  useEffect(() => {
    const g: any = globalThis as any;
    if (!g.addEventListener) return;
    const handler = (ev: any) => {
      try {
        const data = typeof ev.data === 'string' ? JSON.parse(ev.data) : ev.data;
        if (data && data.__apkstudio) onMessage(data as RunnerMessage);
      } catch {
        /* ignore */
      }
    };
    g.addEventListener('message', handler);
    return () => g.removeEventListener('message', handler);
  }, [onMessage]);

  return (
    <View style={{ flex: 1, backgroundColor: bg, overflow: 'hidden' }}>
      {React.createElement('iframe', {
        ref,
        key: reloadKey,
        srcDoc: html,
        sandbox: 'allow-scripts allow-forms allow-modals allow-popups allow-same-origin',
        style: {
          border: 'none',
          width: '100%',
          height: '100%',
          background: bg,
          display: 'block',
        },
      })}
    </View>
  );
}
