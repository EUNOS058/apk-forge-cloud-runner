import React, { useMemo } from 'react';
import { View } from 'react-native';
import QRCode from 'qrcode';

/**
 * Dependency-light QR renderer: builds the module matrix with `qrcode`
 * and paints it with plain Views (works identically on native and web).
 */
export default function QR({
  value,
  size = 180,
  dark = '#0A0F14',
  light = '#FFFFFF',
}: {
  value: string;
  size?: number;
  dark?: string;
  light?: string;
}) {
  const matrix = useMemo(() => {
    try {
      const qr = QRCode.create(value || ' ', { errorCorrectionLevel: 'M' });
      const n = qr.modules.size;
      const data = qr.modules.data;
      const rows: boolean[][] = [];
      for (let y = 0; y < n; y++) {
        const row: boolean[] = [];
        for (let x = 0; x < n; x++) row.push(!!data[y * n + x]);
        rows.push(row);
      }
      return rows;
    } catch {
      return null;
    }
  }, [value]);

  if (!matrix) {
    return <View style={{ width: size, height: size, backgroundColor: light, borderRadius: 8 }} />;
  }

  const n = matrix.length;
  const quiet = 2;
  const cell = size / (n + quiet * 2);

  return (
    <View
      style={{
        width: size,
        height: size,
        backgroundColor: light,
        borderRadius: 10,
        padding: cell * quiet,
      }}
    >
      {matrix.map((row, y) => (
        <View key={y} style={{ flexDirection: 'row', height: cell }}>
          {row.map((on, x) => (
            <View
              key={x}
              style={{ width: cell, height: cell, backgroundColor: on ? dark : light }}
            />
          ))}
        </View>
      ))}
    </View>
  );
}
