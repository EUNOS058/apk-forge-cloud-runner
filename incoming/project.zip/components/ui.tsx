import React, { useEffect, useRef } from 'react';
import {
  ActivityIndicator,
  Animated,
  Easing,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextStyle,
  View,
  ViewStyle,
} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../lib/store';
import { radius } from '../lib/theme';

export function Card({
  children,
  style,
  padded = true,
}: {
  children: React.ReactNode;
  style?: ViewStyle | ViewStyle[];
  padded?: boolean;
}) {
  const { p } = useApp();
  return (
    <View
      style={[
        {
          backgroundColor: p.surface,
          borderRadius: radius.lg,
          borderWidth: 1,
          borderColor: p.border,
          padding: padded ? 16 : 0,
          shadowColor: '#000',
          shadowOpacity: p.mode === 'dark' ? 0.35 : 0.07,
          shadowRadius: 16,
          shadowOffset: { width: 0, height: 8 },
          elevation: 3,
        },
        style as ViewStyle,
      ]}
    >
      {children}
    </View>
  );
}

export function SectionTitle({
  title,
  right,
  icon,
}: {
  title: string;
  right?: React.ReactNode;
  icon?: string;
}) {
  const { p } = useApp();
  return (
    <View style={styles.sectionRow}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 }}>
        {icon ? <Ionicons name={icon as any} size={15} color={p.muted} /> : null}
        <Text
          style={{
            color: p.muted,
            fontSize: 12,
            fontWeight: '700',
            letterSpacing: 1.1,
            textTransform: 'uppercase',
          }}
        >
          {title}
        </Text>
      </View>
      {right}
    </View>
  );
}

export function Btn({
  label,
  onPress,
  icon,
  variant = 'primary',
  loading,
  disabled,
  style,
  small,
}: {
  label: string;
  onPress: () => void;
  icon?: string;
  variant?: 'primary' | 'ghost' | 'danger' | 'violet';
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
  small?: boolean;
}) {
  const { p } = useApp();
  const bg =
    variant === 'primary'
      ? p.accent
      : variant === 'violet'
      ? p.violet
      : variant === 'danger'
      ? p.dangerSoft
      : 'transparent';
  const fg =
    variant === 'primary'
      ? '#05130B'
      : variant === 'violet'
      ? '#FFFFFF'
      : variant === 'danger'
      ? p.danger
      : p.text;
  const scale = useRef(new Animated.Value(1)).current;

  return (
    <Animated.View style={{ transform: [{ scale }], opacity: disabled ? 0.45 : 1 }}>
      <Pressable
        disabled={disabled || loading}
        onPressIn={() =>
          Animated.spring(scale, { toValue: 0.965, useNativeDriver: true, speed: 40 }).start()
        }
        onPressOut={() =>
          Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 40 }).start()
        }
        onPress={onPress}
        style={[
          {
            backgroundColor: bg,
            borderRadius: radius.md,
            paddingVertical: small ? 10 : 15,
            paddingHorizontal: small ? 14 : 18,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 9,
            borderWidth: variant === 'ghost' ? 1 : 0,
            borderColor: p.border,
          },
          style,
        ]}
      >
        {loading ? (
          <ActivityIndicator size="small" color={fg} />
        ) : icon ? (
          <Ionicons name={icon as any} size={small ? 15 : 18} color={fg} />
        ) : null}
        <Text
          numberOfLines={1}
          style={{ color: fg, fontWeight: '700', fontSize: small ? 13 : 15, letterSpacing: 0.2 }}
        >
          {label}
        </Text>
      </Pressable>
    </Animated.View>
  );
}

export function Badge({
  text,
  color,
  bg,
  icon,
}: {
  text: string;
  color?: string;
  bg?: string;
  icon?: string;
}) {
  const { p } = useApp();
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 5,
        backgroundColor: bg || p.surfaceAlt,
        paddingHorizontal: 9,
        paddingVertical: 5,
        borderRadius: 999,
      }}
    >
      {icon ? <Ionicons name={icon as any} size={12} color={color || p.textDim} /> : null}
      <Text style={{ color: color || p.textDim, fontSize: 11.5, fontWeight: '700' }}>{text}</Text>
    </View>
  );
}

export function ProgressBar({ value, color }: { value: number; color?: string }) {
  const { p } = useApp();
  const w = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(w, {
      toValue: Math.max(0, Math.min(1, value)),
      duration: 320,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
  }, [value, w]);
  return (
    <View
      style={{
        height: 8,
        borderRadius: 999,
        backgroundColor: p.surfaceAlt,
        overflow: 'hidden',
      }}
    >
      <Animated.View
        style={{
          height: '100%',
          borderRadius: 999,
          backgroundColor: color || p.accent,
          width: w.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }),
        }}
      />
    </View>
  );
}

export function EmptyState({
  icon,
  title,
  subtitle,
  action,
}: {
  icon: string;
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}) {
  const { p } = useApp();
  return (
    <View style={{ alignItems: 'center', paddingVertical: 46, paddingHorizontal: 24 }}>
      <View
        style={{
          width: 74,
          height: 74,
          borderRadius: 24,
          backgroundColor: p.surfaceAlt,
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: 16,
        }}
      >
        <Ionicons name={icon as any} size={32} color={p.muted} />
      </View>
      <Text style={{ color: p.text, fontSize: 17, fontWeight: '700', textAlign: 'center' }}>
        {title}
      </Text>
      {subtitle ? (
        <Text
          style={{
            color: p.muted,
            fontSize: 13.5,
            textAlign: 'center',
            marginTop: 7,
            lineHeight: 20,
          }}
        >
          {subtitle}
        </Text>
      ) : null}
      {action ? <View style={{ marginTop: 18 }}>{action}</View> : null}
    </View>
  );
}

export function Chip({
  label,
  active,
  onPress,
  icon,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
  icon?: string;
}) {
  const { p } = useApp();
  return (
    <Pressable
      onPress={onPress}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        paddingHorizontal: 13,
        paddingVertical: 9,
        borderRadius: 999,
        backgroundColor: active ? p.accentSoft : p.surfaceAlt,
        borderWidth: 1,
        borderColor: active ? p.accent : 'transparent',
      }}
    >
      {icon ? (
        <Ionicons name={icon as any} size={13} color={active ? p.accent : p.textDim} />
      ) : null}
      <Text
        style={{
          color: active ? p.accent : p.textDim,
          fontWeight: '700',
          fontSize: 13,
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}

export function Row({
  label,
  value,
  icon,
  onPress,
  valueColor,
}: {
  label: string;
  value?: string;
  icon?: string;
  onPress?: () => void;
  valueColor?: string;
}) {
  const { p } = useApp();
  const body = (
    <View style={styles.row}>
      {icon ? (
        <View
          style={{
            width: 30,
            height: 30,
            borderRadius: 9,
            backgroundColor: p.surfaceAlt,
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: 11,
          }}
        >
          <Ionicons name={icon as any} size={15} color={p.textDim} />
        </View>
      ) : null}
      <Text style={{ color: p.text, fontSize: 14.5, flex: 1, fontWeight: '600' }}>{label}</Text>
      {value ? (
        <Text style={{ color: valueColor || p.muted, fontSize: 13.5, fontWeight: '600' }}>
          {value}
        </Text>
      ) : null}
      {onPress ? (
        <Ionicons name="chevron-forward" size={16} color={p.muted} style={{ marginLeft: 6 }} />
      ) : null}
    </View>
  );
  if (!onPress) return body;
  return (
    <Pressable onPress={onPress} style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1 })}>
      {body}
    </Pressable>
  );
}

export function Divider() {
  const { p } = useApp();
  return <View style={{ height: 1, backgroundColor: p.border, marginVertical: 4 }} />;
}

export function FadeIn({
  children,
  delay = 0,
  style,
}: {
  children: React.ReactNode;
  delay?: number;
  style?: ViewStyle;
}) {
  const a = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(a, {
      toValue: 1,
      duration: 380,
      delay,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [a, delay]);
  return (
    <Animated.View
      style={[
        style,
        {
          opacity: a,
          transform: [{ translateY: a.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }],
        },
      ]}
    >
      {children}
    </Animated.View>
  );
}

export const monoFont = Platform.select({
  ios: 'Menlo',
  android: 'monospace',
  default: 'ui-monospace, SFMono-Regular, Menlo, monospace',
}) as string;

export function MonoText({
  children,
  style,
  numberOfLines,
}: {
  children: React.ReactNode;
  style?: TextStyle | TextStyle[];
  numberOfLines?: number;
}) {
  return (
    <Text numberOfLines={numberOfLines} style={[{ fontFamily: monoFont, fontSize: 12 }, style]}>
      {children}
    </Text>
  );
}

const styles = StyleSheet.create({
  sectionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 11,
    marginTop: 4,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 11,
  },
});
