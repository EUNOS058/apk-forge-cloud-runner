import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  Easing,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../lib/store';
import { formatBytes, ingest, toPackageId } from '../lib/zip';
import {
  fetchZip,
  FolderZip,
  isZipBytes,
  listFolderZips,
  PickedFile,
  pickFrom,
  readFolderZip,
  SOURCES,
  SourceId,
} from '../lib/pick';
import { makeSampleFile } from '../lib/sample';
import { buildAndroidProject, ExportKind, outputBaseName, saveZip } from '../lib/export';
import { logColor } from '../lib/theme';
import { MonoText } from '../components/ui';

/* ------------------------------------------------------------------ pieces */

function useFade(active: boolean, delay = 0) {
  const a = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(a, {
      toValue: active ? 1 : 0,
      duration: 320,
      delay,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [a, active, delay]);
  return a;
}

type StepState = 'todo' | 'active' | 'done' | 'failed';

function StepShell({
  n,
  title,
  sub,
  state,
  children,
  last,
}: {
  n: number;
  title: string;
  sub?: string;
  state: StepState;
  children?: React.ReactNode;
  last?: boolean;
}) {
  const { p } = useApp();
  const ringColor =
    state === 'done' ? p.accent : state === 'failed' ? p.danger : state === 'active' ? p.violet : p.border;
  const ringBg =
    state === 'done' ? p.accent : state === 'failed' ? p.dangerSoft : state === 'active' ? p.violetSoft : 'transparent';

  return (
    <View style={{ flexDirection: 'row' }}>
      {/* rail */}
      <View style={{ width: 40, alignItems: 'center' }}>
        <View
          style={[
            styles.ring,
            { borderColor: ringColor, backgroundColor: ringBg },
          ]}
        >
          {state === 'done' ? (
            <Ionicons name="checkmark" size={16} color={p.accentText} />
          ) : state === 'failed' ? (
            <Ionicons name="close" size={15} color={p.danger} />
          ) : (
            <Text
              style={{
                color: state === 'active' ? p.violet : p.muted,
                fontWeight: '800',
                fontSize: 13,
              }}
            >
              {n}
            </Text>
          )}
        </View>
        {!last ? (
          <View
            style={{
              flex: 1,
              width: 2,
              marginTop: 4,
              marginBottom: 4,
              borderRadius: 2,
              backgroundColor: state === 'done' ? p.accent : p.borderSoft,
              opacity: state === 'done' ? 0.45 : 1,
            }}
          />
        ) : null}
      </View>

      {/* body */}
      <View style={{ flex: 1, paddingBottom: last ? 8 : 26 }}>
        <Text
          style={{
            color: state === 'todo' ? p.muted : p.text,
            fontSize: 16,
            fontWeight: '800',
            letterSpacing: -0.2,
            marginTop: 4,
          }}
        >
          {title}
        </Text>
        {sub ? (
          <Text style={{ color: p.muted, fontSize: 12.5, marginTop: 3, lineHeight: 18 }}>{sub}</Text>
        ) : null}
        {children ? <View style={{ marginTop: 13 }}>{children}</View> : null}
      </View>
    </View>
  );
}

function Button({
  label,
  onPress,
  icon,
  tone = 'primary',
  loading,
  disabled,
  style,
  compact,
}: {
  label: string;
  onPress: () => void;
  icon?: string;
  tone?: 'primary' | 'outline' | 'quiet' | 'violet';
  loading?: boolean;
  disabled?: boolean;
  style?: any;
  compact?: boolean;
}) {
  const { p } = useApp();
  const scale = useRef(new Animated.Value(1)).current;
  const bg =
    tone === 'primary' ? p.accent : tone === 'violet' ? p.violet : tone === 'quiet' ? p.surfaceAlt : 'transparent';
  const fg =
    tone === 'primary' ? p.accentText : tone === 'violet' ? '#FFFFFF' : p.text;

  return (
    <Animated.View style={[{ transform: [{ scale }], opacity: disabled ? 0.4 : 1 }, style]}>
      <Pressable
        disabled={disabled || loading}
        onPressIn={() => Animated.spring(scale, { toValue: 0.97, useNativeDriver: true, speed: 45 }).start()}
        onPressOut={() => Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 45 }).start()}
        onPress={onPress}
        style={{
          backgroundColor: bg,
          borderWidth: tone === 'outline' ? 1.3 : 0,
          borderColor: p.border,
          borderRadius: 14,
          paddingVertical: compact ? 11 : 15,
          paddingHorizontal: compact ? 14 : 18,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 8,
        }}
      >
        {loading ? (
          <ActivityIndicator size="small" color={fg} />
        ) : icon ? (
          <Ionicons name={icon as any} size={compact ? 15 : 18} color={fg} />
        ) : null}
        <Text numberOfLines={1} style={{ color: fg, fontWeight: '800', fontSize: compact ? 13 : 15 }}>
          {label}
        </Text>
      </Pressable>
    </Animated.View>
  );
}

function Sheet({
  visible,
  onClose,
  title,
  sub,
  children,
  avoidKeyboard,
}: {
  visible: boolean;
  onClose: () => void;
  title: string;
  sub?: string;
  children: React.ReactNode;
  avoidKeyboard?: boolean;
}) {
  const { p } = useApp();
  const Wrap: any = avoidKeyboard ? KeyboardAvoidingView : View;
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Wrap
        style={styles.modalWrap}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={[styles.sheet, { backgroundColor: p.surface, borderColor: p.border }]}>
          <View style={[styles.grabber, { backgroundColor: p.border }]} />
          <Text style={{ color: p.text, fontSize: 18, fontWeight: '900', letterSpacing: -0.3 }}>{title}</Text>
          {sub ? (
            <Text style={{ color: p.muted, fontSize: 12.5, marginTop: 5, lineHeight: 18 }}>{sub}</Text>
          ) : null}
          <View style={{ marginTop: 16 }}>{children}</View>
        </View>
      </Wrap>
    </Modal>
  );
}

/* -------------------------------------------------------------------- main */

export default function HomeScreen() {
  const {
    p,
    lang,
    mode,
    setLang,
    setMode,
    activeProject,
    activeVfs,
    addProject,
    config,
    patchConfig,
    current,
    progress,
    isBuilding,
    startBuild,
  } = useApp();
  const nav: any = useNavigation();

  const [picking, setPicking] = useState(false);
  const [reading, setReading] = useState(false);
  const [error, setError] = useState<{ msg: string; hint?: string } | null>(null);
  const [sourceOpen, setSourceOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [folderZips, setFolderZips] = useState<FolderZip[] | null>(null);
  const [urlOpen, setUrlOpen] = useState(false);
  const [url, setUrl] = useState('');
  const [saving, setSaving] = useState<ExportKind | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const autoBuilt = useRef<Set<string>>(new Set());

  const bn = lang === 'bn';

  /* ---------------------------------------------------------- step state */
  const built = current?.status === 'success';
  const failed = current?.status === 'failed' || current?.status === 'cancelled';

  const step1: StepState = activeProject ? 'done' : 'active';
  const step2: StepState = !activeProject
    ? 'todo'
    : isBuilding
    ? 'active'
    : built
    ? 'done'
    : failed
    ? 'failed'
    : 'active';
  const step3: StepState = built ? 'active' : 'todo';

  /* -------------------------------------------------------------- import */
  const load = useCallback(
    async (file: PickedFile) => {
      setReading(true);
      setError(null);
      try {
        const { project, vfs } = await ingest(file);
        if (vfs.files.size === 0) {
          setError({ msg: bn ? 'ZIP ফাইলটি খালি' : 'The ZIP archive is empty' });
          return;
        }
        addProject(project, vfs);
      } catch (e: any) {
        setError({
          msg: bn ? 'আর্কাইভ পড়া যায়নি' : 'Could not read the archive',
          hint: String(e?.message || e).slice(0, 100),
        });
      } finally {
        setReading(false);
      }
    },
    [addProject, bn]
  );

  const choose = useCallback(
    async (source: SourceId) => {
      setSourceOpen(false);
      setError(null);

      if (source === 'sample') {
        setReading(true);
        await load(await makeSampleFile());
        return;
      }
      if (source === 'url') {
        setUrlOpen(true);
        return;
      }
      if (source === 'folder') {
        if (Platform.OS !== 'android') {
          setError({
            msg: bn ? 'ফোল্ডার বাছাই শুধু Android-এ' : 'Folder picking is Android only',
            hint: bn ? 'স্টোরেজ অপশন নিন।' : 'Use the Storage option.',
          });
          return;
        }
        setPicking(true);
        const res = await listFolderZips();
        setPicking(false);
        if (!res.ok) {
          if (res.reason !== 'cancelled') {
            setError({ msg: bn ? 'ফোল্ডার খোলা যায়নি' : 'Could not open the folder', hint: res.reason });
          }
          return;
        }
        if (res.zips.length === 0) {
          setError({
            msg: bn ? 'এই ফোল্ডারে ZIP নেই' : 'No ZIP files in that folder',
            hint: bn ? 'Download ফোল্ডারটি বেছে দেখুন।' : 'Try the Download folder.',
          });
          return;
        }
        setFolderZips(res.zips);
        return;
      }

      setPicking(true);
      const res = await pickFrom(source);
      setPicking(false);
      if (!res.ok) {
        if (res.reason === 'cancelled') return;
        if (res.reason === 'invalid') {
          setError({
            msg: bn ? 'এটি ZIP আর্কাইভ নয়' : 'That file is not a ZIP archive',
            hint:
              source === 'gallery'
                ? bn
                  ? 'গ্যালারিতে আর্কাইভ থাকে না — "স্টোরেজ" নিন।'
                  : 'Galleries hold no archives — use Storage.'
                : bn
                ? 'ফাইলটি .zip কিনা দেখুন।'
                : 'Check the file really ends in .zip.',
          });
        } else {
          setError({
            msg: bn ? 'পিকার খোলা যায়নি' : 'The picker could not open',
            hint: res.message,
          });
        }
        return;
      }
      await load(res.file);
    },
    [bn, load]
  );

  /* web drag & drop */
  useEffect(() => {
    if (Platform.OS !== 'web') return;
    const g: any = globalThis as any;
    if (!g.document) return;
    const prevent = (e: any) => e.preventDefault();
    const drop = async (e: any) => {
      e.preventDefault();
      const f = e.dataTransfer?.files?.[0];
      if (!f) return;
      const bytes = new Uint8Array(await f.arrayBuffer());
      if (!isZipBytes(bytes)) {
        setError({ msg: bn ? 'এটি ZIP আর্কাইভ নয়' : 'That file is not a ZIP archive' });
        return;
      }
      load({ name: f.name, size: f.size, uri: '', bytes, source: 'storage' });
    };
    g.document.addEventListener('dragover', prevent);
    g.document.addEventListener('drop', drop);
    return () => {
      g.document.removeEventListener('dragover', prevent);
      g.document.removeEventListener('drop', drop);
    };
  }, [bn, load]);

  const importUrl = useCallback(async () => {
    const target = url.trim();
    if (!target) return;
    setUrlOpen(false);
    setReading(true);
    const res = await fetchZip(target);
    setReading(false);
    if (!res.ok) {
      setError({
        msg:
          res.reason === 'invalid'
            ? bn
              ? 'লিংকটি ZIP দেয়নি'
              : 'That link returned no ZIP'
            : bn
            ? 'ডাউনলোড ব্যর্থ'
            : 'Download failed',
        hint: res.message,
      });
      return;
    }
    await load(res.file);
  }, [bn, load, url]);

  /* ---------------------------------------------------- auto build once */
  useEffect(() => {
    if (!activeProject || !activeVfs) return;
    if (autoBuilt.current.has(activeProject.id)) return;
    autoBuilt.current.add(activeProject.id);
    const id = setTimeout(() => startBuild(), 420);
    return () => clearTimeout(id);
  }, [activeProject, activeVfs, startBuild]);

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 3600);
    return () => clearTimeout(id);
  }, [toast]);

  /* -------------------------------------------------------------- export */
  const doExport = useCallback(
    async (kind: ExportKind) => {
      if (!activeProject || !activeVfs) return;
      setSaving(kind);
      try {
        const zip = await buildAndroidProject(
          activeVfs,
          activeProject,
          config,
          current?.checksum ?? 'draft',
          kind
        );
        const base = outputBaseName(config);
        const name =
          kind === 'source'
            ? `${base}-source.zip`
            : kind === 'web'
            ? `${base}-installable-web.zip`
            : `${base}-${config.version}-android.zip`;
        const res = await saveZip(zip, name);
        setToast(
          res.ok
            ? res.where === 'downloads'
              ? bn
                ? `✔ ফোল্ডারে সেভ হয়েছে · ${name}`
                : `✔ Saved · ${name}`
              : bn
              ? `✔ শেয়ার শিটে পাঠানো হয়েছে · ${name}`
              : `✔ Sent to share sheet · ${name}`
            : `${bn ? 'ব্যর্থ' : 'Failed'}: ${res.message}`
        );
      } catch (e: any) {
        setToast(String(e?.message || e));
      } finally {
        setSaving(null);
      }
    },
    [activeProject, activeVfs, bn, config, current]
  );

  const lastLogs = useMemo(() => (current?.logs ?? []).slice(-4), [current]);
  const runningStep = current?.steps.find((s) => s.state === 'running');

  const tint = (k: string) => (k === 'accent' ? p.accent : k === 'violet' ? p.violet : p.warn);
  const soft = (k: string) => (k === 'accent' ? p.accentSoft : k === 'violet' ? p.violetSoft : p.warnSoft);

  const fadeIn = useFade(true);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: p.bg }} edges={['top']}>
      {/* ------------------------------------------------------- app bar */}
      <View style={styles.appbar}>
        <View style={[styles.brand, { backgroundColor: p.accentSoft }]}>
          <Ionicons name="logo-android" size={19} color={p.accent} />
        </View>
        <View style={{ flex: 1, marginLeft: 11 }}>
          <Text style={{ color: p.text, fontSize: 17, fontWeight: '900', letterSpacing: -0.4 }}>
            APK Studio
          </Text>
          <Text style={{ color: p.muted, fontSize: 11.5, marginTop: 1 }}>
            {bn ? 'ZIP → অ্যান্ড্রয়েড অ্যাপ' : 'ZIP → Android app'}
          </Text>
        </View>
        {activeVfs ? (
          <Pressable onPress={() => nav.navigate('Preview')} hitSlop={8} style={styles.barBtn}>
            <Ionicons name="play-circle-outline" size={21} color={p.textDim} />
          </Pressable>
        ) : null}
        <Pressable onPress={() => setSettingsOpen(true)} hitSlop={8} style={styles.barBtn}>
          <Ionicons name="settings-outline" size={19} color={p.textDim} />
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 8, paddingBottom: 44 }}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View
          style={{
            opacity: fadeIn,
            transform: [{ translateY: fadeIn.interpolate({ inputRange: [0, 1], outputRange: [12, 0] }) }],
          }}
        >
          {/* ============================================ STEP 1 — ZIP */}
          <StepShell
            n={1}
            state={step1}
            title={bn ? 'ZIP ফাইল বাছুন' : 'Choose your ZIP'}
            sub={
              activeProject
                ? undefined
                : bn
                ? 'ফোনের স্টোরেজ, ফোল্ডার বা লিংক থেকে'
                : 'From storage, a folder, or a link'
            }
          >
            {activeProject ? (
              <Pressable
                onPress={() => setSourceOpen(true)}
                style={[styles.fileCard, { backgroundColor: p.surface, borderColor: p.border }]}
              >
                <View style={[styles.fileIcon, { backgroundColor: soft('accent') }]}>
                  <Ionicons name="document-attach" size={19} color={p.accent} />
                </View>
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <MonoText numberOfLines={1} style={{ color: p.text, fontSize: 12.5, fontWeight: '700' }}>
                    {activeProject.fileName}
                  </MonoText>
                  <Text style={{ color: p.muted, fontSize: 11.5, marginTop: 3 }}>
                    {activeVfs?.files.size ?? 0} {bn ? 'ফাইল' : 'files'} ·{' '}
                    {formatBytes(activeProject.sizeBytes)} · {activeProject.framework.label}
                  </Text>
                </View>
                <Ionicons name="swap-horizontal" size={17} color={p.muted} />
              </Pressable>
            ) : (
              <>
                <Button
                  label={bn ? 'ZIP ফাইল বাছুন' : 'Select ZIP file'}
                  icon="folder-open"
                  onPress={() => setSourceOpen(true)}
                  loading={picking || reading}
                />
                <Pressable onPress={() => choose('sample')} style={{ marginTop: 12, alignSelf: 'center' }}>
                  <Text style={{ color: p.violet, fontSize: 13, fontWeight: '700' }}>
                    {bn ? 'অথবা ডেমো প্রজেক্ট দিয়ে দেখুন' : 'or try the demo project'}
                  </Text>
                </Pressable>
              </>
            )}

            {error ? (
              <View style={[styles.errBox, { backgroundColor: p.dangerSoft, borderColor: p.danger }]}>
                <Ionicons name="alert-circle" size={16} color={p.danger} />
                <View style={{ flex: 1 }}>
                  <Text style={{ color: p.danger, fontSize: 12.5, fontWeight: '700' }}>{error.msg}</Text>
                  {error.hint ? (
                    <Text style={{ color: p.textDim, fontSize: 11.5, marginTop: 2 }}>{error.hint}</Text>
                  ) : null}
                </View>
                <Pressable onPress={() => setSourceOpen(true)} hitSlop={8}>
                  <Text style={{ color: p.accent, fontSize: 12, fontWeight: '800' }}>
                    {bn ? 'আবার' : 'Retry'}
                  </Text>
                </Pressable>
              </View>
            ) : null}
          </StepShell>

          {/* ========================================== STEP 2 — BUILD */}
          <StepShell
            n={2}
            state={step2}
            title={bn ? 'বিল্ড' : 'Build'}
            sub={
              !activeProject
                ? bn
                  ? 'ZIP বাছলেই নিজে থেকে শুরু হবে'
                  : 'Starts automatically once a ZIP is loaded'
                : undefined
            }
          >
            {activeProject ? (
              <View style={[styles.buildCard, { backgroundColor: p.surface, borderColor: p.border }]}>
                {/* app identity */}
                <Pressable
                  onPress={() => setDetailsOpen(true)}
                  style={{ flexDirection: 'row', alignItems: 'center' }}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: p.text, fontSize: 14.5, fontWeight: '800' }} numberOfLines={1}>
                      {config.appName}
                    </Text>
                    <MonoText style={{ color: p.muted, marginTop: 3 }} numberOfLines={1}>
                      {config.packageId} · v{config.version}
                    </MonoText>
                  </View>
                  <View style={[styles.editPill, { backgroundColor: p.surfaceAlt }]}>
                    <Ionicons name="create-outline" size={14} color={p.textDim} />
                    <Text style={{ color: p.textDim, fontSize: 11.5, fontWeight: '700', marginLeft: 4 }}>
                      {bn ? 'বদলান' : 'Edit'}
                    </Text>
                  </View>
                </Pressable>

                <View style={[styles.hr, { backgroundColor: p.borderSoft }]} />

                {/* progress */}
                <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                  {isBuilding ? (
                    <ActivityIndicator size="small" color={p.violet} />
                  ) : (
                    <Ionicons
                      name={built ? 'checkmark-circle' : failed ? 'close-circle' : 'ellipse-outline'}
                      size={17}
                      color={built ? p.accent : failed ? p.danger : p.muted}
                    />
                  )}
                  <Text
                    style={{
                      color: p.text,
                      fontSize: 13.5,
                      fontWeight: '700',
                      flex: 1,
                      marginLeft: 9,
                    }}
                    numberOfLines={1}
                  >
                    {isBuilding
                      ? runningStep
                        ? bn
                          ? runningStep.labelBn
                          : runningStep.label
                        : bn
                        ? 'চলছে…'
                        : 'Working…'
                      : built
                      ? bn
                        ? 'বিল্ড সফল'
                        : 'Build succeeded'
                      : failed
                      ? bn
                        ? 'বিল্ড ব্যর্থ'
                        : 'Build failed'
                      : bn
                      ? 'অপেক্ষা'
                      : 'Queued'}
                  </Text>
                  <MonoText style={{ color: p.muted, fontSize: 11.5 }}>
                    {Math.round(progress * 100)}%
                  </MonoText>
                </View>

                <View style={[styles.track, { backgroundColor: p.surfaceAlt }]}>
                  <View
                    style={{
                      height: '100%',
                      borderRadius: 999,
                      width: `${Math.max(2, Math.min(100, progress * 100))}%`,
                      backgroundColor: failed ? p.danger : built ? p.accent : p.violet,
                    }}
                  />
                </View>

                {/* live log tail */}
                {lastLogs.length ? (
                  <View
                    style={[
                      styles.logBox,
                      { backgroundColor: p.terminal, borderColor: p.borderSoft },
                    ]}
                  >
                    {lastLogs.map((l, i) => (
                      <MonoText
                        key={`${l.t}-${i}`}
                        numberOfLines={1}
                        style={{ color: logColor(p, l.level), fontSize: 10.5, lineHeight: 16 }}
                      >
                        {l.text}
                      </MonoText>
                    ))}
                  </View>
                ) : null}

                {!isBuilding ? (
                  <Button
                    label={
                      built
                        ? bn
                          ? 'আবার বিল্ড করুন'
                          : 'Rebuild'
                        : bn
                        ? 'বিল্ড শুরু করুন'
                        : 'Start build'
                    }
                    icon={built ? 'refresh' : 'hammer'}
                    tone={built ? 'outline' : 'primary'}
                    compact
                    onPress={startBuild}
                    style={{ marginTop: 12 }}
                  />
                ) : null}
              </View>
            ) : null}
          </StepShell>

          {/* ========================================= STEP 3 — DOWNLOAD */}
          <StepShell
            n={3}
            state={step3}
            last
            title={bn ? 'APK ডাউনলোড' : 'Download the APK'}
            sub={
              built
                ? bn
                  ? 'দুটি উপায় — যেটি সহজ সেটি নিন'
                  : 'Two routes — pick whichever suits you'
                : bn
                ? 'বিল্ড শেষ হলে চালু হবে'
                : 'Unlocks when the build finishes'
            }
          >
            {built ? (
              <View>
                <Pressable
                  onPress={() => doExport('web')}
                  style={[styles.route, { backgroundColor: p.surface, borderColor: p.accent }]}
                >
                  <View style={[styles.routeIcon, { backgroundColor: soft('accent') }]}>
                    {saving === 'web' ? (
                      <ActivityIndicator size="small" color={p.accent} />
                    ) : (
                      <Ionicons name="flash" size={20} color={p.accent} />
                    )}
                  </View>
                  <View style={{ flex: 1, marginLeft: 13 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}>
                      <Text style={{ color: p.text, fontSize: 14.5, fontWeight: '800' }}>
                        {bn ? 'সরাসরি ইনস্টল' : 'Instant install'}
                      </Text>
                      <View style={[styles.tag, { backgroundColor: p.accentSoft }]}>
                        <Text style={{ color: p.accent, fontSize: 9.5, fontWeight: '900' }}>
                          {bn ? 'সহজ' : 'EASIEST'}
                        </Text>
                      </View>
                    </View>
                    <Text style={{ color: p.muted, fontSize: 12, marginTop: 3, lineHeight: 17 }}>
                      {bn
                        ? 'ফোল্ডার হোস্ট করে Chrome-এ "Install app" — Android নিজেই আসল অ্যাপ বানায়'
                        : 'Host the folder, tap “Install app” in Chrome — Android builds a real app'}
                    </Text>
                  </View>
                  <Ionicons name="download-outline" size={18} color={p.accent} />
                </Pressable>

                <Pressable
                  onPress={() => doExport('project')}
                  style={[styles.route, { backgroundColor: p.surface, borderColor: p.border, marginTop: 10 }]}
                >
                  <View style={[styles.routeIcon, { backgroundColor: soft('violet') }]}>
                    {saving === 'project' ? (
                      <ActivityIndicator size="small" color={p.violet} />
                    ) : (
                      <Ionicons name="logo-android" size={20} color={p.violet} />
                    )}
                  </View>
                  <View style={{ flex: 1, marginLeft: 13 }}>
                    <Text style={{ color: p.text, fontSize: 14.5, fontWeight: '800' }}>
                      {bn ? '.apk ফাইল বানান' : 'Real .apk file'}
                    </Text>
                    <Text style={{ color: p.muted, fontSize: 12, marginTop: 3, lineHeight: 17 }}>
                      {bn
                        ? 'বিল্ড প্যাক — GitHub-এ আপলোড করলে ~৮ মিনিটে .apk দেয়'
                        : 'Build pack — upload to GitHub and get an .apk in ~8 min'}
                    </Text>
                  </View>
                  <Ionicons name="download-outline" size={18} color={p.muted} />
                </Pressable>

                <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
                  <Button
                    label={bn ? 'পূর্ণ গাইড' : 'Full guide'}
                    icon="book-outline"
                    tone="quiet"
                    compact
                    onPress={() => nav.navigate('Guide')}
                    style={{ flex: 1 }}
                  />
                  <Button
                    label={bn ? 'শুধু সোর্স' : 'Source only'}
                    icon="archive-outline"
                    tone="quiet"
                    compact
                    loading={saving === 'source'}
                    onPress={() => doExport('source')}
                    style={{ flex: 1 }}
                  />
                </View>
              </View>
            ) : null}
          </StepShell>
        </Animated.View>
      </ScrollView>

      {toast ? (
        <View style={[styles.toast, { backgroundColor: p.elevated, borderColor: p.border }]}>
          <Ionicons name="checkmark-circle" size={16} color={p.accent} />
          <Text style={{ color: p.text, fontSize: 12.5, flex: 1 }} numberOfLines={2}>
            {toast}
          </Text>
        </View>
      ) : null}

      {/* ------------------------------------------------- source sheet */}
      <Sheet
        visible={sourceOpen}
        onClose={() => setSourceOpen(false)}
        title={bn ? 'ZIP কোথা থেকে নেবেন?' : 'Where is your ZIP?'}
        sub={
          bn
            ? 'একটি কাজ না করলে পরেরটি নিন — প্রতিটি আলাদা পথে যায়।'
            : 'If one route is blocked, try the next — each uses a different API.'
        }
      >
        <ScrollView style={{ maxHeight: 400 }} showsVerticalScrollIndicator={false}>
          {SOURCES.filter((s) => !(s.id === 'folder' && Platform.OS !== 'android')).map((s) => (
            <Pressable
              key={s.id}
              onPress={() => choose(s.id)}
              style={({ pressed }) => [
                styles.srcRow,
                { backgroundColor: pressed ? p.surfaceAlt : 'transparent', borderColor: p.borderSoft },
              ]}
            >
              <View style={[styles.srcIcon, { backgroundColor: soft(s.tint) }]}>
                <Ionicons name={s.icon as any} size={18} color={tint(s.tint)} />
              </View>
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={{ color: p.text, fontSize: 14, fontWeight: '700' }}>
                  {bn ? s.title.bn : s.title.en}
                </Text>
                <Text style={{ color: p.muted, fontSize: 11.5, marginTop: 2, lineHeight: 16 }}>
                  {bn ? s.sub.bn : s.sub.en}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={15} color={p.muted} />
            </Pressable>
          ))}
        </ScrollView>
        <Button
          label={bn ? 'বন্ধ' : 'Close'}
          tone="outline"
          onPress={() => setSourceOpen(false)}
          style={{ marginTop: 12 }}
        />
      </Sheet>

      {/* ------------------------------------------ folder zip results */}
      <Sheet
        visible={!!folderZips}
        onClose={() => setFolderZips(null)}
        title={bn ? 'ফোল্ডারের ZIP ফাইল' : 'ZIP files found'}
        sub={`${folderZips?.length ?? 0} ${bn ? 'টি পাওয়া গেছে' : 'archives'}`}
      >
        <ScrollView style={{ maxHeight: 380 }}>
          {(folderZips ?? []).map((z) => (
            <Pressable
              key={z.uri}
              onPress={async () => {
                setFolderZips(null);
                setReading(true);
                const r = await readFolderZip(z);
                setReading(false);
                if (!r.ok) {
                  setError({ msg: bn ? 'ফাইলটি পড়া যায়নি' : 'Could not read that file' });
                  return;
                }
                await load(r.file);
              }}
              style={({ pressed }) => [
                styles.srcRow,
                { backgroundColor: pressed ? p.surfaceAlt : 'transparent', borderColor: p.borderSoft },
              ]}
            >
              <View style={[styles.srcIcon, { backgroundColor: p.accentSoft }]}>
                <Ionicons name="archive" size={17} color={p.accent} />
              </View>
              <View style={{ flex: 1, marginLeft: 12 }}>
                <MonoText numberOfLines={1} style={{ color: p.text, fontSize: 12 }}>
                  {z.name}
                </MonoText>
                <Text style={{ color: p.muted, fontSize: 11, marginTop: 2 }}>{formatBytes(z.size)}</Text>
              </View>
              <Ionicons name="chevron-forward" size={15} color={p.muted} />
            </Pressable>
          ))}
        </ScrollView>
        <Button
          label={bn ? 'বন্ধ' : 'Close'}
          tone="outline"
          onPress={() => setFolderZips(null)}
          style={{ marginTop: 12 }}
        />
      </Sheet>

      {/* -------------------------------------------------- url import */}
      <Sheet
        visible={urlOpen}
        onClose={() => setUrlOpen(false)}
        title={bn ? 'লিংক থেকে নিন' : 'Import from a link'}
        sub={bn ? 'সরাসরি .zip অথবা GitHub রিপো লিংক।' : 'A direct .zip or a GitHub repo URL.'}
        avoidKeyboard
      >
        <TextInput
          value={url}
          onChangeText={setUrl}
          placeholder="https://github.com/user/repo"
          placeholderTextColor={p.muted}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="url"
          returnKeyType="go"
          onSubmitEditing={importUrl}
          style={[styles.input, { color: p.text, backgroundColor: p.surfaceAlt, borderColor: p.border }]}
        />
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
          <Button
            label={bn ? 'বাতিল' : 'Cancel'}
            tone="outline"
            onPress={() => setUrlOpen(false)}
            style={{ flex: 1 }}
          />
          <Button
            label={bn ? 'ডাউনলোড' : 'Fetch'}
            icon="cloud-download-outline"
            onPress={importUrl}
            style={{ flex: 1.3 }}
          />
        </View>
      </Sheet>

      {/* ------------------------------------------------ app details */}
      <Sheet
        visible={detailsOpen}
        onClose={() => setDetailsOpen(false)}
        title={bn ? 'অ্যাপের তথ্য' : 'App details'}
        sub={bn ? 'APK-তে যা বসবে।' : 'What goes into the APK.'}
        avoidKeyboard
      >
        <ScrollView style={{ maxHeight: 380 }} keyboardShouldPersistTaps="handled">
          <Field
            label={bn ? 'অ্যাপের নাম' : 'App name'}
            value={config.appName}
            onChange={(v) => patchConfig({ appName: v })}
            placeholder="My App"
          />
          <Field
            label={bn ? 'প্যাকেজ আইডি' : 'Package ID'}
            value={config.packageId}
            onChange={(v) => patchConfig({ packageId: v.toLowerCase().replace(/[^a-z0-9._]/g, '') })}
            placeholder="com.company.app"
            mono
            error={
              /^[a-z][a-z0-9_]*(\.[a-z0-9_]+){1,}$/.test(config.packageId)
                ? undefined
                : bn
                ? 'com.company.app এর মতো হতে হবে'
                : 'Must look like com.company.app'
            }
            action={{
              icon: 'refresh',
              onPress: () => patchConfig({ packageId: toPackageId(config.appName) }),
            }}
          />
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <View style={{ flex: 1 }}>
              <Field
                label={bn ? 'ভার্সন' : 'Version'}
                value={config.version}
                onChange={(v) => patchConfig({ version: v.replace(/[^0-9.]/g, '') })}
                placeholder="1.0.0"
                mono
              />
            </View>
            <View style={{ flex: 1 }}>
              <Field
                label={bn ? 'কোড' : 'Code'}
                value={String(config.versionCode)}
                onChange={(v) => patchConfig({ versionCode: Number(v.replace(/\D/g, '')) || 1 })}
                placeholder="1"
                mono
                keyboard="number-pad"
              />
            </View>
          </View>

          <Text style={[styles.fieldLabel, { color: p.muted, marginTop: 4 }]}>
            {bn ? 'ওরিয়েন্টেশন' : 'Orientation'}
          </Text>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {(['portrait', 'landscape', 'auto'] as const).map((o) => (
              <Pressable
                key={o}
                onPress={() => patchConfig({ orientation: o })}
                style={[
                  styles.chip,
                  {
                    backgroundColor: config.orientation === o ? p.accentSoft : p.surfaceAlt,
                    borderColor: config.orientation === o ? p.accent : 'transparent',
                  },
                ]}
              >
                <Text
                  style={{
                    color: config.orientation === o ? p.accent : p.textDim,
                    fontSize: 12.5,
                    fontWeight: '700',
                  }}
                >
                  {o === 'portrait'
                    ? bn
                      ? 'পোর্ট্রেট'
                      : 'Portrait'
                    : o === 'landscape'
                    ? bn
                      ? 'ল্যান্ডস্কেপ'
                      : 'Landscape'
                    : bn
                    ? 'অটো'
                    : 'Auto'}
                </Text>
              </Pressable>
            ))}
          </View>
        </ScrollView>
        <Button
          label={bn ? 'ঠিক আছে' : 'Done'}
          onPress={() => setDetailsOpen(false)}
          style={{ marginTop: 14 }}
        />
      </Sheet>

      {/* --------------------------------------------------- settings */}
      <Sheet
        visible={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        title={bn ? 'সেটিংস' : 'Settings'}
      >
        <Text style={[styles.fieldLabel, { color: p.muted }]}>{bn ? 'ভাষা' : 'Language'}</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 18 }}>
          {(['bn', 'en'] as const).map((l) => (
            <Pressable
              key={l}
              onPress={() => setLang(l)}
              style={[
                styles.chip,
                {
                  flex: 1,
                  justifyContent: 'center',
                  backgroundColor: lang === l ? p.accentSoft : p.surfaceAlt,
                  borderColor: lang === l ? p.accent : 'transparent',
                },
              ]}
            >
              <Text
                style={{ color: lang === l ? p.accent : p.textDim, fontSize: 13, fontWeight: '700' }}
              >
                {l === 'bn' ? 'বাংলা' : 'English'}
              </Text>
            </Pressable>
          ))}
        </View>

        <Text style={[styles.fieldLabel, { color: p.muted }]}>{bn ? 'থিম' : 'Theme'}</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 18 }}>
          {(['dark', 'light'] as const).map((m) => (
            <Pressable
              key={m}
              onPress={() => setMode(m)}
              style={[
                styles.chip,
                {
                  flex: 1,
                  justifyContent: 'center',
                  backgroundColor: mode === m ? p.accentSoft : p.surfaceAlt,
                  borderColor: mode === m ? p.accent : 'transparent',
                },
              ]}
            >
              <Ionicons
                name={m === 'dark' ? 'moon' : 'sunny'}
                size={13}
                color={mode === m ? p.accent : p.textDim}
              />
              <Text
                style={{
                  color: mode === m ? p.accent : p.textDim,
                  fontSize: 13,
                  fontWeight: '700',
                  marginLeft: 6,
                }}
              >
                {m === 'dark' ? (bn ? 'ডার্ক' : 'Dark') : bn ? 'লাইট' : 'Light'}
              </Text>
            </Pressable>
          ))}
        </View>

        <View style={[styles.switchRow, { borderColor: p.borderSoft }]}>
          <Ionicons name="cloud-offline-outline" size={17} color={p.textDim} />
          <Text style={{ color: p.text, fontSize: 13.5, flex: 1, marginLeft: 10, fontWeight: '600' }}>
            {bn ? 'অফলাইন ক্যাশ' : 'Offline cache'}
          </Text>
          <Switch
            value={config.offlineCache}
            onValueChange={(v) => patchConfig({ offlineCache: v })}
            trackColor={{ true: p.accent, false: p.border }}
            thumbColor="#fff"
          />
        </View>

        {activeVfs ? (
          <Button
            label={bn ? 'ফাইলগুলো দেখুন' : 'Browse files'}
            icon="folder-outline"
            tone="outline"
            onPress={() => {
              setSettingsOpen(false);
              nav.navigate('Files');
            }}
            style={{ marginTop: 16 }}
          />
        ) : null}
        <Button
          label={bn ? 'সাহায্য ও সমাধান' : 'Help & troubleshooting'}
          icon="help-buoy-outline"
          tone="outline"
          onPress={() => {
            setSettingsOpen(false);
            nav.navigate('Help');
          }}
          style={{ marginTop: 10 }}
        />
        <Button
          label={bn ? 'বন্ধ' : 'Close'}
          tone="quiet"
          onPress={() => setSettingsOpen(false)}
          style={{ marginTop: 10 }}
        />
      </Sheet>
    </SafeAreaView>
  );
}

/* ------------------------------------------------------------------ field */

function Field({
  label,
  value,
  onChange,
  placeholder,
  mono,
  error,
  action,
  keyboard,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  mono?: boolean;
  error?: string;
  action?: { icon: string; onPress: () => void };
  keyboard?: any;
}) {
  const { p } = useApp();
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={[styles.fieldLabel, { color: p.muted }]}>{label}</Text>
      <View
        style={[
          styles.inputWrap,
          { backgroundColor: p.surfaceAlt, borderColor: error ? p.danger : p.border },
        ]}
      >
        <TextInput
          value={value}
          onChangeText={onChange}
          placeholder={placeholder}
          placeholderTextColor={p.muted}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType={keyboard}
          returnKeyType="done"
          style={{
            flex: 1,
            color: p.text,
            fontSize: 14,
            paddingVertical: 12,
            fontFamily: mono ? (Platform.OS === 'ios' ? 'Menlo' : 'monospace') : undefined,
          }}
        />
        {action ? (
          <Pressable onPress={action.onPress} hitSlop={8} style={{ padding: 4 }}>
            <Ionicons name={action.icon as any} size={16} color={p.muted} />
          </Pressable>
        ) : null}
      </View>
      {error ? <Text style={{ color: p.danger, fontSize: 11, marginTop: 4 }}>{error}</Text> : null}
    </View>
  );
}

/* ----------------------------------------------------------------- styles */

const styles = StyleSheet.create({
  appbar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingTop: 6,
    paddingBottom: 14,
  },
  brand: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  barBtn: { padding: 7 },

  ring: {
    width: 30,
    height: 30,
    borderRadius: 999,
    borderWidth: 1.8,
    alignItems: 'center',
    justifyContent: 'center',
  },

  fileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 16,
    padding: 13,
  },
  fileIcon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },

  errBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    borderWidth: 1,
    borderRadius: 13,
    padding: 12,
    marginTop: 11,
  },

  buildCard: { borderWidth: 1, borderRadius: 18, padding: 15 },
  editPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
  },
  hr: { height: 1, marginVertical: 14 },
  track: { height: 7, borderRadius: 999, overflow: 'hidden' },
  logBox: { borderRadius: 11, padding: 11, marginTop: 12, borderWidth: 1 },

  route: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.4,
    borderRadius: 17,
    padding: 14,
  },
  routeIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  tag: { paddingHorizontal: 7, paddingVertical: 3, borderRadius: 999 },

  toast: {
    position: 'absolute',
    left: 18,
    right: 18,
    bottom: 18,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    borderWidth: 1,
    borderRadius: 14,
    padding: 13,
  },

  modalWrap: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.5)' },
  sheet: {
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    borderWidth: 1,
    padding: 22,
    paddingBottom: 32,
  },
  grabber: { width: 40, height: 4, borderRadius: 999, alignSelf: 'center', marginBottom: 16 },

  srcRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 14,
    padding: 11,
    marginBottom: 8,
  },
  srcIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },

  fieldLabel: {
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 0.7,
    textTransform: 'uppercase',
    marginBottom: 7,
  },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 13,
  },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13, fontSize: 14 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 13,
    paddingVertical: 9,
    borderRadius: 999,
    borderWidth: 1,
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 13,
    padding: 12,
  },
});
