import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import * as Clipboard from 'expo-clipboard';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../lib/store';
import { formatBytes } from '../lib/zip';
import { buildAndroidProject, ExportKind, outputBaseName, saveZip } from '../lib/export';
import {
  Channel,
  ChannelId,
  channelsFor,
  keytoolCommand,
  makeKeystore,
} from '../lib/apk';
import { Badge, Btn, Card, EmptyState, FadeIn, MonoText, SectionTitle } from '../components/ui';
import QR from '../components/QR';

export default function DeliverScreen() {
  const { p, t, lang, activeProject, activeVfs, config, builds } = useApp();
  const nav: any = useNavigation();

  const [open, setOpen] = useState<ChannelId | null>('actions');
  const [saving, setSaving] = useState<ExportKind | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [keyOpen, setKeyOpen] = useState(false);
  const [linkOpen, setLinkOpen] = useState(false);
  const [link, setLink] = useState('');

  const keystore = useMemo(() => makeKeystore(config), [config.appName]);
  const repoName = useMemo(() => `${outputBaseName(config)}-android`, [config.appName]);
  const channels = useMemo(
    () => channelsFor(config, keystore, repoName),
    [config, keystore, repoName]
  );

  const lastGood = builds.find((b) => b.status === 'success') ?? null;

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 3400);
    return () => clearTimeout(id);
  }, [toast]);

  useEffect(() => {
    if (!copied) return;
    const id = setTimeout(() => setCopied(null), 1600);
    return () => clearTimeout(id);
  }, [copied]);

  const copy = useCallback(async (text: string, id: string) => {
    try {
      await Clipboard.setStringAsync(text);
      setCopied(id);
    } catch {
      setToast(lang === 'bn' ? 'কপি করা যায়নি' : 'Could not copy');
    }
  }, [lang]);

  const doExport = useCallback(
    async (kind: ExportKind) => {
      if (!activeProject || !activeVfs) {
        setToast(
          lang === 'bn'
            ? 'আগে একটি ZIP ইমপোর্ট করুন।'
            : 'Import a ZIP first.'
        );
        return;
      }
      setSaving(kind);
      try {
        const zip = await buildAndroidProject(
          activeVfs,
          activeProject,
          config,
          lastGood?.checksum ?? 'draft',
          kind
        );
        const base = outputBaseName(config);
        const name =
          kind === 'source'
            ? `${base}-source.zip`
            : kind === 'web'
            ? `${base}-installable-web.zip`
            : `${base}-${config.version}-android-project.zip`;
        const res = await saveZip(zip, name);
        setToast(
          res.ok
            ? res.where === 'downloads'
              ? lang === 'bn'
                ? `✔ ফোল্ডারে সেভ হয়েছে · ${name}`
                : `✔ Saved to your folder · ${name}`
              : lang === 'bn'
              ? `✔ শেয়ার শিটে পাঠানো হয়েছে · ${name}`
              : `✔ Sent to the share sheet · ${name}`
            : `${lang === 'bn' ? 'ব্যর্থ' : 'Failed'}: ${res.message}`
        );
      } catch (e: any) {
        setToast(String(e?.message || e));
      } finally {
        setSaving(null);
      }
    },
    [activeProject, activeVfs, config, lang, lastGood]
  );

  if (!activeProject) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: p.bg }} edges={['top']}>
        <EmptyState
          icon="rocket-outline"
          title={lang === 'bn' ? 'এখনো কিছু ডেলিভার করার নেই' : 'Nothing to deliver yet'}
          subtitle={
            lang === 'bn'
              ? 'একটি ZIP ইমপোর্ট করলে এখানে APK পাওয়ার সব পথ দেখা যাবে।'
              : 'Import a ZIP and every route to a real APK appears here.'
          }
          action={<Btn label={lang === 'bn' ? 'ফিরে যান' : 'Go back'} icon="arrow-back" onPress={() => nav.goBack()} />}
        />
      </SafeAreaView>
    );
  }

  const tint = (k: string) => (k === 'accent' ? p.accent : k === 'violet' ? p.violet : p.warn);
  const soft = (k: string) =>
    k === 'accent' ? p.accentSoft : k === 'violet' ? p.violetSoft : p.warnSoft;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: p.bg }} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 18, paddingBottom: 46 }}>
        <FadeIn>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
            <Pressable onPress={() => nav.goBack()} hitSlop={10} style={{ padding: 4, marginRight: 8 }}>
              <Ionicons name="chevron-back" size={24} color={p.text} />
            </Pressable>
            <View style={{ flex: 1 }}>
              <Text style={{ color: p.text, fontSize: 23, fontWeight: '900', letterSpacing: -0.5 }}>
                {lang === 'bn' ? 'APK ডেলিভারি' : 'Get your APK'}
              </Text>
              <MonoText style={{ color: p.muted, marginTop: 4 }} numberOfLines={1}>
                {outputBaseName(config)}-{config.version}.{config.output}
              </MonoText>
            </View>
            <View style={[styles.logo, { backgroundColor: p.accentSoft, borderColor: p.accent }]}>
              <Ionicons name="download" size={22} color={p.accent} />
            </View>
          </View>
        </FadeIn>

        {/* ---------------------------------------------------- ready pack */}
        <FadeIn delay={50}>
          <Card>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={[styles.packIcon, { backgroundColor: p.violetSoft }]}>
                <Ionicons name="cube" size={22} color={p.violet} />
              </View>
              <View style={{ flex: 1, marginLeft: 13 }}>
                <Text style={{ color: p.text, fontSize: 16, fontWeight: '800' }}>
                  {lang === 'bn' ? 'বিল্ড প্যাক তৈরি' : 'Your build pack is ready'}
                </Text>
                <Text style={{ color: p.muted, fontSize: 12.5, marginTop: 3, lineHeight: 18 }}>
                  {lang === 'bn'
                    ? `${activeVfs?.files.size ?? 0} টি আসল ফাইল + কীস্টোর, CI ওয়ার্কফ্লো, PWA শেল`
                    : `${activeVfs?.files.size ?? 0} original files + keystore, CI workflow, PWA shell`}
                </Text>
              </View>
            </View>

            <View style={{ flexDirection: 'row', gap: 7, marginTop: 13, flexWrap: 'wrap' }}>
              <Badge text=".github/workflows" color={p.accent} bg={p.accentSoft} icon="logo-github" />
              <Badge text="signing.gradle" color={p.violet} bg={p.violetSoft} icon="key" />
              <Badge text="manifest + sw.js" color={p.warn} bg={p.warnSoft} icon="flash" />
              <Badge text="build-apk.sh" />
              {activeVfs ? <Badge text={formatBytes(activeVfs.totalBytes)} /> : null}
            </View>

            <View style={{ flexDirection: 'row', gap: 10, marginTop: 16 }}>
              <Btn
                label={lang === 'bn' ? 'বিল্ড প্যাক' : 'Build pack'}
                icon="logo-android"
                loading={saving === 'project'}
                onPress={() => doExport('project')}
                style={{ flex: 1.4 }}
              />
              <Btn
                label={lang === 'bn' ? 'ওয়েব অ্যাপ' : 'Web app'}
                icon="flash-outline"
                variant="ghost"
                loading={saving === 'web'}
                onPress={() => doExport('web')}
                style={{ flex: 1 }}
              />
            </View>
          </Card>
        </FadeIn>

        {/* ------------------------------------------------------ keystore */}
        <View style={{ height: 20 }} />
        <SectionTitle
          title={lang === 'bn' ? 'সাইনিং কী' : 'Signing key'}
          icon="key-outline"
          right={
            <Pressable onPress={() => setKeyOpen(true)} hitSlop={8}>
              <Text style={{ color: p.violet, fontSize: 12.5, fontWeight: '800' }}>
                {lang === 'bn' ? 'দেখুন' : 'Reveal'}
              </Text>
            </Pressable>
          }
        />
        <FadeIn delay={70}>
          <Card>
            <Text style={{ color: p.textDim, fontSize: 13, lineHeight: 20 }}>
              {lang === 'bn'
                ? 'প্রতিটি এক্সপোর্টে একটি ইউনিক কীস্টোর কনফিগ যুক্ত হয়, যাতে APK সাইন করা যায় এবং পরে আপডেটও ইনস্টল হয়।'
                : 'Every export ships a unique keystore config so the APK can be signed — and future updates will still install.'}
            </Text>
            <View style={[styles.keyRow, { borderColor: p.border }]}>
              <Ionicons name="finger-print" size={16} color={p.violet} />
              <MonoText style={{ color: p.text, flex: 1, marginLeft: 10 }} numberOfLines={1}>
                {keystore.alias}
              </MonoText>
              <Pressable onPress={() => copy(keytoolCommand(keystore), 'key')} hitSlop={8}>
                <Ionicons
                  name={copied === 'key' ? 'checkmark-circle' : 'copy-outline'}
                  size={17}
                  color={copied === 'key' ? p.accent : p.muted}
                />
              </Pressable>
            </View>
          </Card>
        </FadeIn>

        {/* ------------------------------------------------------ channels */}
        <View style={{ height: 20 }} />
        <SectionTitle
          title={lang === 'bn' ? 'APK পাওয়ার ৪টি পথ' : '4 ways to get the APK'}
          icon="git-branch-outline"
        />

        {channels.map((c, i) => (
          <ChannelCard
            key={c.id}
            channel={c}
            index={i}
            open={open === c.id}
            onToggle={() => setOpen(open === c.id ? null : c.id)}
            copied={copied}
            onCopy={copy}
            tint={tint(c.tint)}
            soft={soft(c.tint)}
          />
        ))}

        {/* --------------------------------------------------- QR handoff */}
        <View style={{ height: 20 }} />
        <SectionTitle
          title={lang === 'bn' ? 'ফোনে পাঠান' : 'Send it to the phone'}
          icon="qr-code-outline"
        />
        <FadeIn delay={90}>
          <Card>
            <Text style={{ color: p.textDim, fontSize: 13, lineHeight: 20 }}>
              {lang === 'bn'
                ? 'বিল্ড শেষে যে ডাউনলোড লিংক পাবেন সেটি এখানে বসান — QR স্ক্যান করে সরাসরি ফোনে APK নামান।'
                : 'Paste the download link your build produced — scan the QR to pull the APK straight onto the phone.'}
            </Text>
            {link ? (
              <View style={{ alignItems: 'center', marginTop: 18 }}>
                <QR value={link} size={190} dark={p.mode === 'dark' ? '#0A0F14' : '#0A0F14'} />
                <MonoText
                  style={{ color: p.muted, marginTop: 12, fontSize: 11 }}
                  numberOfLines={2}
                >
                  {link}
                </MonoText>
                <View style={{ flexDirection: 'row', gap: 10, marginTop: 14, alignSelf: 'stretch' }}>
                  <Btn
                    label={lang === 'bn' ? 'কপি' : 'Copy'}
                    icon={copied === 'link' ? 'checkmark' : 'copy-outline'}
                    variant="ghost"
                    small
                    onPress={() => copy(link, 'link')}
                    style={{ flex: 1 }}
                  />
                  <Btn
                    label={lang === 'bn' ? 'বদলান' : 'Change'}
                    icon="create-outline"
                    variant="ghost"
                    small
                    onPress={() => setLinkOpen(true)}
                    style={{ flex: 1 }}
                  />
                </View>
              </View>
            ) : (
              <Btn
                label={lang === 'bn' ? 'ডাউনলোড লিংক বসান' : 'Add the download link'}
                icon="link-outline"
                variant="violet"
                onPress={() => setLinkOpen(true)}
                style={{ marginTop: 14 }}
              />
            )}
          </Card>
        </FadeIn>

        {/* ------------------------------------------------------- honesty */}
        <View style={{ height: 20 }} />
        <FadeIn delay={110}>
          <View style={[styles.note, { backgroundColor: p.surfaceAlt, borderColor: p.border }]}>
            <Ionicons name="information-circle" size={17} color={p.textDim} />
            <Text style={{ color: p.textDim, fontSize: 12.5, flex: 1, lineHeight: 19 }}>
              {lang === 'bn'
                ? 'সরাসরি ফোনের ভেতরে Gradle/Java চালিয়ে APK কম্পাইল করা সম্ভব নয় — Android SDK ও JDK লাগে। তাই APK Studio সবকিছু তৈরি করে দেয় আর উপরের যেকোনো একটি পথে আসল APK এনে দেয়। ৪ নম্বর পথে কোনো কম্পাইলারই লাগে না।'
                : 'Compiling an APK on the phone itself is impossible — it needs the Android SDK and a JDK. APK Studio therefore prepares everything and hands it to one of the routes above. Route 4 needs no compiler at all.'}
            </Text>
          </View>
        </FadeIn>
      </ScrollView>

      {toast ? (
        <View style={[styles.toast, { backgroundColor: p.elevated, borderColor: p.border }]}>
          <Ionicons name="information-circle" size={16} color={p.accent} />
          <Text style={{ color: p.text, fontSize: 12.5, flex: 1 }} numberOfLines={2}>
            {toast}
          </Text>
        </View>
      ) : null}

      {/* keystore sheet */}
      <Modal visible={keyOpen} transparent animationType="slide" onRequestClose={() => setKeyOpen(false)}>
        <View style={styles.modalWrap}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setKeyOpen(false)} />
          <View style={[styles.sheet, { backgroundColor: p.surface, borderColor: p.border }]}>
            <View style={[styles.grabber, { backgroundColor: p.border }]} />
            <Text style={{ color: p.text, fontSize: 18, fontWeight: '900' }}>
              {lang === 'bn' ? 'কীস্টোর তথ্য' : 'Keystore credentials'}
            </Text>
            <Text style={{ color: p.muted, fontSize: 12.5, marginTop: 4, marginBottom: 16 }}>
              {lang === 'bn'
                ? 'এগুলো সংরক্ষণ করুন — আপডেট একই কী দিয়ে সাইন করতে হবে।'
                : 'Save these — updates must be signed with the same key.'}
            </Text>
            <ScrollView style={{ maxHeight: 340 }}>
              {[
                { k: 'KEY_ALIAS', v: keystore.alias },
                { k: 'KEYSTORE_PASSWORD', v: keystore.storePassword },
                { k: 'KEY_PASSWORD', v: keystore.keyPassword },
                { k: 'FILE', v: keystore.fileName },
              ].map((row) => (
                <View key={row.k} style={[styles.credRow, { borderColor: p.border }]}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: p.muted, fontSize: 10.5, fontWeight: '800', letterSpacing: 0.8 }}>
                      {row.k}
                    </Text>
                    <MonoText style={{ color: p.text, fontSize: 13, marginTop: 3 }}>{row.v}</MonoText>
                  </View>
                  <Pressable onPress={() => copy(row.v, row.k)} hitSlop={8} style={{ padding: 6 }}>
                    <Ionicons
                      name={copied === row.k ? 'checkmark-circle' : 'copy-outline'}
                      size={17}
                      color={copied === row.k ? p.accent : p.muted}
                    />
                  </Pressable>
                </View>
              ))}
              <Text style={[styles.cmdLabel, { color: p.muted }]}>
                {lang === 'bn' ? 'কীস্টোর বানানোর কমান্ড' : 'Create the keystore'}
              </Text>
              <CodeBlock
                code={keytoolCommand(keystore)}
                onCopy={() => copy(keytoolCommand(keystore), 'keytool')}
                copied={copied === 'keytool'}
              />
            </ScrollView>
            <Btn label={t('close')} variant="ghost" onPress={() => setKeyOpen(false)} style={{ marginTop: 14 }} />
          </View>
        </View>
      </Modal>

      {/* link sheet */}
      <Modal visible={linkOpen} transparent animationType="slide" onRequestClose={() => setLinkOpen(false)}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={styles.modalWrap}
        >
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setLinkOpen(false)} />
          <View style={[styles.sheet, { backgroundColor: p.surface, borderColor: p.border }]}>
            <View style={[styles.grabber, { backgroundColor: p.border }]} />
            <Text style={{ color: p.text, fontSize: 17, fontWeight: '900', marginBottom: 4 }}>
              {lang === 'bn' ? 'ডাউনলোড লিংক' : 'Download link'}
            </Text>
            <Text style={{ color: p.muted, fontSize: 13, marginBottom: 14 }}>
              {lang === 'bn'
                ? 'GitHub artifact, EAS বিল্ড অথবা হোস্ট করা ওয়েব অ্যাপের লিংক।'
                : 'A GitHub artifact, EAS build or hosted web app URL.'}
            </Text>
            <TextInput
              value={link}
              onChangeText={setLink}
              placeholder="https://expo.dev/artifacts/…"
              placeholderTextColor={p.muted}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
              returnKeyType="done"
              onSubmitEditing={() => setLinkOpen(false)}
              style={[styles.input, { color: p.text, backgroundColor: p.surfaceAlt, borderColor: p.border }]}
            />
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
              <Btn
                label={lang === 'bn' ? 'মুছুন' : 'Clear'}
                variant="ghost"
                onPress={() => {
                  setLink('');
                  setLinkOpen(false);
                }}
                style={{ flex: 1 }}
              />
              <Btn
                label={lang === 'bn' ? 'QR বানান' : 'Make QR'}
                icon="qr-code-outline"
                onPress={() => setLinkOpen(false)}
                style={{ flex: 1.4 }}
              />
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

/* ------------------------------------------------------------- sub views */

function ChannelCard({
  channel,
  index,
  open,
  onToggle,
  copied,
  onCopy,
  tint,
  soft,
}: {
  channel: Channel;
  index: number;
  open: boolean;
  onToggle: () => void;
  copied: string | null;
  onCopy: (text: string, id: string) => void;
  tint: string;
  soft: string;
}) {
  const { p, lang } = useApp();
  return (
    <FadeIn delay={index * 45}>
      <Card style={{ marginBottom: 11 }} padded={false}>
        <Pressable onPress={onToggle} style={{ padding: 15, flexDirection: 'row', alignItems: 'center' }}>
          <View style={[styles.chIcon, { backgroundColor: soft }]}>
            <Ionicons name={channel.icon as any} size={20} color={tint} />
          </View>
          <View style={{ flex: 1, marginLeft: 13 }}>
            <Text style={{ color: p.text, fontSize: 15, fontWeight: '800' }}>
              {lang === 'bn' ? channel.title.bn : channel.title.en}
            </Text>
            <Text style={{ color: p.muted, fontSize: 12, marginTop: 3, lineHeight: 17 }}>
              {lang === 'bn' ? channel.tagline.bn : channel.tagline.en}
            </Text>
          </View>
          <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={17} color={p.muted} />
        </Pressable>

        {open ? (
          <View style={{ paddingHorizontal: 15, paddingBottom: 16 }}>
            <View style={{ flexDirection: 'row', gap: 7, flexWrap: 'wrap', marginBottom: 14 }}>
              <Badge
                text={lang === 'bn' ? channel.time.bn : channel.time.en}
                icon="time-outline"
              />
              <Badge
                text={lang === 'bn' ? channel.needs.bn : channel.needs.en}
                icon="cube-outline"
              />
              <Badge
                text={lang === 'bn' ? channel.output.bn : channel.output.en}
                color={tint}
                bg={soft}
                icon="download-outline"
              />
            </View>

            {channel.steps.map((s, i) => (
              <View key={i} style={{ flexDirection: 'row', marginBottom: 11 }}>
                <View style={[styles.stepNum, { backgroundColor: soft }]}>
                  <Text style={{ color: tint, fontWeight: '900', fontSize: 11 }}>{i + 1}</Text>
                </View>
                <Text style={{ color: p.textDim, fontSize: 13.5, flex: 1, lineHeight: 20 }}>
                  {lang === 'bn' ? s.bn : s.en}
                </Text>
              </View>
            ))}

            {channel.commands.map((c) => (
              <View key={c.label} style={{ marginTop: 10 }}>
                <Text style={[styles.cmdLabel, { color: p.muted }]}>{c.label}</Text>
                <CodeBlock
                  code={c.code}
                  onCopy={() => onCopy(c.code, `${channel.id}-${c.label}`)}
                  copied={copied === `${channel.id}-${c.label}`}
                />
              </View>
            ))}
          </View>
        ) : null}
      </Card>
    </FadeIn>
  );
}

function CodeBlock({
  code,
  onCopy,
  copied,
}: {
  code: string;
  onCopy: () => void;
  copied: boolean;
}) {
  const { p } = useApp();
  return (
    <View style={[styles.code, { backgroundColor: p.terminal, borderColor: p.border }]}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flex: 1 }}>
        <MonoText style={{ color: p.code.text, fontSize: 11.5, lineHeight: 18 }}>{code}</MonoText>
      </ScrollView>
      <Pressable onPress={onCopy} hitSlop={8} style={{ paddingLeft: 10 }}>
        <Ionicons
          name={copied ? 'checkmark-circle' : 'copy-outline'}
          size={16}
          color={copied ? p.accent : p.muted}
        />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  logo: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  packIcon: { width: 48, height: 48, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  chIcon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  keyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    marginTop: 14,
  },
  credRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    marginBottom: 9,
  },
  stepNum: {
    width: 22,
    height: 22,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 11,
    marginTop: 1,
  },
  cmdLabel: {
    fontSize: 10.5,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginBottom: 6,
  },
  code: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
  },
  note: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    borderWidth: 1,
    borderRadius: 14,
    padding: 14,
  },
  toast: {
    position: 'absolute',
    left: 18,
    right: 18,
    bottom: 18,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    borderWidth: 1,
    borderRadius: 14,
    padding: 13,
  },
  modalWrap: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.55)' },
  sheet: {
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    borderWidth: 1,
    padding: 22,
    paddingBottom: 32,
  },
  grabber: { width: 42, height: 4, borderRadius: 999, alignSelf: 'center', marginBottom: 16 },
  input: { borderWidth: 1, borderRadius: 13, paddingHorizontal: 14, paddingVertical: 13, fontSize: 14.5 },
});
