import React, { useCallback, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../lib/store';
import { DiagCheck, runDiagnostics } from '../lib/zip';
import { HELP_TOPICS } from '../lib/i18n';
import { Badge, Btn, Card, Chip, FadeIn, MonoText, SectionTitle } from '../components/ui';

export default function HelpScreen() {
  const { p, t, lang, setLang, mode, setMode } = useApp();
  const nav: any = useNavigation();
  const [open, setOpen] = useState<number | null>(0);
  const [checks, setChecks] = useState<DiagCheck[] | null>(null);
  const [running, setRunning] = useState(false);

  const onDiag = useCallback(async () => {
    setRunning(true);
    setChecks(null);
    const res = await runDiagnostics();
    setChecks(res);
    setRunning(false);
  }, []);

  const failing = checks?.filter((c) => c.status !== 'ok').length ?? 0;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: p.bg }} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 18, paddingBottom: 44 }}>
        <FadeIn>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
            <Pressable onPress={() => nav.goBack()} hitSlop={10} style={{ padding: 4, marginRight: 8 }}>
              <Ionicons name="chevron-back" size={24} color={p.text} />
            </Pressable>
            <Text style={{ color: p.text, fontSize: 23, fontWeight: '900', letterSpacing: -0.5 }}>
              {t('tabHelp')}
            </Text>
          </View>
          <Text style={{ color: p.muted, fontSize: 13, marginTop: 4 }}>
            {lang === 'bn'
              ? 'পিকার, স্টোরেজ ও ইনস্টল সমস্যার সমাধান।'
              : 'Fixes for picker, storage and install problems.'}
          </Text>
        </FadeIn>

        <View style={{ height: 20 }} />
        <SectionTitle title={t('appearance')} icon="color-wand-outline" />
        <Card>
          <Text style={[styles.mini, { color: p.muted }]}>{t('language')}</Text>
          <View style={styles.chipRow}>
            <Chip label="বাংলা" active={lang === 'bn'} onPress={() => setLang('bn')} icon="language-outline" />
            <Chip label="English" active={lang === 'en'} onPress={() => setLang('en')} icon="language-outline" />
          </View>
          <Text style={[styles.mini, { color: p.muted, marginTop: 16 }]}>{t('theme')}</Text>
          <View style={styles.chipRow}>
            <Chip label={t('darkT')} active={mode === 'dark'} onPress={() => setMode('dark')} icon="moon-outline" />
            <Chip label={t('lightT')} active={mode === 'light'} onPress={() => setMode('light')} icon="sunny-outline" />
          </View>
        </Card>

        <View style={{ height: 20 }} />
        <SectionTitle title={t('diagnostics')} icon="pulse-outline" />
        <Card>
          <Text style={{ color: p.textDim, fontSize: 13.5, lineHeight: 20 }}>
            {lang === 'bn'
              ? 'ফাইল পিকার, ZIP ইঞ্জিন ও স্টোরেজ রাইট অ্যাক্সেস সত্যিকারভাবে পরীক্ষা করে দেখুন।'
              : 'Runs real checks against the file chooser, ZIP engine and storage write access.'}
          </Text>
          <Btn
            label={t('runDiag')}
            icon="flash-outline"
            onPress={onDiag}
            loading={running}
            style={{ marginTop: 14 }}
          />

          {running ? (
            <View style={{ alignItems: 'center', paddingVertical: 18 }}>
              <ActivityIndicator color={p.accent} />
            </View>
          ) : null}

          {checks ? (
            <View style={{ marginTop: 16 }}>
              <View style={{ flexDirection: 'row', gap: 7, marginBottom: 12 }}>
                <Badge
                  text={
                    failing === 0
                      ? lang === 'bn'
                        ? 'সব ঠিক আছে'
                        : 'All systems ready'
                      : lang === 'bn'
                      ? `${failing} টি সতর্কতা`
                      : `${failing} issue(s)`
                  }
                  color={failing === 0 ? p.accent : p.warn}
                  bg={failing === 0 ? p.accentSoft : p.warnSoft}
                  icon={failing === 0 ? 'checkmark-circle' : 'warning-outline'}
                />
              </View>
              {checks.map((c) => (
                <View key={c.key} style={styles.check}>
                  <Ionicons
                    name={
                      c.status === 'ok' ? 'checkmark-circle' : c.status === 'warn' ? 'alert-circle' : 'close-circle'
                    }
                    size={17}
                    color={c.status === 'ok' ? p.accent : c.status === 'warn' ? p.warn : p.danger}
                  />
                  <View style={{ flex: 1, marginLeft: 10 }}>
                    <Text style={{ color: p.text, fontSize: 13.5, fontWeight: '700' }}>
                      {lang === 'bn' ? c.label.bn : c.label.en}
                    </Text>
                    <MonoText style={{ color: p.muted, marginTop: 3 }} numberOfLines={2}>
                      {c.detail}
                    </MonoText>
                  </View>
                </View>
              ))}
              <Btn
                label={t('chooseZip')}
                icon="folder-open-outline"
                variant="violet"
                onPress={() => nav.goBack()}
                style={{ marginTop: 14 }}
              />
            </View>
          ) : null}
        </Card>

        <View style={{ height: 20 }} />
        <SectionTitle title={t('troubleshoot')} icon="help-buoy-outline" />
        {HELP_TOPICS.map((topic, i) => {
          const isOpen = open === i;
          return (
            <FadeIn key={topic.title.en} delay={i * 40}>
              <Card style={{ marginBottom: 10 }} padded={false}>
                <Pressable
                  onPress={() => setOpen(isOpen ? null : i)}
                  style={{ flexDirection: 'row', alignItems: 'center', padding: 15 }}
                >
                  <View style={[styles.topicIcon, { backgroundColor: p.surfaceAlt }]}>
                    <Ionicons name={topic.icon as any} size={17} color={p.violet} />
                  </View>
                  <Text
                    style={{
                      color: p.text,
                      fontSize: 14.5,
                      fontWeight: '700',
                      flex: 1,
                      marginLeft: 12,
                      lineHeight: 20,
                    }}
                  >
                    {lang === 'bn' ? topic.title.bn : topic.title.en}
                  </Text>
                  <Ionicons name={isOpen ? 'chevron-up' : 'chevron-down'} size={17} color={p.muted} />
                </Pressable>
                {isOpen ? (
                  <View style={{ paddingHorizontal: 15, paddingBottom: 16 }}>
                    {(lang === 'bn' ? topic.body.bn : topic.body.en).map((line, j) => (
                      <View key={j} style={{ flexDirection: 'row', marginTop: 10 }}>
                        <View style={[styles.dot, { backgroundColor: p.accent }]} />
                        <Text
                          style={{ color: p.textDim, fontSize: 13.5, flex: 1, lineHeight: 21 }}
                        >
                          {line}
                        </Text>
                      </View>
                    ))}
                  </View>
                ) : null}
              </Card>
            </FadeIn>
          );
        })}

        <View style={{ height: 20 }} />
        <SectionTitle title={t('about')} icon="information-circle-outline" />
        <Card>
          <Text style={{ color: p.textDim, fontSize: 13.5, lineHeight: 21 }}>
            {lang === 'bn'
              ? 'APK স্টুডিও আপনার ZIP প্রজেক্ট সত্যিকারভাবে পড়ে, ফাইল ট্রি দেখায়, স্ট্যাক শনাক্ত করে এবং অ্যান্ড্রয়েড প্রজেক্ট (ম্যানিফেস্ট, গ্রেডল প্রপার্টি, WebView শেল) জেনারেট করে দেয়। শেষ ধাপে EAS/Gradle দিয়ে ইনস্টলযোগ্য APK বানানো যায়।'
              : 'APK Studio really parses your ZIP, shows the file tree, detects the stack and generates a complete Android project (manifest, gradle properties, WebView shell). The final installable APK is produced with the included EAS/Gradle command.'}
          </Text>
          <View style={{ flexDirection: 'row', gap: 7, marginTop: 14, flexWrap: 'wrap' }}>
            <Badge text="expo-document-picker" color={p.violet} bg={p.violetSoft} />
            <Badge text="jszip" color={p.accent} bg={p.accentSoft} />
            <Badge text="expo-file-system" />
            <Badge text="v1.0.0" />
          </View>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  mini: { fontSize: 11.5, fontWeight: '800', letterSpacing: 0.7, marginBottom: 8, textTransform: 'uppercase' },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  check: { flexDirection: 'row', alignItems: 'flex-start', paddingVertical: 9 },
  topicIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  dot: { width: 5, height: 5, borderRadius: 999, marginTop: 8, marginRight: 10 },
});
