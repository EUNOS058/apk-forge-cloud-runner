import React, { useMemo, useState } from 'react';
import {
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../lib/store';
import { findEntryPoint, formatBytes, iconForEntry, timeAgo } from '../lib/zip';
import { Badge, Btn, Card, EmptyState, FadeIn, MonoText, SectionTitle } from '../components/ui';

type Node = {
  name: string;
  path: string;
  dir: boolean;
  size: number;
  count: number;
};

export default function ProjectScreen() {
  const { p, t, lang, activeProject, activeVfs } = useApp();
  const nav: any = useNavigation();
  const [cwd, setCwd] = useState('');
  const [query, setQuery] = useState('');

  const stats = useMemo(() => {
    if (!activeProject) return null;
    const files = activeProject.entries.filter((e) => !e.dir);
    const dirs = new Set<string>();
    activeProject.entries.forEach((e) => {
      const parts = e.path.split('/');
      parts.pop();
      let acc = '';
      parts.forEach((d) => {
        acc = acc ? `${acc}/${d}` : d;
        dirs.add(acc);
      });
    });
    const byExt = new Map<string, number>();
    files.forEach((f) => byExt.set(f.ext || 'other', (byExt.get(f.ext || 'other') ?? 0) + 1));
    const top = [...byExt.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
    return {
      files: files.length,
      dirs: dirs.size,
      raw: files.reduce((s, f) => s + f.size, 0),
      top,
      entry: findEntryPoint(activeProject),
    };
  }, [activeProject]);

  const nodes = useMemo<Node[]>(() => {
    if (!activeProject) return [];
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      return activeProject.entries
        .filter((e) => !e.dir && e.path.toLowerCase().includes(q))
        .slice(0, 200)
        .map((e) => ({ name: e.path, path: e.path, dir: false, size: e.size, count: 0 }));
    }
    const map = new Map<string, Node>();
    for (const e of activeProject.entries) {
      if (cwd && !e.path.startsWith(cwd)) continue;
      const rest = e.path.slice(cwd.length);
      if (!rest) continue;
      const parts = rest.split('/');
      if (parts.length === 1) {
        const key = `${cwd}${parts[0]}`;
        const prev = map.get(key);
        map.set(key, {
          name: parts[0],
          path: key,
          dir: e.dir || prev?.dir || false,
          size: e.dir ? prev?.size ?? 0 : e.size,
          count: prev?.count ?? 0,
        });
      } else {
        const key = `${cwd}${parts[0]}`;
        const prev = map.get(key) ?? { name: parts[0], path: key, dir: true, size: 0, count: 0 };
        map.set(key, {
          ...prev,
          dir: true,
          size: prev.size + (e.dir ? 0 : e.size),
          count: prev.count + (e.dir ? 0 : 1),
        });
      }
    }
    return [...map.values()].sort((a, b) => {
      if (a.dir !== b.dir) return a.dir ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
  }, [activeProject, cwd, query]);

  if (!activeProject) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: p.bg }} edges={['top']}>
        <EmptyState
          icon="cube-outline"
          title={t('noProject')}
          subtitle={t('noProjectHint')}
          action={<Btn label={lang === 'bn' ? 'ফিরে যান' : 'Go back'} icon="arrow-back" onPress={() => nav.goBack()} />}
        />
      </SafeAreaView>
    );
  }

  const crumbs = cwd ? cwd.replace(/\/$/, '').split('/') : [];

  const header = (
    <View>
      <FadeIn>
        <Pressable
          onPress={() => nav.goBack()}
          hitSlop={10}
          style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12, gap: 4 }}
        >
          <Ionicons name="chevron-back" size={22} color={p.text} />
          <Text style={{ color: p.text, fontWeight: '700', fontSize: 15 }}>
            {lang === 'bn' ? 'ফাইল ব্রাউজার' : 'Files'}
          </Text>
        </Pressable>
        <Card>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View style={[styles.fw, { backgroundColor: p.surfaceAlt }]}>
              <Ionicons
                name={activeProject.framework.icon as any}
                size={24}
                color={activeProject.framework.color}
              />
            </View>
            <View style={{ flex: 1, marginLeft: 13 }}>
              <Text numberOfLines={1} style={{ color: p.text, fontSize: 19, fontWeight: '900' }}>
                {activeProject.name}
              </Text>
              <MonoText style={{ color: p.muted, marginTop: 3 }} numberOfLines={1}>
                {activeProject.fileName} · {timeAgo(activeProject.importedAt, lang)}
              </MonoText>
            </View>
          </View>

          <View style={{ flexDirection: 'row', gap: 7, marginTop: 13, flexWrap: 'wrap' }}>
            <Badge
              text={activeProject.framework.label}
              color={activeProject.framework.color}
              bg={p.surfaceAlt}
              icon="pricetag-outline"
            />
            <Badge
              text={
                activeProject.framework.mode === 'native'
                  ? lang === 'bn'
                    ? 'নেটিভ বিল্ড'
                    : 'native build'
                  : activeProject.framework.mode === 'webview'
                  ? lang === 'bn'
                    ? 'WebView র‍্যাপার'
                    : 'WebView wrapper'
                  : lang === 'bn'
                  ? 'হাইব্রিড'
                  : 'hybrid'
              }
              color={p.violet}
              bg={p.violetSoft}
              icon="construct-outline"
            />
            {activeProject.truncated ? (
              <Badge
                text={lang === 'bn' ? 'আংশিক ক্যাশ' : 'partial cache'}
                color={p.warn}
                bg={p.warnSoft}
                icon="warning-outline"
              />
            ) : null}
          </View>

          <View style={[styles.statGrid, { borderColor: p.border }]}>
            <Stat label={t('files')} value={String(stats?.files ?? 0)} icon="document-outline" />
            <Stat
              label={lang === 'bn' ? 'ফোল্ডার' : 'folders'}
              value={String(stats?.dirs ?? 0)}
              icon="folder-outline"
            />
            <Stat
              label={lang === 'bn' ? 'আর্কাইভ' : 'archive'}
              value={formatBytes(activeProject.sizeBytes)}
              icon="archive-outline"
            />
            <Stat
              label={lang === 'bn' ? 'আনপ্যাকড' : 'unpacked'}
              value={formatBytes(stats?.raw ?? 0)}
              icon="cube-outline"
            />
          </View>

          <View style={{ marginTop: 14 }}>
            <Text style={{ color: p.muted, fontSize: 12, fontWeight: '700' }}>
              {lang === 'bn' ? 'এন্ট্রি পয়েন্ট' : 'ENTRY POINT'}
            </Text>
            <MonoText style={{ color: p.accent, marginTop: 5, fontSize: 13 }}>
              {stats?.entry}
            </MonoText>
          </View>

          <Btn
            label={lang === 'bn' ? '▶ লাইভ চালান' : '▶ Run it live'}
            icon="play"
            variant="violet"
            onPress={() => nav.navigate('Preview')}
            disabled={!activeVfs}
            style={{ marginTop: 16 }}
          />
        </Card>
      </FadeIn>

      {stats && stats.top.length ? (
        <FadeIn delay={60}>
          <View style={{ marginTop: 20 }}>
            <SectionTitle
              title={lang === 'bn' ? 'ফাইল টাইপ' : 'File types'}
              icon="pie-chart-outline"
            />
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ gap: 9 }}
            >
              {stats.top.map(([ext, n]) => (
                <View
                  key={ext}
                  style={[styles.extChip, { backgroundColor: p.surface, borderColor: p.border }]}
                >
                  <MonoText style={{ color: p.text, fontWeight: '700', fontSize: 13 }}>
                    .{ext}
                  </MonoText>
                  <Text style={{ color: p.muted, fontSize: 12, marginTop: 2 }}>
                    {n} {t('files')}
                  </Text>
                </View>
              ))}
            </ScrollView>
          </View>
        </FadeIn>
      ) : null}

      <View style={{ marginTop: 20 }}>
        <SectionTitle
          title={lang === 'bn' ? 'ফাইল ব্রাউজার' : 'File browser'}
          icon="folder-open-outline"
        />
        <View style={[styles.search, { backgroundColor: p.surface, borderColor: p.border }]}>
          <Ionicons name="search" size={16} color={p.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder={t('searchFiles')}
            placeholderTextColor={p.muted}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="search"
            style={{ flex: 1, color: p.text, fontSize: 14.5, paddingVertical: 10 }}
          />
          {query ? (
            <Pressable onPress={() => setQuery('')} hitSlop={8}>
              <Ionicons name="close-circle" size={16} color={p.muted} />
            </Pressable>
          ) : null}
        </View>

        {!query ? (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ alignItems: 'center', gap: 4, paddingVertical: 11 }}
          >
            <Pressable onPress={() => setCwd('')} style={styles.crumb}>
              <Ionicons name="home" size={13} color={cwd ? p.muted : p.accent} />
            </Pressable>
            {crumbs.map((c, i) => (
              <View key={`${c}-${i}`} style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Ionicons name="chevron-forward" size={12} color={p.muted} />
                <Pressable
                  onPress={() => setCwd(`${crumbs.slice(0, i + 1).join('/')}/`)}
                  style={styles.crumb}
                >
                  <MonoText
                    style={{
                      color: i === crumbs.length - 1 ? p.accent : p.textDim,
                      fontSize: 12.5,
                      fontWeight: '700',
                    }}
                  >
                    {c}
                  </MonoText>
                </Pressable>
              </View>
            ))}
          </ScrollView>
        ) : (
          <View style={{ height: 11 }} />
        )}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: p.bg }} edges={['top']}>
      <FlatList
        data={nodes}
        keyExtractor={(n) => n.path}
        ListHeaderComponent={header}
        contentContainerStyle={{ padding: 18, paddingBottom: 40 }}
        ListEmptyComponent={
          <EmptyState
            icon="file-tray-outline"
            title={t('entriesEmpty')}
            subtitle={
              query
                ? lang === 'bn'
                  ? 'অন্য কিওয়ার্ড দিয়ে দেখুন।'
                  : 'Try a different keyword.'
                : undefined
            }
          />
        }
        renderItem={({ item }) => (
          <Pressable
            onPress={() => {
              if (item.dir) {
                setCwd(`${item.path}/`);
              } else {
                nav.navigate('FileViewer', { path: item.path });
              }
            }}
            style={({ pressed }) => [
              styles.fileRow,
              {
                backgroundColor: pressed ? p.surfaceAlt : p.surface,
                borderColor: p.border,
              },
            ]}
          >
            <Ionicons
              name={iconForEntry({ dir: item.dir, name: item.name }) as any}
              size={18}
              color={item.dir ? p.warn : p.textDim}
            />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text numberOfLines={1} style={{ color: p.text, fontSize: 14, fontWeight: '600' }}>
                {item.name}
              </Text>
              <Text style={{ color: p.muted, fontSize: 11.5, marginTop: 2 }}>
                {item.dir
                  ? `${item.count} ${t('files')} · ${formatBytes(item.size)}`
                  : formatBytes(item.size)}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={15} color={p.muted} />
          </Pressable>
        )}
      />
    </SafeAreaView>
  );
}

function Stat({ label, value, icon }: { label: string; value: string; icon: string }) {
  const { p } = useApp();
  return (
    <View style={{ flex: 1, minWidth: '44%', paddingVertical: 9 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
        <Ionicons name={icon as any} size={12} color={p.muted} />
        <Text style={{ color: p.muted, fontSize: 11.5, fontWeight: '700' }}>{label}</Text>
      </View>
      <Text style={{ color: p.text, fontSize: 16, fontWeight: '800', marginTop: 3 }}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  fw: { width: 50, height: 50, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  statGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    borderTopWidth: 1,
    marginTop: 14,
    paddingTop: 6,
  },
  extChip: {
    borderWidth: 1,
    borderRadius: 13,
    paddingHorizontal: 14,
    paddingVertical: 10,
    minWidth: 96,
  },
  search: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    borderWidth: 1,
    borderRadius: 13,
    paddingHorizontal: 13,
  },
  crumb: { paddingHorizontal: 8, paddingVertical: 5 },
  fileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 13,
    padding: 13,
    marginBottom: 8,
  },
});
