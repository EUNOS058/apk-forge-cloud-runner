import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../lib/store';
import {
  buildHtmlDocument,
  buildReactDocument,
  buildStaticDocument,
  planRun,
  RunTier,
} from '../lib/runtime';
import { extname } from '../lib/vfs';
import { logColor } from '../lib/theme';
import Runner, { RunnerMessage } from '../components/Runner';
import { Badge, Btn, EmptyState, MonoText } from '../components/ui';

type Log = { level: string; text: string; t: number };

const DEVICES = [
  { id: 'fit', label: { en: 'Fit', bn: 'ফিট' }, w: 0, h: 0 },
  { id: 'phone', label: { en: 'Phone', bn: 'ফোন' }, w: 360, h: 760 },
  { id: 'tablet', label: { en: 'Tablet', bn: 'ট্যাব' }, w: 600, h: 900 },
];

export default function RunScreen() {
  const { p, lang, activeProject, activeVfs } = useApp();
  const nav: any = useNavigation();
  const win = useWindowDimensions();

  const [reloadKey, setReloadKey] = useState(0);
  const [logs, setLogs] = useState<Log[]>([]);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [device, setDevice] = useState('fit');
  const [entryOverride, setEntryOverride] = useState<string | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [booting, setBooting] = useState(true);
  const bootTimer = useRef<any>(null);

  const plan = useMemo(() => (activeVfs ? planRun(activeVfs) : null), [activeVfs]);

  const entry = entryOverride ?? plan?.entry ?? '';
  const tier: RunTier = useMemo(() => {
    if (!plan) return 'none';
    if (!entryOverride) return plan.tier;
    const e = extname(entryOverride);
    if (e === 'html' || e === 'htm') return 'html';
    if (['js', 'jsx', 'ts', 'tsx'].includes(e)) return 'react';
    return 'static';
  }, [plan, entryOverride]);

  const html = useMemo(() => {
    if (!activeVfs || !activeProject) return '';
    try {
      if (tier === 'html') return buildHtmlDocument(activeVfs, entry);
      if (tier === 'react') return buildReactDocument(activeVfs, entry, p.bg, p.muted);
      return buildStaticDocument(
        activeVfs,
        {
          name: activeProject.name,
          framework: activeProject.framework.label,
          files: activeVfs.files.size,
          bg: p.bg,
          fg: p.text,
          accent: p.accent,
        },
        entry
      );
    } catch (e: any) {
      return `<!DOCTYPE html><html><body style="background:${p.bg};color:#FF8A94;font:13px monospace;padding:20px">Preview build error: ${String(
        e?.message || e
      )}</body></html>`;
    }
  }, [activeVfs, activeProject, tier, entry, p.bg, p.text, p.accent]);

  const runnable = useMemo(() => {
    if (!activeVfs) return [] as string[];
    return [...activeVfs.files.keys()]
      .filter((k) => /\.(html?|jsx?|tsx?)$/i.test(k))
      .sort((a, b) => a.localeCompare(b))
      .slice(0, 120);
  }, [activeVfs]);

  const onMessage = useCallback((m: RunnerMessage) => {
    if (m.type === 'console') {
      setLogs((prev) => [...prev.slice(-199), { ...m.payload, t: Date.now() }]);
    } else if (m.type === 'ready') {
      setBooting(false);
    } else if (m.type === 'navigate') {
      setLogs((prev) => [
        ...prev.slice(-199),
        { level: 'info', text: `→ navigate ${m.payload.href}`, t: Date.now() },
      ]);
    }
  }, []);

  const reload = useCallback(() => {
    setLogs([]);
    setBooting(true);
    setReloadKey((k) => k + 1);
  }, []);

  useEffect(() => {
    setBooting(true);
    clearTimeout(bootTimer.current);
    bootTimer.current = setTimeout(() => setBooting(false), tier === 'react' ? 7000 : 2600);
    return () => clearTimeout(bootTimer.current);
  }, [reloadKey, tier, entry]);

  const errCount = logs.filter((l) => l.level === 'error').length;

  if (!activeProject) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: p.bg }} edges={['top']}>
        <EmptyState
          icon="play-circle-outline"
          title={lang === 'bn' ? 'চালানোর মতো প্রজেক্ট নেই' : 'Nothing to run yet'}
          subtitle={
            lang === 'bn'
              ? 'একটি .zip ইমপোর্ট করলে সেটি এখানেই সরাসরি চলবে।'
              : 'Import a .zip and it will run right here.'
          }
          action={
            <Btn
              label={lang === 'bn' ? 'ফিরে যান' : 'Go back'}
              icon="arrow-back"
              onPress={() => nav.goBack()}
            />
          }
        />
      </SafeAreaView>
    );
  }

  if (!activeVfs) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: p.bg }} edges={['top']}>
        <EmptyState
          icon="refresh-circle-outline"
          title={lang === 'bn' ? 'সোর্স মেমোরিতে নেই' : 'Source not in memory'}
          subtitle={
            lang === 'bn'
              ? 'অ্যাপ রিস্টার্ট হয়েছে। চালাতে ZIP-টি আবার ইমপোর্ট করুন।'
              : 'The app restarted. Re-import the ZIP to run it again.'
          }
          action={
            <Btn
              label={lang === 'bn' ? 'আবার ইমপোর্ট' : 'Re-import'}
              icon="cloud-upload-outline"
              onPress={() => nav.goBack()}
            />
          }
        />
      </SafeAreaView>
    );
  }

  const dev = DEVICES.find((d) => d.id === device)!;
  const frameW = dev.w ? Math.min(dev.w, win.width - 32) : undefined;

  const stage = (
    <View style={{ flex: 1 }}>
      <View
        style={[
          styles.stage,
          {
            backgroundColor: p.terminal,
            borderColor: p.border,
            alignSelf: frameW ? 'center' : 'stretch',
            width: frameW,
            borderRadius: fullscreen ? 0 : 18,
            borderWidth: fullscreen ? 0 : 1,
          },
        ]}
      >
        <Runner html={html} bg={p.bg} reloadKey={reloadKey} onMessage={onMessage} />
        {booting ? (
          <View style={[styles.boot, { backgroundColor: `${p.bg}EE` }]} pointerEvents="none">
            <ActivityIndicator color={p.accent} />
            <MonoText style={{ color: p.muted, marginTop: 10 }}>
              {tier === 'react'
                ? lang === 'bn'
                  ? 'Babel দিয়ে কম্পাইল হচ্ছে…'
                  : 'compiling with Babel…'
                : lang === 'bn'
                ? 'লোড হচ্ছে…'
                : 'booting…'}
            </MonoText>
          </View>
        ) : null}
      </View>
    </View>
  );

  if (fullscreen) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: p.terminal }} edges={['top', 'bottom']}>
        {stage}
        <Pressable
          onPress={() => setFullscreen(false)}
          style={[styles.fab, { backgroundColor: p.elevated, borderColor: p.border }]}
        >
          <Ionicons name="contract-outline" size={20} color={p.text} />
        </Pressable>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: p.bg }} edges={['top']}>
      <View style={[styles.bar, { borderColor: p.border, backgroundColor: p.surface }]}>
        <Pressable onPress={() => nav.goBack()} hitSlop={10} style={{ paddingRight: 4 }}>
          <Ionicons name="chevron-down" size={22} color={p.text} />
        </Pressable>
        <View style={{ flex: 1, marginLeft: 10 }}>
          <Text numberOfLines={1} style={{ color: p.text, fontWeight: '800', fontSize: 15 }}>
            {activeProject.name}
          </Text>
          <MonoText numberOfLines={1} style={{ color: p.muted, marginTop: 2 }}>
            {entry || '—'}
          </MonoText>
        </View>
        <Pressable onPress={reload} hitSlop={8} style={styles.iconBtn}>
          <Ionicons name="reload" size={18} color={p.textDim} />
        </Pressable>
        <Pressable onPress={() => setFullscreen(true)} hitSlop={8} style={styles.iconBtn}>
          <Ionicons name="expand-outline" size={18} color={p.textDim} />
        </Pressable>
        <Pressable onPress={() => setConsoleOpen(true)} hitSlop={8} style={styles.iconBtn}>
          <Ionicons
            name="terminal-outline"
            size={18}
            color={errCount ? p.danger : p.textDim}
          />
          {errCount ? (
            <View style={[styles.dot, { backgroundColor: p.danger }]}>
              <Text style={{ color: '#fff', fontSize: 9, fontWeight: '900' }}>{errCount}</Text>
            </View>
          ) : null}
        </Pressable>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ padding: 12, gap: 8, alignItems: 'center' }}
        style={{ flexGrow: 0 }}
      >
        <Badge
          text={
            tier === 'html'
              ? lang === 'bn' ? 'অফলাইন রান' : 'offline run'
              : tier === 'react'
              ? lang === 'bn' ? 'লাইভ কম্পাইল' : 'live compile'
              : lang === 'bn' ? 'সামারি' : 'summary'
          }
          color={tier === 'static' ? p.warn : p.accent}
          bg={tier === 'static' ? p.warnSoft : p.accentSoft}
          icon={tier === 'react' ? 'flash' : tier === 'html' ? 'cloud-offline' : 'document-text'}
        />
        {DEVICES.map((d) => (
          <Pressable
            key={d.id}
            onPress={() => setDevice(d.id)}
            style={[
              styles.seg,
              {
                backgroundColor: device === d.id ? p.violetSoft : p.surfaceAlt,
                borderColor: device === d.id ? p.violet : 'transparent',
              },
            ]}
          >
            <Text
              style={{
                color: device === d.id ? p.violet : p.textDim,
                fontSize: 12,
                fontWeight: '700',
              }}
            >
              {lang === 'bn' ? d.label.bn : d.label.en}
            </Text>
          </Pressable>
        ))}
        <Pressable
          onPress={() => setPickerOpen(true)}
          style={[styles.seg, { backgroundColor: p.surfaceAlt, borderColor: 'transparent' }]}
        >
          <Ionicons name="swap-horizontal" size={13} color={p.textDim} />
          <Text style={{ color: p.textDim, fontSize: 12, fontWeight: '700', marginLeft: 5 }}>
            {lang === 'bn' ? 'এন্ট্রি বদলান' : 'Change entry'}
          </Text>
        </Pressable>
      </ScrollView>

      <View style={{ flex: 1, paddingHorizontal: 14, paddingBottom: 14 }}>{stage}</View>

      {plan && tier === 'react' ? (
        <View style={[styles.note, { backgroundColor: p.warnSoft, borderColor: p.warn }]}>
          <Ionicons name="wifi-outline" size={14} color={p.warn} />
          <Text style={{ color: p.warn, fontSize: 11.5, flex: 1 }}>
            {lang === 'bn'
              ? 'React/RN কোড ব্রাউজারে কম্পাইল হচ্ছে — ইন্টারনেট লাগবে।'
              : 'React/RN code is compiled in-page — an internet connection is required.'}
          </Text>
        </View>
      ) : null}

      {/* console */}
      <Modal
        visible={consoleOpen}
        transparent
        animationType="slide"
        onRequestClose={() => setConsoleOpen(false)}
      >
        <View style={styles.modalWrap}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setConsoleOpen(false)} />
          <View style={[styles.sheet, { backgroundColor: p.surface, borderColor: p.border }]}>
            <View style={[styles.grabber, { backgroundColor: p.border }]} />
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
              <Text style={{ color: p.text, fontSize: 17, fontWeight: '900', flex: 1 }}>
                {lang === 'bn' ? 'কনসোল' : 'Console'}
              </Text>
              <Btn
                label={lang === 'bn' ? 'মুছুন' : 'Clear'}
                variant="ghost"
                small
                icon="trash-outline"
                onPress={() => setLogs([])}
              />
            </View>
            <View style={[styles.terminal, { backgroundColor: p.terminal, borderColor: p.border }]}>
              <ScrollView style={{ maxHeight: 300 }}>
                {logs.length === 0 ? (
                  <MonoText style={{ color: p.code.dim }}>
                    {lang === 'bn' ? 'কোনো আউটপুট নেই।' : 'No output yet.'}
                  </MonoText>
                ) : (
                  logs.map((l, i) => (
                    <MonoText
                      key={i}
                      style={{
                        color: l.level === 'info' ? p.code.cmd : logColor(p, l.level),
                        fontSize: 11.5,
                        lineHeight: 17,
                      }}
                    >
                      {l.text}
                    </MonoText>
                  ))
                )}
              </ScrollView>
            </View>
            <Btn
              label={lang === 'bn' ? 'বন্ধ' : 'Close'}
              variant="ghost"
              onPress={() => setConsoleOpen(false)}
              style={{ marginTop: 14 }}
            />
          </View>
        </View>
      </Modal>

      {/* entry picker */}
      <Modal
        visible={pickerOpen}
        transparent
        animationType="slide"
        onRequestClose={() => setPickerOpen(false)}
      >
        <View style={styles.modalWrap}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setPickerOpen(false)} />
          <View style={[styles.sheet, { backgroundColor: p.surface, borderColor: p.border }]}>
            <View style={[styles.grabber, { backgroundColor: p.border }]} />
            <Text style={{ color: p.text, fontSize: 17, fontWeight: '900', marginBottom: 4 }}>
              {lang === 'bn' ? 'কোন ফাইল চালাবেন?' : 'Which file should run?'}
            </Text>
            <Text style={{ color: p.muted, fontSize: 12.5, marginBottom: 14 }}>
              {lang === 'bn'
                ? 'HTML সরাসরি চলে · JS/TSX Babel দিয়ে কম্পাইল হয়'
                : 'HTML runs directly · JS/TSX compiles through Babel'}
            </Text>
            <ScrollView style={{ maxHeight: 330 }}>
              {runnable.map((f) => (
                <Pressable
                  key={f}
                  onPress={() => {
                    setEntryOverride(f);
                    setPickerOpen(false);
                    reload();
                  }}
                  style={({ pressed }) => [
                    styles.entryRow,
                    {
                      backgroundColor: pressed ? p.surfaceAlt : 'transparent',
                      borderColor: f === entry ? p.accent : p.border,
                    },
                  ]}
                >
                  <Ionicons
                    name={/\.html?$/i.test(f) ? 'globe-outline' : 'logo-javascript'}
                    size={15}
                    color={f === entry ? p.accent : p.textDim}
                  />
                  <MonoText
                    numberOfLines={1}
                    style={{ color: f === entry ? p.accent : p.text, flex: 1, marginLeft: 10 }}
                  >
                    {f}
                  </MonoText>
                  {f === entry ? <Ionicons name="checkmark" size={15} color={p.accent} /> : null}
                </Pressable>
              ))}
              {runnable.length === 0 ? (
                <MonoText style={{ color: p.muted }}>
                  {lang === 'bn' ? 'চালানোর মতো ফাইল নেই।' : 'No runnable file found.'}
                </MonoText>
              ) : null}
            </ScrollView>
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
              <Btn
                label={lang === 'bn' ? 'অটো' : 'Auto'}
                variant="ghost"
                icon="sparkles-outline"
                onPress={() => {
                  setEntryOverride(null);
                  setPickerOpen(false);
                  reload();
                }}
                style={{ flex: 1 }}
              />
              <Btn
                label={lang === 'bn' ? 'বন্ধ' : 'Close'}
                variant="ghost"
                onPress={() => setPickerOpen(false)}
                style={{ flex: 1 }}
              />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 11,
    borderBottomWidth: 1,
  },
  playIcon: { width: 32, height: 32, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  iconBtn: { padding: 8 },
  dot: {
    position: 'absolute',
    top: 2,
    right: 2,
    minWidth: 14,
    height: 14,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  seg: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
  },
  stage: { flex: 1, overflow: 'hidden' },
  boot: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  note: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginHorizontal: 14,
    marginBottom: 12,
    padding: 10,
    borderRadius: 12,
    borderWidth: 1,
  },
  fab: {
    position: 'absolute',
    right: 18,
    bottom: 26,
    width: 46,
    height: 46,
    borderRadius: 999,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalWrap: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.55)' },
  sheet: {
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    borderWidth: 1,
    padding: 22,
    paddingBottom: 32,
  },
  grabber: { width: 42, height: 4, borderRadius: 999, alignSelf: 'center', marginBottom: 16 },
  terminal: { borderWidth: 1, borderRadius: 14, padding: 12 },
  entryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 11,
    paddingHorizontal: 12,
    paddingVertical: 11,
    marginBottom: 7,
  },
});
