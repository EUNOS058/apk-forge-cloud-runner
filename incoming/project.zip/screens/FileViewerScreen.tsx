import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useApp } from '../lib/store';
import { extOf, formatBytes, isTextFile } from '../lib/zip';
import { Badge, EmptyState, MonoText } from '../components/ui';

export default function FileViewerScreen() {
  const { p, t, lang, activeProject } = useApp();
  const nav: any = useNavigation();
  const route: any = useRoute();
  const path: string = route.params?.path ?? '';
  const [wrap, setWrap] = useState(false);

  const entry = activeProject?.entries.find((e) => e.path === path);
  const content = activeProject?.contents[path];
  const allLines = useMemo(() => (content ? content.split('\n') : []), [content]);
  const lines = useMemo(() => allLines.slice(0, 1200), [allLines]);
  const ext = extOf(path);

  const renderBody = () => {
    if (!isTextFile(path.split('/').pop() || '')) {
      return (
        <EmptyState
          icon="image-outline"
          title={t('binaryFile')}
          subtitle={`${ext.toUpperCase()} · ${formatBytes(entry?.size ?? 0)}`}
        />
      );
    }
    if (content == null) {
      return <EmptyState icon="cloud-offline-outline" title={t('notCached')} />;
    }
    return (
      <ScrollView
        horizontal={!wrap}
        showsHorizontalScrollIndicator
        contentContainerStyle={wrap ? { width: '100%' } : undefined}
      >
        <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 14, paddingBottom: 60 }}>
          {lines.map((l, i) => (
            <View key={i} style={{ flexDirection: 'row' }}>
              <MonoText
                style={{
                  color: p.code.dim,
                  width: 38,
                  textAlign: 'right',
                  marginRight: 12,
                  fontSize: 11.5,
                }}
              >
                {String(i + 1)}
              </MonoText>
              <MonoText
                style={{
                  color: colorFor(l, p),
                  fontSize: 12.5,
                  lineHeight: 18,
                  flexShrink: wrap ? 1 : 0,
                }}
              >
                {l.length ? l : ' '}
              </MonoText>
            </View>
          ))}
          {allLines.length > lines.length ? (
            <MonoText style={{ color: p.warn, marginTop: 14, fontSize: 11.5 }}>
              {lang === 'bn'
                ? `… আরও ${allLines.length - lines.length} লাইন লুকানো`
                : `… ${allLines.length - lines.length} more lines hidden`}
            </MonoText>
          ) : null}
        </ScrollView>
      </ScrollView>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: p.terminal }} edges={['top', 'bottom']}>
      <View style={[styles.bar, { borderColor: p.border, backgroundColor: p.surface }]}>
        <Pressable onPress={() => nav.goBack()} hitSlop={10} style={{ padding: 4 }}>
          <Ionicons name="close" size={22} color={p.text} />
        </Pressable>
        <View style={{ flex: 1, marginHorizontal: 12 }}>
          <Text numberOfLines={1} style={{ color: p.text, fontWeight: '800', fontSize: 15 }}>
            {path.split('/').pop()}
          </Text>
          <MonoText numberOfLines={1} style={{ color: p.muted, marginTop: 2 }}>
            {path}
          </MonoText>
        </View>
        <Pressable
          onPress={() => setWrap((w) => !w)}
          style={{
            paddingHorizontal: 11,
            paddingVertical: 7,
            borderRadius: 999,
            backgroundColor: wrap ? p.accentSoft : p.surfaceAlt,
          }}
        >
          <Text style={{ color: wrap ? p.accent : p.textDim, fontWeight: '700', fontSize: 12 }}>
            {t('wrap')}
          </Text>
        </Pressable>
      </View>

      <View style={[styles.metaRow, { backgroundColor: p.surface, borderColor: p.border }]}>
        <Badge text={ext ? `.${ext}` : 'file'} color={p.violet} bg={p.violetSoft} />
        <Badge text={formatBytes(entry?.size ?? content?.length ?? 0)} />
        <Badge text={`${allLines.length} ${lang === 'bn' ? 'লাইন' : 'lines'}`} />
      </View>

      <View style={{ flex: 1 }}>{renderBody()}</View>
    </SafeAreaView>
  );
}

function colorFor(line: string, p: any): string {
  const l = line.trim();
  if (!l) return p.code.dim;
  if (l.startsWith('//') || l.startsWith('#') || l.startsWith('*') || l.startsWith('/*'))
    return p.code.dim;
  if (l.startsWith('<') || l.startsWith('</')) return p.code.cmd;
  if (/^(import|export|from|const|let|var|function|class|return|async|await)\b/.test(l))
    return p.code.ok;
  if (/^[.#@:a-zA-Z-]+\s*\{/.test(l)) return p.code.warn;
  if (/^"[^"]+":/.test(l)) return p.code.cmd;
  return p.code.text;
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  metaRow: {
    flexDirection: 'row',
    gap: 7,
    paddingHorizontal: 14,
    paddingBottom: 11,
    borderBottomWidth: 1,
  },
});
